package com.extravision.tracking.Dialogs;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.extravision.tracking.R;

/**
 * Created by marktreble on 06/01/2016.
 */
public class PinDialog extends DialogFragment {
    private ViewGroup mView;

    private EditText mPinNumber;

    public static PinDialog newInstance() {

        PinDialog pinDialog = new PinDialog();
        return pinDialog;
    }

    public interface PinDialogListener {

        void onPINAccepted();
    }

    public PinDialogListener mListener;

    @Override
    @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new Dialog(getActivity(), getTheme()){
            @Override
            public void onBackPressed() {
                super.onBackPressed();
                getActivity().finish();
            }
        };
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(STYLE_NO_TITLE);
        mView = (ViewGroup)inflater.inflate(R.layout.pin_dialog, container);

        ImageView close = (ImageView)mView.findViewById(R.id.close_btn);
        /*close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });*/

        mPinNumber = (EditText)mView.findViewById(R.id.pin_number);

        mPinNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
                String user_id = sharedPreferences.getString("user_id", "");
                String prefID = sharedPreferences.getString("prefID", user_id);

                String pin = sharedPreferences.getString("pin_number_"+prefID, "");

                if (pin.equals(s.toString())){
                    // Correct PIN
                    if (mListener != null){
                        // Dismiss Keyboard
                        mPinNumber.onEditorAction(EditorInfo.IME_ACTION_DONE);
                        getDialog().setCancelable(true);
                        mListener.onPINAccepted();
                    }
                    // Dismiss after short delay (to allow keyboard to close!)
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            getDialog().dismiss();
                        }
                    }, 300);
                } else if (s.toString().length() == 4){
                    Animation shakeAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.shake);
                    mView.startAnimation(shakeAnimation);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        mPinNumber.requestFocus();
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        return mView;
    }

    @Override
    public void onResume() {
        super.onResume();
        final View v = getDialog().findViewById(R.id.pin_number);
        v.post(new Runnable() {
            @Override
            public void run() {
                v.requestFocus();
                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();

        if (getDialog() == null)
            return;

        getDialog().getWindow().setWindowAnimations(R.style.slide);

        getDialog().getWindow().setGravity(Gravity.CENTER);

        getDialog().setCancelable(false);

        int screenWidth = (int) getResources().getDisplayMetrics().widthPixels;
        getDialog().getWindow().setLayout(screenWidth,
                RelativeLayout.LayoutParams.WRAP_CONTENT);

        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

    }

}
