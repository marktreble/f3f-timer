package com.extravision.tracking.Fragments;

import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.extravision.tracking.MainActivity;
import com.extravision.tracking.Managers.API;
import com.extravision.tracking.Managers.CommandController;
import com.extravision.tracking.R;
import com.extravision.tracking.Views.ObjectListHeaderView;

/**
 * Created by marktreble on 04/01/2016.
 */
public class ObjectListFragment extends Fragment
        implements API.APICallbackInterface, ObjectListHeaderView.ObjectListHeaderViewListener {

    private static final String TAG = "ObjectListFragment";

    private static final int CELL_TYPE_HEADER = 0;
    private static final int CELL_TYPE_OBJECT = 1;

    private SwipeMenuListView mList;
    private JSONObject mRawData;
    private ArrayList<JSONObject> mObjectList;
    private ArrayAdapter<JSONObject> mAdapter;
    private ArrayList<String> mGroupsList = new ArrayList<>();
    private ArrayList<Boolean> mGroupsStatus = new ArrayList<>();
    private ArrayList<Integer> mGroupsCount = new ArrayList<>();

    private boolean mCheckAll = false;

    private CommandController command_controller;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "ONCREATE");

        if (savedInstanceState == null) {
            mObjectList = new ArrayList<>();
        } else {
            mCheckAll = savedInstanceState.getBoolean("checkall");

            // Restore the objects arrays

            /*mObjectList = new ArrayList<>();

            Object o;
            int counter = 0;
            do {
                o = null;
                if (savedInstanceState.containsKey("ol"+counter)) {
                    o = savedInstanceState.getString("ol" + counter++);
                    if (o != null){
                        try {
                            JSONObject obj = new JSONObject((String) o);
                            mObjectList.add(obj);
                        } catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                }
            } while (o != null);*/

            String rawData = savedInstanceState.getString("rawData");
            if (rawData != null) {
                try {
                    mRawData = new JSONObject(rawData);
                    setData(mRawData);
                    mAdapter.notifyDataSetChanged();
                } catch (JSONException e) {};
            }
        }

    }

    public void resume(){
        Log.i(TAG, "RESUME");
        try {
            JSONObject data = new JSONObject(mRawData.toString());
            setData(data);
            mAdapter.notifyDataSetChanged();
        } catch (JSONException e){};


    }

    public void onSaveInstanceState(Bundle outState){
        outState.putBoolean("checkall", mCheckAll);
        if (mRawData != null) {
            outState.putString("rawData", mRawData.toString());
        }
        /*
        for (int i = 0; i < mObjectList.size(); i++) {
            outState.putString("ol" + i, mObjectList.get(i).toString());
        }*/

        super.onSaveInstanceState(outState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.swipe_list_container, null);

        mList = (SwipeMenuListView)view.findViewById(R.id.listView);

        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {

                if (menu.getViewType() == CELL_TYPE_HEADER) return;

                int bitmask = menu.getViewType()-1;
                if ((bitmask & 1) == 1) {
                    // Immobilise
                    SwipeMenuItem item = new SwipeMenuItem(getContext());
                    item.setBackground(new ColorDrawable(ContextCompat.getColor(getActivity(), R.color.red)));
                    item.setWidth(dp2px(90));
                    item.setIcon(R.mipmap.locked);
                    menu.addMenuItem(item);
                }

                if ((bitmask & 2) == 2) {
                    // Timeframe
                    SwipeMenuItem item = new SwipeMenuItem(getContext());
                    item.setBackground(new ColorDrawable(ContextCompat.getColor(getActivity(), R.color.orange)));
                    item.setWidth(dp2px(90));
                    item.setIcon(R.mipmap.stopwatch);
                    menu.addMenuItem(item);
                }

                if ((bitmask & 4) == 4) {
                    // Deimmobilise
                    SwipeMenuItem item = new SwipeMenuItem(getContext());
                    item.setBackground(new ColorDrawable(ContextCompat.getColor(getActivity(), R.color.green)));
                    item.setWidth(dp2px(90));
                    item.setIcon(R.mipmap.unlocked);
                    menu.addMenuItem(item);
                }

            }
        };


        // set creator
        mList.setMenuCreator(creator);
        mList.setSwipeDirection(SwipeMenuListView.DIRECTION_LEFT);
        mList.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                if (menu.getViewType() == CELL_TYPE_HEADER) return false;

                int altered_position = position;
                int next_position = 0;
                for (int i=0; i<mGroupsStatus.size(); i++){
                    int offset = mGroupsCount.get(i);
                    next_position+=offset+1;
                    if (next_position>position+offset) break;
                    if (!mGroupsStatus.get(i)) {
                        // Hidden, so remove the number of items in this group
                        altered_position += offset;
                        next_position-= offset;
                    }

                }
                JSONObject o = mAdapter.getItem(altered_position);
                String encoded_cmds = "";
                try {
                    encoded_cmds = o.getString("cmds");
                } catch (JSONException e){};

                Log.i("SMS", encoded_cmds);
                byte[] cmd_bytes = Base64.decode(encoded_cmds, Base64.DEFAULT);
                String[] commands;
                String cmd_immobilise = "", cmd_timeframe = "", cmd_deimmobilise = "";
                if (cmd_bytes != null){
                    JSONObject ocntrl_data = null;
                    String json = new String(cmd_bytes);
                    Log.i("SMS", json);
                    try {
                        ocntrl_data = new JSONObject(json);
                    } catch (JSONException e){ e.printStackTrace(); };

                    command_controller.ocntrl_data = ocntrl_data;

                    String str_commands = "";
                    try {
                        str_commands = ocntrl_data.getString("commands");
                    } catch (JSONException e){};

                    commands = str_commands.split(",");

                    for (String command : commands){
                        String[] parts = command.split("~");
                        String name =  parts[0];
                        String cmd = parts[1].replace("%@", "%s");;

                        if (name.equals("Immobilise")){
                            cmd_immobilise = cmd;
                        }

                        if (name.equals("Timeframe")){
                            cmd_timeframe = cmd;
                        }

                        if (name.equals("Deimmobilise")){
                            cmd_deimmobilise = cmd;
                        }

                    }
                }

                try {
                    command_controller.name = o.getString("name");
                    command_controller.object_id = o.getString("object_id");
                } catch (JSONException e){};

                int bitmask = menu.getViewType()-1;

                int p = 8;
                while (index>=0){
                    p/=2;
                    if ((bitmask&p) == p) index--;
                }

                String message;

                switch (p){
                    case 1:
                        command_controller.command = "Deimmobilise";
                        message = cmd_deimmobilise;
                        command_controller.sendMessage(message);

                        break;
                    case 2:
                        command_controller.command = "Timeframe";
                        message = cmd_timeframe;
                        command_controller.sendMessage(message);

                        break;
                    case 4:
                        command_controller.command = "Immobilise";
                        message = cmd_immobilise;
                        command_controller.sendMessage(message);


                        break;
                }

                return false;
            }
        });
        setList();

        return view;
    }

    private int dp2px(float dp){
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }

    private void setList(){

        final Drawable contract = ContextCompat.getDrawable(getContext(), R.mipmap.contract_icon);
        final Drawable expand = ContextCompat.getDrawable(getContext(), R.mipmap.expand_icon);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String user_id = sharedPreferences.getString("user_id", "");
        String prefID = sharedPreferences.getString("prefID", user_id);

        boolean left_handed =  sharedPreferences.getBoolean("left_handed_enabled_"+prefID, false);
        final boolean immobiliser_shortcut_enabled =  sharedPreferences.getBoolean("immobiliser_shortcut_enabled_"+prefID, false);

        final int cell_layout = (left_handed) ? R.layout.object_list_item_left : R.layout.object_list_item;


        mAdapter = new ArrayAdapter<JSONObject>(getActivity(), cell_layout, mObjectList ){

            public int getAlteredPosition(int position){
                int altered_position = position;
                int next_position = 0;
                for (int i=0; i<mGroupsStatus.size(); i++){
                    int offset = mGroupsCount.get(i);
                    next_position+=offset+1;
                    if (next_position>position+offset) break;
                    if (!mGroupsStatus.get(i)) {
                        // Hidden, so remove the number of items in this group
                        altered_position += offset;
                        next_position-= offset;
                    }

                }
                return altered_position;
            }

            public int getViewTypeCount(){
                // Header + 8 (3 buttons -3 bit bitmask )
                return 9;
            }

            public int getItemViewType(int position){
                JSONObject o = getItem(getAlteredPosition(position));

                if (o.has("group_name") || o.length() == 0){
                    return 0;
                }
                // Return button bitmask +1
                int bitmask = 0;
                if (o.has("immobilisable") && immobiliser_shortcut_enabled){
                    boolean cmd_de = false, cmd_tf = false, cmd_im = false;
                    try { cmd_de = o.getBoolean("cmd_de"); } catch (JSONException e){};
                    try { cmd_tf = o.getBoolean("cmd_tf"); } catch (JSONException e){};
                    try { cmd_im = o.getBoolean("cmd_im"); } catch (JSONException e){};
                    bitmask += (cmd_de)?1:0;
                    bitmask += (cmd_tf)?2:0;
                    bitmask += (cmd_im)?4:0;
                }
                return bitmask + 1;
            }

            public int getCount(){
                int total = super.getCount();
                for (int i=0; i<mGroupsStatus.size(); i++){
                    if (!mGroupsStatus.get(i)){
                        // Hidden, so remove the number of items in this group
                        total-= mGroupsCount.get(i);
                    }
                }
                return total;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                // Get the data item for this position
                int altered_position = getAlteredPosition(position);

                JSONObject o = getItem(altered_position);

                int type = getItemViewType(position);

                if (convertView == null){
                    switch (type){
                        case 0:
                            // Header
                            convertView = LayoutInflater.from(getContext()).inflate(R.layout.object_list_group_header, parent, false);
                            break;

                        default:
                            // Object
                            convertView = LayoutInflater.from(getContext()).inflate(cell_layout, parent, false);
                            break;

                    }
                }
                if (type == CELL_TYPE_HEADER){
                    // Group Header Cell

                    TextView name = (TextView) convertView.findViewById(R.id.name);

                    String g_name = "Ungrouped";
                    try {
                        g_name = o.getString("group_name");
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Log.i("OBJECT", o.toString());
                    }

                    name.setText(g_name);

                    ImageView button_sort = (ImageView) convertView.findViewById(R.id.button_sort);
                    if (position==0){
                        button_sort.setVisibility(View.VISIBLE);
                        button_sort.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                showReorder();
                            }
                        });
                    }

                    ImageView button_hideshow = (ImageView) convertView.findViewById(R.id.button_hideshow);
                    final int group_index = mGroupsList.indexOf(g_name);
                    Log.i("PPP", "NAME = "+g_name);
                    if (group_index>=0) {
                        if (mGroupsStatus.get(group_index)) {
                            // Group is Showing (icon should be -)
                            button_hideshow.setImageDrawable(contract);
                        } else {
                            // Group is Hidden (icon should be +)
                            button_hideshow.setImageDrawable(expand);
                        }
                    }
                    button_hideshow.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            hideshowGroup((ImageView)v, group_index);
                        }
                    });
                } else {
                    // Tracker Cell

                    String g_name = "";
                    try {
                        g_name = o.getString("group");
                    } catch (JSONException e){}

                    int group_index = mGroupsList.indexOf(g_name);
                    if (group_index>=0 && group_index<mGroupsStatus.size()) {
                        if (mGroupsStatus.get(group_index)) {
                            convertView.setVisibility(View.VISIBLE);
                        } else {
                            convertView.setVisibility(View.GONE);
                            return convertView;
                        }
                    }

                    // Lookup view for data population
                    TextView name = (TextView) convertView.findViewById(R.id.name);
                    CheckBox selected = (CheckBox) convertView.findViewById(R.id.selected);
                    selected.setTag(altered_position);
                    Button disclosure = (Button) convertView.findViewById(R.id.show);
                    disclosure.setTag(altered_position);

                    // Populate the data into the template view using the data object
                    String o_name = "";
                    boolean o_selected = false;
                    try {
                        o_name = o.getString("name");
                        if (o.has("selected")) o_selected = o.getBoolean("selected");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    name.setText(o_name);
                    selected.setChecked(o_selected);
                    selected.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            // Update the model
                            int p = (int) buttonView.getTag();
                            JSONObject object = mObjectList.get(p);
                            try {
                                object.put("selected", isChecked);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                    disclosure.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Integer[] p = new Integer[1];
                            p[0] = (Integer) v.getTag();
                            Log.d(TAG, "SEL=" + p[0]);
                            showNext(p, MainActivity.VIEW_TYPE_O_CONTEXT_MENU);
                        }
                    });
                }
                // Return the completed view to render on screen
                return convertView;
            }
        };

        mList.setAdapter(mAdapter);

        ObjectListHeaderView objectListHeaderView = new ObjectListHeaderView(getActivity());
        objectListHeaderView.mCallback = this;
        objectListHeaderView.setCheckAll(mCheckAll);
        mList.addHeaderView(objectListHeaderView);


    }

    private void setData(JSONObject data){

        JSONArray objects = null;
        JSONArray groups = null;
        ArrayList<String> arr_groups = new ArrayList<>();
        mGroupsList = new ArrayList<>();
        while (mObjectList.size()>0) mObjectList.remove(0);
        mGroupsCount = new ArrayList<>();

        if (data != null) {
            try {
                objects = data.getJSONArray("data");
                groups = data.getJSONArray("groups");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (objects != null) {
            Log.i("PPP", "OBJECTS");
            String previous_group = "";
            String name = "";
            Integer counter = 0;
            boolean skip = true;
            for (int i = 0; i < objects.length(); i++) {
                JSONObject object = null;
                try {
                    object = objects.getJSONObject(i);
                    if (object != null) {
                        String group = object.getString("group_id");
                        if (!group.equals(previous_group)) {
                            previous_group = group;
                            if (group.equals("0")) {
                                name = "Ungrouped";
                                JSONObject ungrouped = new JSONObject();
                                ungrouped.put("group_name", name);
                                mObjectList.add(ungrouped);
                            } else {
                                for (int j = 0; j < groups.length(); j++) {
                                    JSONObject gname = groups.getJSONObject(j);
                                    if (gname.getString("group_id").equals(previous_group)) {
                                        mObjectList.add(gname);
                                        name = gname.getString("group_name");
                                    }
                                }
                            }
                            arr_groups.add(name);
                            mGroupsList.add(name); // Set Groups list as a default if no order hasbeen set yet
                            if (!skip)
                                mGroupsCount.add(counter);
                            skip = false;
                            counter = 0;
                        }
                        object.put("group", name);
                        mObjectList.add(object);
                        counter++;

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
            mGroupsCount.add(counter);

            for (int i = 0; i < mObjectList.size(); i++) {
                try {
                    Log.i("PPP", "ARR(PRE):" + mObjectList.get(i).getString("name"));
                } catch (JSONException e){
                    Log.i("PPP", "ARR(PRE):***");
                };
            }
            Log.i("PPP", "ARR(PRE)---");

            Log.i("PPP", "mGroupsList (Natural): "+mGroupsList.toString());


            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
            String user_id = sharedPreferences.getString("user_id", "");
            String str_groups_list =  sharedPreferences.getString("group_names_order_"+user_id, null);
            if (str_groups_list != null) {
                Log.i("PPP", "strGroupsList: "+str_groups_list);
                mGroupsList = new ArrayList<>(Arrays.asList(str_groups_list.split("\\|\\|\\|")));
                Log.i("PPP", "mGroupsList: "+mGroupsList.toString());
                for (int i=0; i<mGroupsList.size(); i++){
                    int sourceIndex = arr_groups.indexOf(mGroupsList.get(i));
                    if (sourceIndex>=0){
                        groups = this.reorderArray(groups, sourceIndex,i);
                        mObjectList = this.reorderObjects(mObjectList, sourceIndex, i);
                        arr_groups = this.reorderString(arr_groups, sourceIndex, i);
                        mGroupsCount = this.reorderInteger(mGroupsCount, sourceIndex, i);
                    }
                }

            }

            // Initialise the status (hidden/shown) array
            mGroupsStatus = new ArrayList<>();
            mGroupsStatus.add(true);
            String str_group_status =  sharedPreferences.getString("group_status_"+user_id, null);
            if (str_group_status != null) {
                mGroupsStatus = new ArrayList<>();
                for (int i=0; i<str_group_status.length(); i++){
                    mGroupsStatus.add((str_group_status.charAt(i) == 49)); // Ascii 49 = (String) "1" = (Boolean) true
                }
            }

            // Add new items to the end if required
            if (mGroupsStatus.size() < mGroupsList.size()){
                for (int i=mGroupsStatus.size(); i<mGroupsList.size(); i++){
                    mGroupsStatus.add(true);
                }
            }

            Log.i("PPP", "NAMES:"+mGroupsList.toString());
            Log.i("PPP", "COUNTS:"+mGroupsCount.toString());
            Log.i("PPP", "STATUS:"+mGroupsStatus.toString());

            for (int i = 0; i < mObjectList.size(); i++) {
                try {
                    Log.i("PPP", "ARR(FINAL):" + mObjectList.get(i).getString("name"));
                } catch (JSONException e){
                    Log.i("PPP", "ARR(FINAL):***");
                };
            }
            Log.i("PPP", "ARR(FINAL)---");

        }
    }

    private ArrayList<String> reorderString(ArrayList<String> arr, int src, int dst) {
        if (src == dst) return arr;

        String tmp = arr.get(dst);
        arr.set(dst, arr.get(src));
        arr.set(src, tmp);

        return arr;
    }

    private ArrayList<Integer> reorderInteger(ArrayList<Integer> arr, int src, int dst) {
        if (src == dst) return arr;

        Integer tmp = arr.get(dst);
        arr.set(dst, arr.get(src));
        arr.set(src, tmp);

        return arr;
    }

    private ArrayList<JSONObject> reorderObjects(ArrayList<JSONObject> arr, int src, int dst){
        if (src == dst) return arr;
        if (dst>src){
            // Swap to normalise order (dst, src)
            int tmp = dst;
            dst = src;
            src = tmp;
        }

        ArrayList<JSONObject> tmp = new ArrayList<>();
        int src_count = mGroupsCount.get(src);
        int src_offset = 0;

        for (int i=0; i<src; i++){
            src_offset+= mGroupsCount.get(i)+1;
        }

        int dst_count = mGroupsCount.get(dst);
        int dst_offset = 0;

        for (int i=0; i<dst; i++){
            dst_offset+= mGroupsCount.get(i)+1;
        }


        // Save dst...src to tmp
        for (int i=dst_offset; i<=src_offset+src_count; i++){
            tmp.add(arr.get(i));
        }

        // Start replacing from src (end)
        int cursor = src_offset - dst_offset;
        for (int i=dst_offset; i<=src_offset+src_count; i++) {
            arr.set(i, tmp.get(cursor++));
            if (cursor == tmp.size()) cursor = dst_count + 1; // When end is reached copy the middle
            if (cursor == src_offset - dst_offset) cursor = 0; // Finally copy the start
        }

        return arr;
    }

    private JSONArray reorderArray(JSONArray arr, int src, int dst){
        if (src == dst) return arr;

        try {
            Object tmp = arr.get(dst);
            arr.put(dst, arr.get(src));
        } catch (JSONException e){
            e.printStackTrace();
        }

        return arr;
    }

    @Override
    public void onStart(){
        super.onStart();

    }

    @Override
    public void onResume(){
        super.onResume();

        command_controller = new CommandController();
        command_controller.mContext = this;
        command_controller.delegate = (MainActivity)getActivity();
    }

    public void onAPISuccess(String request, JSONObject data){
        if (request.equals(API.API_GET_OBJECTS)) {
            try {
                mRawData = new JSONObject(data.toString());
                setData(data);
                mAdapter.notifyDataSetChanged();
            } catch (JSONException e){};
        }
    }

    public void onAPIError(String request, JSONObject data){
        Log.d(TAG, "Error: " + request);

    }

    public void onCheckAll(boolean checked) {
        mCheckAll = checked;

        for (int i=0; i<mObjectList.size(); i++){
            JSONObject object = mObjectList.get(i);
            try {
                object.put("selected", checked);
            } catch (JSONException e){
                e.printStackTrace();
            }
        }
        mAdapter.notifyDataSetChanged();
    }

    public void onShowSelected(){
        List<Integer> position = new ArrayList<>();
        boolean selected;
        boolean hidden = false;
        int c = 0;
        int group_index = 0;
        for (int i=0; i<mObjectList.size(); i++){
            selected = false;
            JSONObject o = mObjectList.get(i);
            if (o.has("group_name") || o.length() == 0) {
                hidden = !mGroupsStatus.get(group_index++);
                c++;
            } else {
                try {
                    if (o.has("selected")) selected = (!hidden) && o.getBoolean("selected");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (selected) {
                    position.add(c);
                }
                c++;
            }
        }
        if (position.size()>0) {
            showNext(position.toArray(new Integer[position.size()]), MainActivity.VIEW_TYPE_MAP);
        } else {
            new AlertDialog.Builder(getActivity())
                    .setTitle("No Objects Chosen")
                    .setMessage("Please tick the boxes on the left to select which object to view, or select a single object using the arrows on the right.")
                    .setNeutralButton("OK", null)
                    .create().show();
        }
     }

    private void showNext(Integer[] position, int nextViewType){
        String title = "";
        String oldest_date = "";
        String[] ids = new String[position.length];

        int next = 0;
        String id = "";
        JSONObject o = null;
        for (int p : position){
            o = mObjectList.get(p);
            try {
                id = o.getString("object_id");
                if (next == 0) title = o.getString("name");
                if (next == 0) oldest_date = o.getString("oldest_data");
            } catch (JSONException e){
                e.printStackTrace();
            }
            if (id != null) ids[next++] = id;
        }

        if (position.length>1){
            title = String.format("%s Objects", position.length);
        }

        if (nextViewType == MainActivity.VIEW_TYPE_MAP) {
            ((MainActivity) getActivity()).showRealtimeMap(ids, title, oldest_date);
        } else if (nextViewType == MainActivity.VIEW_TYPE_O_CONTEXT_MENU){
            ((MainActivity)getActivity()).showContextMenu(ids, title, oldest_date, o);
        }
    }

    private void showReorder(){
        ((MainActivity)getActivity()).showReorderGroups(mGroupsList, mGroupsStatus, "");
    }

    private void hideshowGroup(ImageView button, int index){
        Drawable contract = ContextCompat.getDrawable(getContext(), R.mipmap.contract_icon);
        Drawable expand = ContextCompat.getDrawable(getContext(), R.mipmap.expand_icon);

        if (mGroupsStatus.get(index)){
            mGroupsStatus.set(index, false);
            // Group is Showing (icon should be -)
            button.setImageDrawable(expand);
        } else {
            mGroupsStatus.set(index, true);
            // Group is Hidden (icon should be +)
            button.setImageDrawable(contract);
        }

        mAdapter.notifyDataSetChanged();

        // Save to Prefs as string of zeros (false) and ones (true)
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String user_id = sharedPreferences.getString("user_id", "");
        String prefID = sharedPreferences.getString("prefID", user_id);
        SharedPreferences.Editor e = sharedPreferences.edit();
        String str_status = "";
        for (int i=0; i<mGroupsStatus.size(); i++){
            str_status+= (mGroupsStatus.get(i))?"1":"0";
        }
        e.putString("group_status_"+user_id, str_status);
        //e.remove("group_names_order_"+user_id);
        e.apply();
    }
}
