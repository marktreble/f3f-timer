package com.extravision.tracking.Managers;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Log;

import com.extravision.tracking.MainActivity;
import com.extravision.tracking.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by marktreble on 02/06/2017.
 */

public class CommandController {

    private static String TAG = "CommandController";

    public JSONObject ocntrl_data;
    public String name;
    public String object_id;
    public String command;
    public String message;
    public String number;
    public String svc_operator;

    public Fragment mContext;
    public MainActivity delegate;

    private API mAPITask = null;

    public static final int SMS_PERMISSION_GRANTED = 2;

    public void sendMessage(String command){
        String val_operator="", val_username="", val_password="";
        try {
            val_operator = ocntrl_data.getString("operator");
            val_username = ocntrl_data.getString("username");
            val_password = ocntrl_data.getString("username");

            number = ocntrl_data.getString("number");
        } catch (JSONException e){};

        String[] commands = TextUtils.split(command, ";");
        for (int i=0;i<commands.length; i++){
            commands[i] = String.format(commands[i], val_username, val_password).trim();
        }
        message = TextUtils.join(";", commands);

        Log.i("CMD", message + " to " + number + " via " + val_operator);

        /* DEP
        if (val_operator.equals("1")){
            if (!val_username.equals("")
            && !val_password.equals("")
            && !number.equals("")){
                new AlertDialog.Builder(delegate)
                        .setTitle(delegate.getString(R.string.app_name))
                        .setMessage(String.format("Are you sure you want send %s to %s?", this.command, name))
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Log.i("SMS", "CLICKED CANCEL!");
                            }
                        })
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Log.i("SMS", "CLICKED YES!");
                                sendSMS();
                            }
                        })
                        .create().show();


            } else {
                commandDetailsNotSet();
            }
        } else

        */
        if (val_operator.equals("2")){
            if (!val_username.equals("")
                && !val_password.equals("")
                && !number.equals("")){

                new AlertDialog.Builder(delegate)
                        .setTitle(delegate.getString(R.string.app_name))
                        .setMessage(String.format("Are you sure you want send %s to %s?", this.command, name))
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        })
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                sendAeris();
                            }
                        })
                        .create().show();

            } else {
                commandDetailsNotSet();
            }
        } else

        if (val_operator.equals("3")){
            commands = TextUtils.split(command, ";");
            for (int i=0;i<commands.length; i++){
                commands[i] = String.format(commands[i], "", "").trim();
            }
            message = TextUtils.join(";", commands);

            new AlertDialog.Builder(delegate)
                    .setTitle(delegate.getString(R.string.app_name))
                    .setMessage(String.format("Are you sure you want send %s to %s?", this.command, name))
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    })
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            sendGPRS();
                        }
                    })
                    .create().show();
        } else

        if (val_operator.equals("4")){
            if (!val_username.equals("")
                    && !val_password.equals("")
                    && !number.equals("")){

                new AlertDialog.Builder(delegate)
                        .setTitle(delegate.getString(R.string.app_name))
                        .setMessage(String.format("Are you sure you want send %s to %s?", this.command, name))
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        })
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                sendDataSIM();
                            }
                        })
                        .create().show();

            } else {
                commandDetailsNotSet();
            }
        } else {


                commandDetailsNotSet();
        }

    }

    public void commandDetailsNotSet(){
        new AlertDialog.Builder(delegate)
                .setTitle(delegate.getString(R.string.app_name))
                .setMessage("Command could not be sent. Please check the configuration for this tracker")
                .create().show();
    }

    /* DEP
    public void sendSMS(){
        Log.i(TAG, "sendSMS");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (delegate.checkSelfPermission(Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // permission is not granted, ask for permission:
                delegate.mPermissionRequested = true;
                mContext.requestPermissions(new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_GRANTED);
            } else {
                sendSMSFromDevice();
            }
        } else {
            sendSMSFromDevice();
        }

    }
    */

    /* DEP
    public void sendSMSFromDevice(){
        delegate.showSMSSending();

        String[] messages = TextUtils.split(message, ";");
        String cmd = messages[0];
        String[] msgs = Arrays.copyOfRange(messages, 1, messages.length);
        message = TextUtils.join(";", msgs);

        SmsManager sms = SmsManager.getDefault();
        Intent sentIntent = new Intent("SMS_SENT");
        PendingIntent piSent = PendingIntent.getBroadcast(delegate, 0, sentIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        Intent deliveredIntent = new Intent("SMS_DELIVERED");
        PendingIntent piDelivered = PendingIntent.getBroadcast(delegate, 0, deliveredIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        sms.sendTextMessage(number, null, cmd, piSent, piDelivered);
        Log.i(TAG, "sendSMS: "+cmd);

        if (message.length()>0){
            sendSMSFromDevice();
        }
    }
    */

    public void sendAeris(){
        delegate.showSMSSending();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(delegate);
        String token = preferences.getString("token", null);

        String val_username;
        String val_password;
        try {

            val_username = ocntrl_data.getString("username");
            val_password = ocntrl_data.getString("username");

        } catch (JSONException e){
            e.printStackTrace();
            return;
        }

        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_SEND_AERIS_COMMAND);
        params.put("t", token);
        params.put("m", message);
        params.put("n", number);
        params.put("id", object_id);
        params.put("a", String.format("%s:%s", val_username, val_password));

        mAPITask = new API();
        mAPITask.mCallback = delegate;
        mAPITask.request = API.API_SEND_AERIS_COMMAND;
        mAPITask.makeAPICall(delegate, API.httpmethod.GET, params);
    }

    public void sendGPRS(){
        delegate.showSMSSending();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(delegate);
        String token = preferences.getString("token", null);

        String val_username;
        String val_password;

        try {

            val_username = ocntrl_data.getString("username");
            val_password = ocntrl_data.getString("username");

        } catch (JSONException e){
            Log.i(TAG, ocntrl_data.toString());
            e.printStackTrace();
            return;
        }

        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_SEND_GPRS_COMMAND);
        params.put("t", token);
        params.put("m", message);
        params.put("id", object_id);
        params.put("a", String.format("%s:%s", val_username, val_password));

        mAPITask = new API();
        mAPITask.mCallback = delegate;
        mAPITask.request = API.API_SEND_GPRS_COMMAND;
        mAPITask.makeAPICall(delegate, API.httpmethod.GET, params);
    }

    public void sendDataSIM(){
        delegate.showSMSSending();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(delegate);
        String token = preferences.getString("token", null);

        String val_username;
        String val_password;
        try {

            val_username = ocntrl_data.getString("username");
            val_password = ocntrl_data.getString("username");

        } catch (JSONException e){
            e.printStackTrace();
            return;
        }

        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_SEND_DATASIM_COMMAND);
        params.put("t", token);
        params.put("m", message);
        params.put("n", number);
        params.put("id", object_id);
        params.put("a", String.format("%s:%s", val_username, val_password));

        mAPITask = new API();
        mAPITask.mCallback = delegate;
        mAPITask.request = API.API_SEND_DATASIM_COMMAND;
        mAPITask.makeAPICall(delegate, API.httpmethod.GET, params);
    }
}
