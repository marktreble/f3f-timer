package com.extravision.tracking;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.SharedPreferencesCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.extravision.tracking.Dialogs.PinDialog;
import com.extravision.tracking.Managers.API;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by marktreble on 05/12/2017.
 */

public class SuperAdminActivity extends AppCompatActivity
        implements API.APICallbackInterface {

    private API mAuthTask = null;

    private Context mContext;
    private ListView mList;
    private ListAdapter mAdapter;
    private ArrayList<JSONObject> mUsersList;
    private JSONArray mUsers;

    private View mProgressView;

    private String mUsername;
    private String mPassword;
    private String mDeviceId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_superadmin);
        mContext = this;

        mProgressView = findViewById(R.id.login_progress);
        EditText searchbar = (EditText)findViewById(R.id.searchbar);
        mList = (ListView)findViewById(R.id.userlist);

        searchbar.setHint("\uD83D\uDD0D Search");

        searchbar.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                // TODO Auto-generated method stub
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                // TODO Auto-generated method stub
            }

            @Override
            public void afterTextChanged(Editable s) {

                final String searchterm = s.toString().trim();
                new Handler().post(new Runnable() {
                    @Override
                    public void run() {
                        ArrayList <JSONObject> filtered_list = getObjectsFilteredBy(searchterm);

                        while (mUsersList.size()>filtered_list.size()){
                            mUsersList.remove(0);
                        }
                        while (mUsersList.size()<filtered_list.size()){
                            mUsersList.add(new JSONObject());
                        }
                        for (int i = 0; i < filtered_list.size(); i++){
                            mUsersList.set(i, filtered_list.get(i));
                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                ((BaseAdapter)mAdapter).notifyDataSetChanged();
                            }
                        });
                    }
                });

            }
        });

        Intent i = getIntent();
        String str_users = i.getStringExtra("users");
        mUsername = i.getStringExtra("username");
        mPassword = i.getStringExtra("password");
        mDeviceId = i.getStringExtra("deviceId");

        mUsersList = new ArrayList<>();
        try {
           mUsers = new JSONArray(str_users);
            mUsersList = getObjectsFilteredBy("");
        } catch (JSONException e){
            e.printStackTrace();
        }

        setList();
    }

    private void setList(){

        mAdapter = new ArrayAdapter<JSONObject>(mContext, R.layout.userlist, mUsersList ){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the data item for this position
                JSONObject o = getItem(position);
                // Check if an existing view is being reused, otherwise inflate the view
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.userlist, parent, false);
                }
                // Lookup view for data population
                TextView username = (TextView) convertView.findViewById(R.id.user);

                // Populate the data into the template view using the data object
                String o_username = "";
                String o_id = "";

                try {
                    o_username = o.getString("username");
                    o_id = o.getString("id");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                username.setText(o_username);

                convertView.setTag(o_id);
                convertView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String id = (String)v.getTag();

                        superAdminLogin(id);
                    }
                });
                // Return the completed view to render on screen
                return convertView;
            }
        };

        mList.setAdapter(mAdapter);


    }

    private ArrayList<JSONObject> getObjectsFilteredBy(String searchterm){
        ArrayList<JSONObject> list = new ArrayList<>();
        for (int i=0; i<mUsers.length(); i++){
            try {
                JSONObject user = (JSONObject)mUsers.get(i);
                String username = user.getString("username").toLowerCase();

                if (searchterm.equals("")){
                    list.add(user);
                } else if (username.contains(searchterm.toLowerCase())){
                    list.add(user);

                }
            } catch (JSONException e){
                e.printStackTrace();
            }

        }

        return list;
    }

    private void superAdminLogin(String id){
        showProgress(true);

        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_LOGIN);
        params.put("u", mUsername);
        params.put("d", mDeviceId);
        params.put("p", mPassword);
        params.put("su", id);

        mAuthTask = new API();
        mAuthTask.mCallback = this;
        mAuthTask.request = API.API_LOGIN;
        mAuthTask.makeAPICall(mContext, API.httpmethod.GET, params);
    }

    public void onAPISuccess(String request, JSONObject data) {
        mAuthTask = null;
        showProgress(false);

        String type = "";
        String token = "";
        String user_id = "";
        String zones = "";
        String notifications ="";
        JSONArray users;
        try {
            type = data.getString("type");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (type.equals("user")) {
            try {
                token = data.getString("token");
                user_id = data.getString("user_id");
                zones = data.getString("zones");
                notifications = data.getString("notifications");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("token", token);
            editor.putString("user_id", user_id);
            editor.putString("zones", zones);
            editor.putString("notifications", notifications);
            SharedPreferencesCompat.EditorCompat.getInstance().apply(editor);

            loginSuccess(false, null); // Don't need to ask for pin
            finish();
        }
    }

    public void onAPIError(String request, JSONObject data) {
        mAuthTask = null;
        showProgress(false);
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mList.setVisibility(show ? View.GONE : View.VISIBLE);
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mList.setVisibility(show ? View.GONE : View.VISIBLE);
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
        }
    }

    private void loginSuccess(boolean pin_enabled, String pin) {
        Intent i = new Intent(mContext, MainActivity.class);
        startActivity(i);
        overridePendingTransition(R.anim.slide_in_right,
                R.anim.zoom_fade_exit);
        finish();
    }

}
