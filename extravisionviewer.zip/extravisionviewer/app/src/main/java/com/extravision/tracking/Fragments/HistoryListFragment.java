package com.extravision.tracking.Fragments;

import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.extravision.tracking.Dialogs.HistorySettingsDialog;
import com.extravision.tracking.Dialogs.InfoDialog;
import com.extravision.tracking.EVHistoryListActivity;
import com.extravision.tracking.MainActivity;
import com.extravision.tracking.Managers.API;
import com.extravision.tracking.Managers.RGeocode;
import com.extravision.tracking.R;
import com.extravision.tracking.Views.HistoryListHeaderView;

/**
 * Created by marktreble on 04/01/2016.
 */
public class HistoryListFragment extends Fragment
        implements API.APICallbackInterface, HistorySettingsDialog.HistorySettingsDialogListener {

    private static final String TAG = "HistoryListFragment";

    private ListView mList;
    private ArrayList<JSONObject> mHistoryList;
    private Map<String,String> mLocationCache;
    private ArrayAdapter<JSONObject> mAdapter;

    public MainActivity delegate;

    private String mToken;
    private String mIds;
    private String mOldest_date;
    private String mTitle;

    public String mDate;
    public boolean mHideRoute;
    public boolean mHideStops;
    public boolean mHideEvents;
    public boolean mHideArrows;
    public boolean mHideJourneyUpdates;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "ONCREATE");


        if (savedInstanceState == null) {
            mHistoryList = new ArrayList<>();
            mLocationCache = new HashMap<>();
        } else {
            // Restore the waypoints arrays
            mHistoryList = new ArrayList<>();
            Object o;
            int counter = 0;
            do {
                o = null;
                if (savedInstanceState.containsKey("ol"+counter)) {
                    o = savedInstanceState.getString("ol" + counter++);
                    if (o != null){
                        try {
                            JSONObject obj = new JSONObject((String) o);
                            mHistoryList.add(obj);
                        } catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                }
            } while (o != null);
        }

    }

    public void setParams(String token, String ids, String title, String oldest_date){
        mToken = token;
        mIds = ids;
        mTitle = title;
        mOldest_date = oldest_date;

        Log.d(TAG, "OLDEST DATE = "+mOldest_date);
    }

    public void onSaveInstanceState(Bundle outState){
        for (int i = 0; i < mHistoryList.size(); i++) {
            outState.putString("ol" + i, mHistoryList.get(i).toString());
        }


        super.onSaveInstanceState(outState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_container, null);

        TextView title = (TextView)view.findViewById(R.id.title);
        title.setText(mTitle);

        mList = (ListView)view.findViewById(R.id.list);
        getHistorySettings();
        setList();
        

        return view;
    }

    private void setList(){


        mAdapter = new ArrayAdapter<JSONObject>(getActivity(), R.layout.history_list_item, mHistoryList ){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the data item for this position
                JSONObject o = getItem(position);
                // Check if an existing view is being reused, otherwise inflate the view
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.history_list_item, parent, false);
                }
                // Lookup view for data population
                ImageView icon = (ImageView) convertView.findViewById(R.id.icon);
                TextView time = (TextView) convertView.findViewById(R.id.time);
                TextView information = (TextView) convertView.findViewById(R.id.information);
                TextView location = (TextView) convertView.findViewById(R.id.location);
                Button disclosure = (Button) convertView.findViewById(R.id.show);
                disclosure.setTag(position);

                // Populate the data into the template view using the data object
                String o_icon = "";
                String o_time = "";
                String o_information = "";
                String o_location = "";
                String data = "";

                try {
                    o_icon = o.getString("icon");
                    o_time = o.getString("time");
                    o_information = o.getString("info");
                    data = o.getString("data");
                    o_location = o.getString("Position");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                try {
                    icon.setImageDrawable(ContextCompat.getDrawable(getActivity(), getResources().getIdentifier(o_icon, "mipmap", getActivity().getApplication().getPackageName())));
                } catch (Resources.NotFoundException e){
                    icon.setImageDrawable(null);
                }
                time.setText(o_time);
                information.setText(o_information);
                disclosure.setVisibility(View.GONE);

                boolean isHidden = false;
                if (o_icon.equals("route_stop") && mHideStops) isHidden = true;
                if (o_icon.equals("route_event") && mHideEvents) isHidden = true;
                if (o_icon.equals("route_update") && mHideJourneyUpdates) isHidden = true;

                if (isHidden){
                    convertView.setVisibility(View.GONE);
                    convertView.setLayoutParams(new AbsListView.LayoutParams(-1,1));
                } else {
                    convertView.setVisibility(View.VISIBLE);
                    convertView.setLayoutParams(new AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT, AbsListView.LayoutParams.WRAP_CONTENT));

                    location.setText("");
                    if (!o_location.equals("")) {
                        Log.i(TAG, o_location);
                        // Check if this location has been cached
                        if (mLocationCache.containsKey(o_location)) {
                            //Log.i(TAG, "Cached: " + mLocationCache.get(o_location));
                            location.setText(mLocationCache.get(o_location));
                        } else {
                            //Log.i(TAG, "FETCHING FROM GEOCODER for "+o_name);
                            // No - Call the Geocoder, and cache the result for later
                            String[] latlng = o_location.split(",");
                            double lat = Double.parseDouble(latlng[0]);
                            double lng = Double.parseDouble(latlng[1]);
                            RGeocode.LocationReceiver location_received = new RGeocode().new LocationReceiver() {

                                @Override
                                public void run() {
                                    mLocationCache.put(mLatLng, mAddress);
                                }
                            };

                            location_received.mLatLng = o_location;
                            RGeocode r = new RGeocode(getActivity(), lat, lng, location, location_received);
                            r.mDelimiter = ", ";

                            new Thread(r).start();
                        }
                    }

                }

                /* Not Used - maybe in future
                disclosure.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer[] position = new Integer[1];
                        position[0] = (Integer) v.getTag();

                    }
                });*/

                convertView.setTag(o);
                convertView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showMap(v);

                    }
                });
                // Return the completed view to render on screen
                return convertView;
            }
        };

        mList.setAdapter(mAdapter);

        HistoryListHeaderView historyListHeaderView = new HistoryListHeaderView(getActivity());
        mList.addHeaderView(historyListHeaderView);


    }

    private void showDetails(View v){
        String m = (String)v.getTag();
        if (m == null) return;
        if (m.equals("")) return;
        if (m.equals("[]")) return;


        FragmentManager fm = getActivity().getSupportFragmentManager();
        if (fm.findFragmentByTag(EVHistoryListActivity.INFO_DIALOG) == null) {
            final InfoDialog lDialog = InfoDialog.newInstance(m);
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, EVHistoryListActivity.INFO_DIALOG).commitAllowingStateLoss();
        }
    }

    private void showMap(View v){
        JSONObject o = (JSONObject)v.getTag();
        if (o == null) return;

        String o_icon = "";

        try {
            o_icon = o.getString("icon");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (o_icon.equals("route_start")
        || o_icon.equals("route_stop")
        || o_icon.equals("route_event")
        || o_icon.equals("route_update")
        || o_icon.equals("route_end")) {
            String[] ids = TextUtils.split(mIds, ",");
            ((MainActivity)getActivity()).showHistoryMapAtLocation(o, ids, mTitle, mOldest_date);

        }
    }

    private void setData(JSONObject data){
        JSONArray objects = null;
        if (data != null) {
            try {
                objects = data.getJSONArray("data");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (objects != null) {

            // Append items
            for (int i = 0; i < objects.length(); i++) {
                JSONObject object = null;
                try {
                    object = objects.getJSONObject(i);
                    if (object != null) {
                        mHistoryList.add(object);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }
        delegate.mData = data;
    }

    @Override
    public void onStart(){
        super.onStart();

    }

    public void onAPISuccess(String request, JSONObject data){
        Log.d(TAG, "ONAPISUCCESS");
        if (request.equals(API.API_GET_HISTORY)) {
            setData(data);
            mAdapter.notifyDataSetChanged();
        }
    }

    public void onAPIError(String request, JSONObject data){
        Log.d(TAG, "Error: " + request);
        new AlertDialog.Builder(getActivity())
                .setTitle("No History Available")
                .setMessage("No history is available. Please try a different date")
                .create().show();
    }

    public void onHistorySettingsChanged(){
        getHistorySettings();
        mAdapter.notifyDataSetChanged();
    }

    private void getHistorySettings(){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        mHideRoute = !preferences.getBoolean("show_route", true);
        mHideStops = !preferences.getBoolean("show_stops", true);
        mHideEvents = !preferences.getBoolean("show_events", true);
        mHideJourneyUpdates = !preferences.getBoolean("show_journey_updates", true);
        if (!mDate.equals(preferences.getString("show_date", "today"))){
            // Change of date
            // Truncate the array and clear the view
            mList.scrollTo(0,0);
            while (mHistoryList.size()>0)
                mHistoryList.remove(0);

            mAdapter.notifyDataSetChanged();

            delegate.getHistory(this);
        }

    }

}
