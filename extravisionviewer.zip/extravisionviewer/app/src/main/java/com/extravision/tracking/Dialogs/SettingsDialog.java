package com.extravision.tracking.Dialogs;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.DialogFragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.extravision.tracking.Managers.API;
import com.extravision.tracking.R;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by marktreble on 06/01/2016.
 */
public class SettingsDialog extends DialogFragment {

    private ViewGroup mView;
    private boolean mPinValid;

    private String user_id;
    private String prefID;

    private DialogFragment mFragment;

    public static SettingsDialog newInstance() {

        SettingsDialog settingsDialog = new SettingsDialog();
        return settingsDialog;
    }

    public interface SettingsDialogListener {

        void onSettingsChanged();
    }

    public SettingsDialogListener mListener;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(STYLE_NO_TITLE);
        mView = (ViewGroup)inflater.inflate(R.layout.settings_dialog, null);

        mFragment = this;
        setCancelable(false);

        Button ok = (Button)mView.findViewById(R.id.btn_ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.onCancel(getDialog());
            }
        });

        ImageView close = (ImageView)mView.findViewById(R.id.close_btn);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.onCancel(getDialog());
            }
        });

        CheckBox enable_pin = (CheckBox)mView.findViewById(R.id.enable_pin);
        ViewGroup pin_entry = (ViewGroup)mView.findViewById(R.id.pin_entry);
        EditText pin_number = (EditText)mView.findViewById(R.id.pin_number);
        //CheckBox enable_push = (CheckBox)mView.findViewById(R.id.enable_push);
        CheckBox enable_layout_full = (CheckBox)mView.findViewById(R.id.enable_layout_full);
        CheckBox enable_immobiliser_status = (CheckBox)mView.findViewById(R.id.enable_immobiliser_status);
        CheckBox enable_immobiliser_shortcut = (CheckBox)mView.findViewById(R.id.enable_immobiliser_shortcut);
        CheckBox enable_left_handed = (CheckBox)mView.findViewById(R.id.enable_left_handed);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        user_id = sharedPreferences.getString("user_id", "");
        prefID = sharedPreferences.getString("prefID", user_id);
        boolean pin_enabled = sharedPreferences.getBoolean("pin_enabled_"+prefID, false);
        String pin = sharedPreferences.getString("pin_number_"+prefID, "");
        pin_number.setText(pin);
        mPinValid =  (pin.length()==4);


        pin_number.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mPinValid = (s.length() == 4);
            }

            @Override
            public void afterTextChanged(Editable s) {
                validate();
            }
        });

        if (pin_enabled) {
            enable_pin.setChecked(true);
            pin_entry.setVisibility(View.VISIBLE);
        } else {
            enable_pin.setChecked(false);
            pin_entry.setVisibility(View.GONE);
        }

        enable_pin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ViewGroup pin_entry = (ViewGroup) mView.findViewById(R.id.pin_entry);

                if (isChecked) {
                    pin_entry.setVisibility(View.VISIBLE);

                } else {
                    pin_entry.setVisibility(View.GONE);
                }
                validate();
            }
        });

        validate();

        //boolean notify = sharedPreferences.getBoolean("push_enabled_"+prefID, false);
        //enable_push.setChecked(notify);

        boolean layout_full = sharedPreferences.getBoolean("layout_full_enabled_"+prefID, false);
        enable_layout_full.setChecked(layout_full);

        boolean immobiliser_status = sharedPreferences.getBoolean("immobiliser_status_enabled_"+prefID, false);
        enable_immobiliser_status.setChecked(immobiliser_status);

        boolean immobiliser_shortcut = sharedPreferences.getBoolean("immobiliser_shortcut_enabled_"+prefID, false);
        enable_immobiliser_shortcut.setChecked(immobiliser_shortcut);

        boolean left_handed_enabled = sharedPreferences.getBoolean("left_handed_enabled_"+prefID, false);
        enable_left_handed.setChecked(left_handed_enabled);

        return mView;
    }

    public void validate(){
        CheckBox enable_pin = (CheckBox)mView.findViewById(R.id.enable_pin);

        setCancelable(!enable_pin.isChecked() || mPinValid);
    }

    @Override
    public void onStart() {
        super.onStart();

        if (getDialog() == null)
            return;

        getDialog().getWindow().setWindowAnimations(R.style.slide);

        getDialog().getWindow().setGravity(Gravity.CENTER);

        int screenWidth = (int) getResources().getDisplayMetrics().widthPixels;
        getDialog().getWindow().setLayout(screenWidth,
                RelativeLayout.LayoutParams.WRAP_CONTENT);

        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        CheckBox enable_pin = (CheckBox)mView.findViewById(R.id.enable_pin);
        EditText pin_number = (EditText)mView.findViewById(R.id.pin_number);
        //CheckBox enable_push = (CheckBox)mView.findViewById(R.id.enable_push);
        CheckBox enable_layout_full = (CheckBox)mView.findViewById(R.id.enable_layout_full);
        CheckBox enable_immobiliser_status = (CheckBox)mView.findViewById(R.id.enable_immobiliser_status);
        CheckBox enable_immobiliser_shortcut = (CheckBox)mView.findViewById(R.id.enable_immobiliser_shortcut);
        CheckBox enable_left_handed = (CheckBox)mView.findViewById(R.id.enable_left_handed);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        /*
        boolean enabled = sharedPreferences.getBoolean("push_enabled_"+ prefID, false);
        if (enable_push.isChecked() != enabled){
            // update api
            String ptoken = sharedPreferences.getString("ptoken", null);
            String token = sharedPreferences.getString("token", null);
            String device = sharedPreferences.getString("device_id", null);
            Map<String, String> params = new HashMap<>();
            params.put(API.ENDPOINT_KEY, API.API_SAVE_PUSH_TOKEN);
            params.put("t", token);
            params.put("d", device);
            params.put("tp", "And");
            params.put("p", (enable_push.isChecked()) ? ptoken : "");

            API apitask = new API();
            apitask.request = API.API_SAVE_PUSH_TOKEN;
            apitask.makeAPICall(getActivity(), API.httpmethod.GET, params);
        }*/
        sharedPreferences.edit()
                .putBoolean("pin_enabled_"+prefID, enable_pin.isChecked())
                .putString("pin_number_" + prefID, pin_number.getText().toString())
               // .putBoolean("push_enabled_" + prefID, enable_push.isChecked())
                .putBoolean("layout_full_enabled_" + prefID, enable_layout_full.isChecked())
                .putBoolean("immobiliser_status_enabled_" + prefID, enable_immobiliser_status.isChecked())
                .putBoolean("immobiliser_shortcut_enabled_" + prefID, enable_immobiliser_shortcut.isChecked())
                .putBoolean("left_handed_enabled_" + prefID, enable_left_handed.isChecked())
                .apply();

        if (mListener != null)
            mListener.onSettingsChanged();

        super.onCancel(dialog);
        mFragment.dismissAllowingStateLoss();

    }

    @Override
    public void onDismiss(DialogInterface dialog){


        super.onDismiss(dialog);
    }
}
