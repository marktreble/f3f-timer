package com.extravision.tracking;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.SharedPreferencesCompat;
import android.support.v7.app.AlertDialog;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.extravision.tracking.Dialogs.HistorySettingsDialog;
import com.extravision.tracking.Dialogs.InfoDialog;
import com.extravision.tracking.Dialogs.SettingsDialog;
import com.extravision.tracking.Managers.API;

/**
 * Created by marktreble on 05/01/2016.
 */
public class EVHistoryMapActivity extends FragmentActivity
    implements OnMapReadyCallback, View.OnClickListener,
        API.APICallbackInterface, GoogleMap.OnMarkerClickListener,
        GoogleMap.OnCameraChangeListener,
        HistorySettingsDialog.HistorySettingsDialogListener {

    private Context mContext;
    private GoogleMap mMap;
    private ArrayList<ArrayList<LatLng>> mWayPoints = new ArrayList<>();
    private JSONObject mData;

    private String mToken;
    private String mIds;
    private String mOldest_date;
    private String mTitle;
    private Button mToggleZones;
    private Button mMapType;



    private API mAPITask = null;
    public static final Handler mHandler = new Handler();

    private static final String INFO_DIALOG = "Info Dialog";
    private static final String SETTINGS_DIALOG = "Settings Dialog";
    private static final String HISTORY_SETTINGS_DIALOG = "History Settings Dialog";

    private static final String[] map_types = {"StreetMap", "Satellite", "Hybrid"};

    // These booleans record that the user has requested a navigation item in the app
    // rather than pressing home to put app into the background
    // Setting these cancels the app kill timeout in onPause
    public boolean mBackPressed;

    private Button mBtnLogout;
    private Button mBtnBack;

    public String mDate;
    public boolean mHideRoute;
    public boolean mHideStops;
    public boolean mHideEvents;
    public boolean mHideArrows;

    private ViewGroup mStats;
    private TextView mViewDate;

    private boolean mFirstCall = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        mContext = this;

        TextView lbl_title = (TextView)findViewById(R.id.title);
        Button btn_back = (Button)findViewById(R.id.btn_back);
        btn_back.setOnClickListener(this);

        ImageButton btn_swap = (ImageButton)findViewById(R.id.btn_swap);
        btn_swap.setOnClickListener(this);
        btn_swap.setImageDrawable(ContextCompat.getDrawable(mContext, R.mipmap.live_tracking));

        ImageButton btn_history_settings = (ImageButton)findViewById(R.id.btn_history_settings);
        btn_history_settings.setVisibility(View.VISIBLE);
        btn_history_settings.setOnClickListener(this);

        Bundle extras = getIntent().getExtras();
        String title = extras.getString("title");
        mTitle = title;
        lbl_title.setText(title);

        mStats = (ViewGroup)findViewById(R.id.stats);
        mStats.setVisibility(View.VISIBLE);
        mStats.findViewById(R.id.stats1).setVisibility(View.VISIBLE);
        ((TextView)mStats.findViewById(R.id.stats1).findViewById(R.id.stats_l1)).setText("Viewing:");
        mViewDate = (TextView)mStats.findViewById(R.id.stats1).findViewById(R.id.stats_v1);

        mToggleZones = (Button)findViewById(R.id.toggle_zones);
        mToggleZones.setOnClickListener(this);

        mMapType = (Button)findViewById(R.id.map_type);
        mMapType.setOnClickListener(this);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        boolean hide_zones = preferences.getBoolean("hide_zones", false);

        String label = (hide_zones) ? "Show Zones":"hide Zones";
        mToggleZones.setText(label);

        int map_type = preferences.getInt("map_type", 0);

        mMapType.setText(map_types[map_type]);

        mToken = extras.getString("token");
        mIds = extras.getString("ids");
        mOldest_date = extras.getString("oldest_date");

        if (savedInstanceState != null){
            mFirstCall = false;

            // Restore the waypoints arrays
            Object o;
            int counter = 0;
            do {
                o = null;
                if (savedInstanceState.containsKey("wp"+counter)) {
                    o = savedInstanceState.getSerializable("wp" + counter++);
                    if (o != null){
                        ArrayList<LatLng> list = (ArrayList<LatLng>)o;
                        mWayPoints.add(list);
                    }
                }
            } while (o != null);

            // Restore the listener to the dialog
            FragmentManager fm = this.getSupportFragmentManager();
            if (fm.findFragmentByTag(HISTORY_SETTINGS_DIALOG) != null) {
                HistorySettingsDialog lDialog = (HistorySettingsDialog) fm.findFragmentByTag(HISTORY_SETTINGS_DIALOG);
                lDialog.mListener = this;
            }
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onBackPressed(){
        mBackPressed = true;
        super.onBackPressed();

    }

    @Override
    public void onDestroy(){
        super.onDestroy();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        // Save the waypoints arrays
        for (int i = 0; i < mWayPoints.size(); i++) {
            outState.putSerializable("wp" + i, mWayPoints.get(i));
        }
        // Must call super or the map will not be restored
        super.onSaveInstanceState(outState);
    }

    // Runnable to shutdown application after 2 seconds of background
    // This forces the app to restart and require the PIN number
    Runnable shutdown = new Runnable() {
        @Override
        public void run() {
            ActivityCompat.finishAffinity((EVHistoryMapActivity)mContext);
            System.exit(0);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();

        // Cancel Shutdown timeout
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mBackPressed) return;
        // Shutdown after 2 seconds
        mHandler.postDelayed(shutdown, MainActivity.SHUTDOWN_TIMOUT);
    }

    @Override
    public void onMapReady(GoogleMap map) {
        mMap = map;
        //mMap.getUiSettings().setRotateGesturesEnabled(false);
        mMap.setOnCameraChangeListener(this);
        mMap.setOnMarkerClickListener(this);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        int map_type = preferences.getInt("map_type", 0);
        switch (map_type){
            case 0:
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                break;
            case 1:
                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                break;
            case 2:
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                break;
        }
        // Begin calls to api to get object data
        mDate = "";
        getHistorySettings();
    }

    public void onCameraChange(CameraPosition c){
        // Update the map when camera changes - mainly to update the bearings of the markers (bearing + map bearing)
        //updateArrows(mData);
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn_back:
                onBackPressed();
                break;
            case R.id.btn_settings:
                showSettings();
                break;
            case R.id.btn_history_settings:
                showHistorySettings();
                break;
            case R.id.btn_swap:
                showLiveTracking();
                break;
            case R.id.toggle_zones:
                toggleZones();
                break;
            case R.id.map_type:
                changeMapType();
                break;
        }
    }

    private void showLiveTracking(){
        mBackPressed = true;

        Intent i = new Intent(this, EVRealtimeTrackingActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_TASK_ON_HOME);
        i.putExtra("ids", mIds);
        i.putExtra("title", mTitle);
        i.putExtra("oldest_date", mOldest_date);
        i.putExtra("token", mToken);

        startActivity(i);
        overridePendingTransition(R.anim.slide_in_right,
                R.anim.zoom_fade_exit);
        finish();
    }

    private void showSettings(){
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(SETTINGS_DIALOG) == null) {
            final SettingsDialog lDialog = SettingsDialog.newInstance();
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, SETTINGS_DIALOG).commitAllowingStateLoss();
        }
    }

    private void showHistorySettings(){

        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(HISTORY_SETTINGS_DIALOG) == null) {
            final HistorySettingsDialog lDialog = HistorySettingsDialog.newInstance();
            lDialog.mListener = this;
            lDialog.mOldest_date = mOldest_date;
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, HISTORY_SETTINGS_DIALOG).commitAllowingStateLoss();
        }
    }

    public void onAPISuccess(String request, JSONObject data) {
        if (request.equals(API.API_GET_HISTORY)) {
            mData = data;
            updateMap(data);

        }

        if (request.equals(API.API_GET_ZONES)) {

            String zones = "";
            try {
                zones = data.getString("zones");
            } catch (JSONException e){
                e.printStackTrace();
            }

            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("zones", zones);
            SharedPreferencesCompat.EditorCompat.getInstance().apply(editor);

            getHistory(this);

        }
    }

    private void updateMap(JSONObject data){
        if (data == null) return;

        mData = data;
        // Update view with new data
        Resources r = getResources();
        float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1, r.getDisplayMetrics());

        try {
            JSONObject d = data.getJSONObject("data");


            mMap.clear();
            LatLngBounds.Builder bounds = new LatLngBounds.Builder();

            // Add Markers and calc bounds
            JSONArray objects = d.getJSONArray("markers");

            for (int i=0; i<objects.length(); i++) {
                JSONObject object = objects.getJSONObject(i);
                String icon_name = object.getString("icon");

                if (icon_name.equals("route_start")
                        ||icon_name.equals("route_stop")
                        || icon_name.equals("route_event")
                        || icon_name.equals("route_end")) {

                    boolean isHidden = false;
                    if (icon_name.equals("route_stop") && mHideStops) isHidden = true;
                    if (icon_name.equals("route_event") && mHideEvents) isHidden = true;

                    if (!isHidden) {

                        JSONObject dta = object.getJSONObject("data");
                        JSONObject l = object.getJSONObject("location");
                        if (l!=null) {
                            float lat = Float.parseFloat(l.getString("lat"));
                            float lng = Float.parseFloat(l.getString("lng"));

                            LatLng o = new LatLng(lat, lng);

                            String object_data = object.getString("data");

                            Bitmap bmp_icon = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier(icon_name, "mipmap", getApplication().getPackageName()));

                            BitmapDescriptor icon = BitmapDescriptorFactory.fromBitmap(bmp_icon);
                            MarkerOptions marker = new MarkerOptions().position(o).anchor(0.5f, 0.2f).snippet(object_data).icon(icon);
                            mMap.addMarker(marker);
                            bounds.include(o);
                        }
                    }
                }
            }

            // Next add route polyline
            JSONArray route = d.getJSONArray("route");
            LatLng o_prev = null;
            LatLng o = null;
            PolylineOptions line = new PolylineOptions();
            line.geodesic(true);
            for (int i=0; i<route.length(); i++) {
                JSONObject object = route.getJSONObject(i);
                float lat = Float.parseFloat(object.getString("lat"));
                float lng = Float.parseFloat(object.getString("lng"));

                o = new LatLng(lat, lng);

                if (o_prev!=null) {
                    line.add(o_prev, o);
                }

                o_prev = o;
            }
            line.width(5 * px).color(ContextCompat.getColor(mContext, R.color.history));
            mMap.addPolyline(line);

            // Arrows
            if (!mHideArrows){
            }

            // Add the Zones
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            boolean hide_zones = preferences.getBoolean("hide_zones", false);
            if (!hide_zones) {

                String zones = preferences.getString("zones", "");

                JSONArray arr_zones = new JSONArray(zones);
                for (int i = 0; i < arr_zones.length(); i++) {
                    JSONObject zone = arr_zones.getJSONObject(i);
                    String zone_name = zone.getString("zone_name");
                    String zone_colour = zone.getString("zone_color");
                    String zone_verts = zone.getString("zone_vertices");
                    boolean zone_visible = zone.getBoolean("zone_visible");
                    boolean zone_name_visible = zone.getBoolean("zone_name_visible");

                    if (zone_visible) {
                        PolygonOptions opts = new PolygonOptions();
                        String[] verts = zone_verts.split(",");
                        double clat = 0;
                        double clng = 0;
                        for (int j = 0; j < verts.length; j += 2) {
                            double lat = Double.parseDouble(verts[j]);
                            double lng = Double.parseDouble(verts[j + 1]);
                            opts.add(new LatLng(lat, lng));
                            clat += lat;
                            clng += lng;
                        }
                        int c_stroke = Color.parseColor("#CC" + zone_colour.substring(1, 7));
                        int c_fill = Color.parseColor("#66" + zone_colour.substring(1, 7));
                        opts.strokeColor(c_stroke);
                        opts.fillColor(c_fill);

                        mMap.addPolygon(opts);

                        if (zone_name_visible) {
                            double numverts = (verts.length / 2);
                            LatLng o_l = new LatLng(clat / numverts, clng / numverts);

                            // Add label
                            Bitmap bmp_label = createLabel(zone_name, px, 0);
                            BitmapDescriptor label = BitmapDescriptorFactory.fromBitmap(bmp_label);
                            MarkerOptions marker_label = new MarkerOptions().position(o_l).icon(label);
                            mMap.addMarker(marker_label);
                        }
                    }
                }
            }

            if (mFirstCall) {
                CameraUpdate start = CameraUpdateFactory.newLatLngBounds(bounds.build(), (int) (75f * px));
                mMap.moveCamera(start);
            }
            mFirstCall = false;

        } catch (JSONException e){
            e.printStackTrace();

        }
    }

    public void onAPIError(String request, JSONObject data){
        if (request.equals(API.API_GET_HISTORY)) {
            new AlertDialog.Builder(this)
                    .setTitle("No History Unavailable")
                    .setMessage("No history is available. Please try a different date")
                    .create().show();
        }
    }

    private Bitmap createLabel(String name, float px, float offset) {

        float textsize = 12*px;
        offset *=px;
        float padding = 5*px;

        Paint metrics = new Paint();
        metrics.setFakeBoldText(true);
        metrics.setAntiAlias(true);
        metrics.setTextSize(textsize);
        float width = metrics.measureText(name) + (padding * 2);
        float height = textsize + (padding * 2);


        Bitmap bitmap = Bitmap.createBitmap((int)((width*2)+offset), (int)height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint background = new Paint();
        background.setColor(0xccffffff);
        canvas.drawRect(width + offset, 0F, (width * 2) + offset,  height, background);

        Paint border = new Paint();
        border.setStyle(Paint.Style.STROKE);
        border.setColor(0x40000000);
        border.setStrokeWidth(2*px);
        canvas.drawRect(width + offset, 0F, (width * 2) + offset, height, border);

        Paint paint = new Paint();
        paint.setColor(0xcc333333);
        paint.setTextSize(textsize);
        paint.setFakeBoldText(true);
        paint.setAntiAlias(true);
        canvas.drawText(name, width+offset+padding, height-padding, paint);
        return bitmap;
    }

    public boolean onMarkerClick(Marker m){
        if (m == null) return false;
        if (m.getSnippet() == null) return false;
        if (m.getSnippet().equals("")) return true;
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(INFO_DIALOG) == null) {
            final InfoDialog lDialog = InfoDialog.newInstance(m.getSnippet());
            lDialog.mFetchAddress = true;
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, INFO_DIALOG).commitAllowingStateLoss();
        }
        return true;
    }

    private void loadZones(){
        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_GET_ZONES);
        params.put("t", mToken);

        mAPITask = new API();
        mAPITask.mCallback = this;
        mAPITask.request = API.API_GET_ZONES;
        mAPITask.makeAPICall(mContext, API.httpmethod.GET, params);
    }

    private void toggleZones(){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        boolean hide_zones = !preferences.getBoolean("hide_zones", false);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("hide_zones", hide_zones);

        String label = (hide_zones) ? "Show Zones":"Hide Zones";
        editor.commit();

        mToggleZones.setText(label);
        updateMap(mData);
    }

    private void changeMapType(){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose");
        builder.setItems(map_types, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putInt("map_type", which);
                editor.commit();
                mMapType.setText(map_types[which]);

                switch (which){
                    case 0:
                        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                        break;
                    case 1:
                        mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                        break;
                    case 2:
                        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                        break;
                }
            }
        });
        builder.show();
    }

    private void getHistory(API.APICallbackInterface callback){
        // Call the api on behalf of the fragment
        // Data will be returned to fragment's APIResponse callback methods
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String today = simpleDateFormat.format(cal.getTime());
        cal.add(Calendar.DATE, -1);
        String yesterday = simpleDateFormat.format(cal.getTime());

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        String date = preferences.getString("show_date", "today");
        mDate = date;

        mViewDate.setText(date);

        if (date.equals("today")) date = today;
        if (date.equals("yesterday")) date = yesterday;


        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_GET_HISTORY);
        params.put("t", mToken);
        params.put("i", mIds);
        params.put("d", date);
        params.put("msd", "1");
        params.put("w", "full");

        mAPITask = new API();
        mAPITask.mCallback = callback;
        mAPITask.request = API.API_GET_HISTORY;
        mAPITask.makeAPICall(mContext, API.httpmethod.GET, params);

    }

    public void onHistorySettingsChanged(){
        mMap.clear();
        getHistorySettings();
        updateMap(mData);

    }

    private void getHistorySettings(){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        mHideRoute = !preferences.getBoolean("show_route", true);
        mHideStops = !preferences.getBoolean("show_stops", true);
        mHideEvents = !preferences.getBoolean("show_events", true);
        mHideArrows = !preferences.getBoolean("show_arrows", true);
        if (!mDate.equals(preferences.getString("show_date", "today"))) {
            mMap.clear();
            mData = null;
            loadZones();
        }

    }

}
