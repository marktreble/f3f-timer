package com.extravision.tracking.Fragments;

import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.extravision.tracking.EVNotificationsActivity;
import com.extravision.tracking.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by marktreble on 04/01/2016.
 */
public class NotificationsListFragment extends Fragment {

    private static final String TAG = "NotifsListFragment";

    private SwipeMenuListView mList;
    private ArrayList<JSONObject> mNotificationList;
    private ArrayAdapter<JSONObject> mAdapter;

    public EVNotificationsActivity delegate;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "ONCREATE");

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String user_id = preferences.getString("user_id", "");
        String notifications = preferences.getString("notifications_"+user_id, "");
        Log.d(TAG, notifications);

        mNotificationList = new ArrayList<>();
        if (!notifications.equals("")) {
            try {
                JSONArray json_arr = new JSONArray(notifications);
                for (int i=0; i<json_arr.length(); i++){
                    mNotificationList.add(json_arr.getJSONObject(i));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


    }

    public void onSaveInstanceState(Bundle outState){

        super.onSaveInstanceState(outState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.swipe_list_container, null);

        mList = (SwipeMenuListView)view.findViewById(R.id.listView);

        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {

                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(getContext());
                // set item background
                deleteItem.setBackground(new ColorDrawable(ContextCompat.getColor(getActivity(), R.color.red)));
                // set item width
                deleteItem.setWidth(dp2px(90));
                // set a icon
                deleteItem.setIcon(R.mipmap.delete);
                // add to menu
                menu.addMenuItem(deleteItem);
            }
        };


        // set creator
        mList.setMenuCreator(creator);
        mList.setSwipeDirection(SwipeMenuListView.DIRECTION_LEFT);
        mList.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                // Delete the notification at position
                mNotificationList.remove(position);
                JSONArray notifs = new JSONArray(mNotificationList);

                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
                String user_id = preferences.getString("user_id", "");

                preferences.edit()
                        .putString("notifications_"+user_id, notifs.toString())
                        .apply();

                mAdapter.notifyDataSetChanged();
                // false : close the menu; true : not close the menu
                return true;
            }
        });
        setList();

        return view;
    }

    private int dp2px(float dp){
        return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }

    public static JSONArray removeFromJSONArrayAtIndex( JSONArray jarray,int pos) {

        JSONArray Njarray=new JSONArray();
        try{
            for(int i=0;i<jarray.length();i++){
                if(i!=pos)
                    Njarray.put(jarray.get(i));
            }
        } catch (Exception e){e.printStackTrace();}
        return Njarray;

    }

    private void setList(){


        mAdapter = new ArrayAdapter<JSONObject>(getActivity(), R.layout.notification_list_item, mNotificationList ){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the data item for this position
                JSONObject o = getItem(position);
                // Check if an existing view is being reused, otherwise inflate the view
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.notification_list_item, parent, false);
                }
                // Lookup view for data population
                TextView name = (TextView) convertView.findViewById(R.id.name);

                // Populate the data into the template view using the data object
                String o_message = "";
                String o_time = "";
                try {
                    o_message = o.getString("message");
                    o_time = o.getString("time");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                name.setText(String.format("%s\n%s", o_time, o_message));

                // Return the completed view to render on screen
                return convertView;
            }
        };

        mList.setAdapter(mAdapter);
    }

    @Override
    public void onStart(){
        super.onStart();

    }


}
