package com.extravision.tracking.Fragments;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.telephony.SmsManager;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.extravision.tracking.EVTrackerCommandsListActivity;
import com.extravision.tracking.MainActivity;
import com.extravision.tracking.Managers.API;
import com.extravision.tracking.Managers.CommandController;
import com.extravision.tracking.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by marktreble on 17/03/2016.
 */
public class TrackerCommandsListFragment extends Fragment {

    private static final String TAG = "TrackerCmdsListFragment";

    private static final int SMS_PERMISSION_GRANTED = 2;
    private ListView mList;
    private ArrayList<JSONObject> mNotificationList;
    private ArrayAdapter<String> mAdapter;

    public MainActivity delegate;

    private String mNumber;
    private String mMessage;
    private String mTitle;

    public JSONObject mObjectData;
    public JSONObject mOCntrlData;

    private API mAPITask = null;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "ONCREATE");

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String notifications = preferences.getString("notifications", "");

        mNotificationList = new ArrayList<>();
        if (!notifications.equals("")) {
            try {
                JSONArray json_arr = new JSONArray(notifications);
                for (int i=0; i<json_arr.length(); i++){
                    mNotificationList.add(json_arr.getJSONObject(i));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


    }

    public void setParams(String title){
        mTitle = title;
    }

    public void onSaveInstanceState(Bundle outState){

        super.onSaveInstanceState(outState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_container, null);

        TextView title = (TextView)view.findViewById(R.id.title);
        title.setText(mTitle);

        mList = (ListView)view.findViewById(R.id.list);
        setList();

        return view;
    }

    private void setList(){
        String[] commands = new String[0];
        try {
            String base64String = mObjectData.getString("cmds");
            byte[] data = Base64.decode(base64String, Base64.DEFAULT);
            String cmds = new String(data, "UTF-8");
            mOCntrlData = new JSONObject(cmds);
            commands = mOCntrlData.getString("commands").split(",");

        } catch (JSONException | UnsupportedEncodingException e){
            e.printStackTrace();
        };

        final LinkedHashMap<String, String> menulist = new LinkedHashMap<>();

        for (String command : commands) {
            String[] parts = command.split("~");
            menulist.put(parts[0], parts[1]);
        }

        Collection<String> menutitles = menulist.keySet();

        String[] context_menu_options = new String[menutitles.size()];
        context_menu_options = menutitles.toArray(context_menu_options);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String user_id = sharedPreferences.getString("user_id", "");
        boolean left_handed =  sharedPreferences.getBoolean("left_handed_enabled_"+user_id, false);

        final int cell_layout = (left_handed) ? R.layout.context_menu_list_item_left : R.layout.context_menu_list_item;

        mAdapter = new ArrayAdapter<String>(getActivity(), cell_layout, R.id.name, context_menu_options ){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the data item for this position
                final String option = getItem(position);
                // Check if an existing view is being reused, otherwise inflate the view
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(cell_layout, parent, false);
                }
                // Lookup view for data population
                TextView name = (TextView) convertView.findViewById(R.id.name);
                Button disclosure = (Button) convertView.findViewById(R.id.show);
                disclosure.setTag(position);

                name.setText(option);

                disclosure.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.d(TAG, "CLICKED "+v.getTag());

                        int position = (Integer) v.getTag();
                        String command = menulist.get(option).replace("%@", "%s");
                        Log.i(TAG, command);
                        sendMessage(command, option);
                    }
                });

                // Return the completed view to render on screen
                return convertView;
            }
        };

        mList.setAdapter(mAdapter);

    }


    @Override
    public void onStart(){
        super.onStart();
    }

    private void sendMessage(String command, String command_name) {

        /*
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String user_id = sharedPreferences.getString("user_id", "");
        String object_id = "1";//mObjectData.getString("object_id");

        String val_operator = sharedPreferences.getString("operator_" + user_id + "_" + object_id, "");
        String val_username = sharedPreferences.getString("username_" + user_id + "_" + object_id, "");
        String val_password = sharedPreferences.getString("password_" + user_id + "_" + object_id, "");
        mNumber = sharedPreferences.getString("number_" + user_id + "_" + object_id, "");
        */
        String val_operator;
        String val_username;
        String val_password;
        String object_id;
        String name;

        try {
            val_operator = mOCntrlData.getString("operator");
            val_username = mOCntrlData.getString("username");
            val_password = mOCntrlData.getString("username");
            mNumber = mOCntrlData.getString("number");
            object_id = mObjectData.getString("object_id");
            name = mObjectData.getString("name");


        } catch (JSONException e){
            e.printStackTrace();
            return;
        }

        CommandController command_controller = new CommandController();
        command_controller.mContext = this;
        command_controller.delegate = (MainActivity)getActivity();
        command_controller.ocntrl_data = mOCntrlData;

        command_controller.name = name;
        command_controller.object_id = object_id;

        command_controller.command = command_name;
        command_controller.sendMessage(command);

        /*
        Log.i("SMS", "FMT: "+command);
        mMessage = String.format(command, val_username, val_password);
        Log.d(TAG, mMessage);
        Log.d(TAG, val_operator);

        if (val_operator.equals("1")) {
            // GeoSIM (Send by SMS)
            sendSMS();
        }
        */

        if (val_operator.equals("2")) {
            // Aeris (Send by Aeris API)
            delegate.showSMSSending();
            new sendAeris(getActivity()).execute();
        }

        if (val_operator.equals("3")) {
            // Aeris (Send by Aeris API)
            delegate.showSMSSending();
            // Don't send uname/password for GPRS
            mMessage = String.format(command, "", "").trim();
            new sendGPRS(getActivity()).execute();
        }

    }

    public class sendAeris extends AsyncTask<Void, Void, String> {
        Context mContext;
        int mMethod;


        public sendAeris(Context context) {
            super();
            mContext = context;

        }

        public void execute(){
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            String token = preferences.getString("token", null);

            String val_username;
            String val_password;
            String object_id;
            try {
                object_id = mObjectData.getString("object_id");

                val_username = mOCntrlData.getString("username");
                val_password = mOCntrlData.getString("username");

            } catch (JSONException e){
                e.printStackTrace();
                return;
            }

            Map<String, String> params = new HashMap<>();
            params.put(API.ENDPOINT_KEY, API.API_SEND_AERIS_COMMAND);
            params.put("t", token);
            params.put("m", mMessage);
            params.put("n", mNumber);
            params.put("id", object_id);
            params.put("a", String.format("%s:%s", val_username, val_password));

            mAPITask = new API();
            mAPITask.mCallback = (API.APICallbackInterface)mContext;
            mAPITask.request = API.API_SEND_AERIS_COMMAND;
            mAPITask.makeAPICall(mContext, API.httpmethod.GET, params);
        }

        @Override
        protected String doInBackground(Void... params) {

            MediaType JSON = MediaType.parse("application/json; charset=utf-8");
            String json = "{\"address\":[\""+mNumber+"\"],\"senderAddress\":\"TestApp\",\"senderName\":\"AFTestClient\",\"outboundSMSTextMessage\":{\"message\":\""+ mMessage +"\"},\"clientCorrelator\":\"123456\"}";
            String url = "https://api.aerframe.aeris.com/smsmessaging/v2/15066/outbound/TestApp/requests?apiKey=7b20a291-651a-11e6-a5a1-e71fcc19a6ae";

            Log.i(TAG, json);
            OkHttpClient client = new OkHttpClient();

            RequestBody body = RequestBody.create(JSON, json);
            Request request = new Request.Builder()
                    .header("Content-Type", "application/json; charset=utf-8")
                    .url(url)
                    .post(body)
                    .build();

            String str_response = "IOException";
            try {
                Response response = client.newCall(request).execute();
                str_response = response.body().string();
            } catch (IOException e){
                e.printStackTrace();
            }
            return str_response;
        }


        @Override
        protected void onPostExecute(String response) {
            if (this.isCancelled()) return;

            Log.i(TAG, "RESPONSE WAS: " + response);
            final String r = response;
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ((EVTrackerCommandsListActivity)getActivity()).AerisAPIResponse(r);
                }

            });

        }

    }

    /* DEP
    private void sendSMS(){
        Log.i("SMS", "sendSMS!!!!");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (getActivity().checkSelfPermission(Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // permission is not granted, ask for permission:
                delegate.mPermissionRequested = true;
                requestPermissions(new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_GRANTED);
            } else {
                sendSMSFromDevice();
            }
        } else {
            sendSMSFromDevice();
        }

    }
    */
    public class sendGPRS {
        Context mContext;


        public sendGPRS(Context context) {
            super();
            mContext = context;

        }

        public void execute(){
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            String token = preferences.getString("token", null);

            String val_username;
            String val_password;
            String object_id;
            try {
                object_id = mObjectData.getString("object_id");

                val_username = mOCntrlData.getString("username");
                val_password = mOCntrlData.getString("username");

            } catch (JSONException e){
                e.printStackTrace();
                return;
            }

            Map<String, String> params = new HashMap<>();
            params.put(API.ENDPOINT_KEY, API.API_SEND_GPRS_COMMAND);
            params.put("t", token);
            params.put("m", mMessage);
            params.put("id", object_id);
            params.put("a", String.format("%s:%s", val_username, val_password));

            mAPITask = new API();
            mAPITask.mCallback = (API.APICallbackInterface)mContext;
            mAPITask.request = API.API_SEND_GPRS_COMMAND;
            mAPITask.makeAPICall(mContext, API.httpmethod.GET, params);
        }
    }

    /*
    public void onRequestPermissionsResult (int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_GRANTED) {
            // Only one permission, but we will loop and check for completeness
            // and future compatibility
            for (int i = 0; i < permissions.length; i++) {

                String permission = permissions[i];
                int result = grantResults[i];

                if (permission.equals(Manifest.permission.SEND_SMS)){
                    if (result == PackageManager.PERMISSION_GRANTED){
                        sendSMSFromDevice();
                    }
                }

            }
        }
    }

    private void sendSMSFromDevice(){
        delegate.showSMSSending();
        SmsManager sms = SmsManager.getDefault();
        Intent sentIntent = new Intent("SMS_SENT");
        PendingIntent piSent = PendingIntent.getBroadcast(getActivity(), 0, sentIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        Intent deliveredIntent = new Intent("SMS_DELIVERED");
        PendingIntent piDelivered = PendingIntent.getBroadcast(getActivity(), 0, deliveredIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        sms.sendTextMessage(mNumber, null, mMessage, piSent, piDelivered);
    }
    */

}
