package com.extravision.tracking.Views;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;

import com.extravision.tracking.R;

/**
 * Created by marktreble on 04/01/2016.
 */
public class ObjectListHeaderView extends FrameLayout
        implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    private CheckBox mCheckAll;
    private Button mShowSelected;
    private Button mShowSelected2;

    public interface ObjectListHeaderViewListener {
        void onCheckAll(boolean checked);
        void onShowSelected();
    }

    public ObjectListHeaderViewListener mCallback;

    public ObjectListHeaderView(Context context){
        super(context);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String user_id = sharedPreferences.getString("user_id", "");
        boolean left_handed =  sharedPreferences.getBoolean("left_handed_enabled_"+user_id, false);

        final int cell_layout = (left_handed) ? R.layout.object_list_header_view_left : R.layout.object_list_header_view;

        View view;
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(cell_layout, null);

        addView(view);

        mCheckAll = (CheckBox)view.findViewById(R.id.check_all);
        mShowSelected = (Button)view.findViewById(R.id.show_selected);
        mShowSelected2 = (Button)view.findViewById(R.id.show_selected2);

        mCheckAll.setOnCheckedChangeListener(this);
        mShowSelected.setOnClickListener(this);
        mShowSelected2.setOnClickListener(this);
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.show_selected:
            case R.id.show_selected2:
                    mCallback.onShowSelected();
                break;
        }
    }

    public void onCheckedChanged(CompoundButton v, boolean isChecked){
        switch (v.getId()){
            case R.id.check_all:
                    mCallback.onCheckAll(isChecked);
                break;
        }
    }

    public void setCheckAll(boolean checked){
        mCheckAll.setChecked(checked);
    }
}
