package com.extravision.tracking.Views;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;

import com.extravision.tracking.R;

/**
 * Created by marktreble on 04/01/2016.
 */
public class HistoryListHeaderView extends FrameLayout {

    public HistoryListHeaderView(Context context){
        super(context);

        View view;
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.history_list_header_view, null);

        addView(view);

    }

}
