package com.extravision.tracking.Managers;

import android.app.Activity;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.util.Log;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Created by marktreble on 04/07/2016.
 */
public class RGeocode implements Runnable {

    private static final String TAG = "RGeocode";

    private double _lat;
    private double _lng;
    private TextView _target;
    private Context _context;
    private LocationReceiver _callback;
    public String mDelimiter;

    private String mStr_address;

    public RGeocode(){

    }

    public RGeocode(Context context, double lat, double lng, TextView target, LocationReceiver callback) {
        _lat = lat;
        _lng = lng;
        _target = target;
        _context = context;
        _callback = callback;
    }

    @Override
    public void run() {
        // Run in background
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);

        // Do the reverse geocoding
        Geocoder geocoder = new Geocoder(_context, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(_lat, _lng, 1);
            if (Geocoder.isPresent() && addresses != null && addresses.size() > 0) {
                Address a = addresses.get(0);

                StringBuilder address = new StringBuilder();
                for (int i = 0; i<= a.getMaxAddressLineIndex(); i++){
                    if (address.length()>0) address.append(mDelimiter);
                    address.append(a.getAddressLine(i));
                }
                mStr_address = address.toString();
                if (mStr_address.equals("")){
                    getFromWebService();
                }
                ((Activity)_context).runOnUiThread(completed);

            } else {
                getFromWebService();
            }
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public void getFromWebService(){
        Log.d(TAG, "No Geocoder available (or not working?) - using web service");
        Location l = new Location("");
        l.setLatitude(_lat);
        l.setLongitude(_lng);
        mStr_address = ReverseGeocoder.getFromLocation(l, _context);
        ((Activity)_context).runOnUiThread(completed);
    }

    Runnable completed = new Runnable() {
        @Override
        public void run() {
            if (_target != null) _target.setText(mStr_address);
            if (_callback!=null && mStr_address!= null){
                _callback.mAddress = mStr_address;
                _callback.run();
            }
        }
    };

    public abstract class LocationReceiver implements Runnable {
        public String mAddress;
        public String mLatLng;

        public LocationReceiver(){

        }
    }
};