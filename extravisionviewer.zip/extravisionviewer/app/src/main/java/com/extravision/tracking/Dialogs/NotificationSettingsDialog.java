package com.extravision.tracking.Dialogs;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.DialogFragment;
import android.support.v4.widget.TextViewCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.extravision.tracking.Managers.API;
import com.extravision.tracking.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by marktreble on 06/01/2016.
 */
public class NotificationSettingsDialog extends DialogFragment {

    private ViewGroup mView;

    private String user_id;

    private DialogFragment mFragment;

    public static NotificationSettingsDialog newInstance() {

        NotificationSettingsDialog settingsDialog = new NotificationSettingsDialog();
        return settingsDialog;
    }

    public interface NotificationSettingsDialogListener {

        void onNotificationSettingsChanged();
    }

    public NotificationSettingsDialogListener mListener;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(STYLE_NO_TITLE);
        mView = (ViewGroup)inflater.inflate(R.layout.notification_settings_dialog, null);

        mFragment = this;
        setCancelable(false);

        CheckBox enable_push = (CheckBox)mView.findViewById(R.id.enable_push);

        Button ok = (Button)mView.findViewById(R.id.btn_ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.onCancel(getDialog());
            }
        });

        ImageView close = (ImageView)mView.findViewById(R.id.close_btn);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.onCancel(getDialog());
            }
        });

        ViewGroup options = (ViewGroup)mView.findViewById(R.id.options);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        user_id = sharedPreferences.getString("user_id", "");

        String notifications = sharedPreferences.getString("notifications", "");
        try {
            JSONArray arr_notifications = new JSONArray(notifications);

            for (int n=0; n<arr_notifications.length(); n++){
                JSONObject notification = arr_notifications.getJSONObject(n);

                LinearLayout option = new LinearLayout(getActivity());
                option.setOrientation(LinearLayout.HORIZONTAL);

                LayoutParams LLParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
                option.setLayoutParams(LLParams);

                int event_id = notification.getInt("event_id");
                String name = notification.getString("name");
                int status = 0;
                if (!notification.isNull("notify"))  status = notification.getInt("notify");

                CheckBox checkbox = new CheckBox(getActivity());
                LayoutParams CBLParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                checkbox.setLayoutParams(CBLParams);
                checkbox.setTag(event_id);
                checkbox.setChecked(status != 1);

                TextView label = new TextView(getActivity());
                LayoutParams LabelLParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                label.setLayoutParams(LabelLParams);
                label.setGravity(Gravity.LEFT);
                label.setText(name);
                TextViewCompat.setTextAppearance(label, R.style.dialog);

                option.addView(checkbox);
                option.addView(label);

                options.addView(option);


            }
        } catch (JSONException e){

        }

        boolean notify = sharedPreferences.getBoolean("push_enabled_"+user_id, false);
        enable_push.setChecked(notify);

        return mView;
    }


    @Override
    public void onStart() {
        super.onStart();

        if (getDialog() == null)
            return;

        getDialog().getWindow().setWindowAnimations(R.style.slide);

        getDialog().getWindow().setGravity(Gravity.CENTER);

        int screenWidth = (int) getResources().getDisplayMetrics().widthPixels;
        getDialog().getWindow().setLayout(screenWidth,
                LayoutParams.WRAP_CONTENT);

        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }

    @Override
    public void onCancel(DialogInterface dialog) {

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String notifications = sharedPreferences.getString("notifications", "");
        try {
            JSONArray arr_notifications = new JSONArray(notifications);

            for (int n = 0; n < arr_notifications.length(); n++) {
                JSONObject notification = arr_notifications.getJSONObject(n);

                LinearLayout option = new LinearLayout(getActivity());
                option.setOrientation(LinearLayout.HORIZONTAL);

                LayoutParams LLParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
                option.setLayoutParams(LLParams);

                int event_id = notification.getInt("event_id");
                CheckBox checkbox = (CheckBox)mView.findViewWithTag(event_id);

                notification.put("notify", checkbox.isChecked()?0:1);
                arr_notifications.put(n, notification);


            }
            CheckBox enable_push = (CheckBox)mView.findViewById(R.id.enable_push);
            boolean enabled = sharedPreferences.getBoolean("push_enabled_"+ user_id, false);

            if (enable_push.isChecked() != enabled){
                // update api
                String ptoken = sharedPreferences.getString("ptoken", null);
                String token = sharedPreferences.getString("token", null);
                String device = sharedPreferences.getString("device_id", null);
                Map<String, String> params = new HashMap<>();
                params.put(API.ENDPOINT_KEY, API.API_SAVE_PUSH_TOKEN);
                params.put("t", token);
                params.put("d", device);
                params.put("tp", "And");
                params.put("p", (enable_push.isChecked()) ? ptoken : "");

                API apitask = new API();
                apitask.request = API.API_SAVE_PUSH_TOKEN;
                apitask.makeAPICall(getActivity(), API.httpmethod.GET, params);
            }
            sharedPreferences.edit()
                    .putString("notifications", arr_notifications.toString())
                    .putBoolean("push_enabled_" + user_id, enable_push.isChecked())
                    .apply();
            Log.d("OI", user_id);

        } catch (JSONException e){

        }

        if (mListener != null)
            mListener.onNotificationSettingsChanged();

        super.onCancel(dialog);
        mFragment.dismissAllowingStateLoss();

    }

    @Override
    public void onDismiss(DialogInterface dialog){


        super.onDismiss(dialog);
    }
}
