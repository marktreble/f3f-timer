package com.extravision.tracking.Fragments;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.extravision.tracking.MainActivity;
import com.extravision.tracking.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.Collection;
import java.util.LinkedHashMap;

import static com.extravision.tracking.MainActivity.*;

/**
 * Created by marktreble on 04/01/2016.
 */
public class ObjectContextMenuFragment extends Fragment {

    private static final String TAG = "ObjectContextMenuFrag";

    private ListView mList;
    private ArrayAdapter<String> mAdapter;

    private boolean mCheckAll = false;

    private String[] mIds;
    private String mTitle;
    private String mOldest_date;

    public JSONObject mObjectData;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "ONCREATE");

    }

    public void setParams(String[] ids, String title, String oldest_date){
        // Passthrough variables
        mIds = ids;
        mTitle = title;
        mOldest_date = oldest_date;
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_container, null);

        TextView title = (TextView)view.findViewById(R.id.title);
        title.setText(mTitle);

        mList = (ListView)view.findViewById(R.id.list);
        setList();

        return view;
    }

    private void setList(){
        String[] commands = new String[0];
        try {
            String base64String = mObjectData.getString("cmds");
            byte[] data = Base64.decode(base64String, Base64.DEFAULT);
            String cmds = new String(data, "UTF-8");
            JSONObject options = new JSONObject(cmds);
            commands = options.getString("commands").split(",");

        } catch (JSONException | UnsupportedEncodingException e){
            //e.printStackTrace();
        };

        final LinkedHashMap<String, Integer> menulist = new LinkedHashMap<>();

        menulist.put("Live Tracking", FRAG_LIVE_TRACKING);
        menulist.put("History Map", FRAG_HISTORY_MAP);
        menulist.put("History Events", FRAG_HISTORY_LIST);
        menulist.put("Servicing Details", FRAG_SERVICING);
        if (commands.length>0) menulist.put("Tracker Commands", FRAG_TRACKER_COMMANDS);
        menulist.put("Share Location", FRAG_SHARE_LOC);

        Collection<String> menutitles = menulist.keySet();

        String[] context_menu_options = new String[menutitles.size()];
        context_menu_options = menutitles.toArray(context_menu_options);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String user_id = sharedPreferences.getString("user_id", "");
        boolean left_handed =  sharedPreferences.getBoolean("left_handed_enabled_"+user_id, false);

        final int cell_layout = (left_handed) ? R.layout.context_menu_list_item_left : R.layout.context_menu_list_item;

        mAdapter = new ArrayAdapter<String>(getActivity(), cell_layout, R.id.name, context_menu_options ){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the data item for this position
                String option = getItem(position);

                // Check if an existing view is being reused, otherwise inflate the view
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(cell_layout, parent, false);
                }
                // Lookup view for data population
                TextView name = (TextView) convertView.findViewById(R.id.name);
                Button disclosure = (Button) convertView.findViewById(R.id.show);
                disclosure.setTag(menulist.get(option));

                name.setText(option);

                disclosure.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int position = (Integer) v.getTag();
                        switch (position){
                            case FRAG_LIVE_TRACKING:
                                ((MainActivity) getActivity()).showRealtimeMap(mIds, mTitle, mOldest_date);
                                break;
                            case FRAG_HISTORY_MAP:
                                ((MainActivity) getActivity()).showHistoryMap(mIds, mTitle, mOldest_date);
                                break;
                            case FRAG_HISTORY_LIST:
                                ((MainActivity) getActivity()).showHistoryList(mIds, mTitle, mOldest_date);
                                break;
                            case FRAG_SERVICING:
                                ((MainActivity) getActivity()).showServicing(mIds, mTitle, mObjectData);
                                break;
                            case FRAG_TRACKER_COMMANDS:
                                ((MainActivity) getActivity()).showTrackerCommandsList(mIds, mTitle, mObjectData);
                                break;
                            case FRAG_SHARE_LOC:
                                ((MainActivity) getActivity()).shareLocation(mIds, mTitle, mObjectData);
                                break;
                        }
                    }
                });

                // Return the completed view to render on screen
                return convertView;
            }
        };

        mList.setAdapter(mAdapter);

    }



    @Override
    public void onStart(){
        super.onStart();

    }


}
