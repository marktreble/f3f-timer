package com.extravision.tracking.Fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.extravision.tracking.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collection;
import java.util.LinkedHashMap;

/**
 * Created by marktreble on 04/01/2016.
 */
public class TrackerServicingFragment extends Fragment {

    private static final String TAG = "ServicingFrag";

    private ListView mList;
    private ArrayAdapter<String> mAdapter;

    public String[] mIds;
    public String mTitle;

    public JSONObject mObjectData;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "ONCREATE");

    }

    public void setParams(String title){
        mTitle = title;
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_container, null);

        TextView title = (TextView)view.findViewById(R.id.title);
        title.setText(mTitle);

        mList = (ListView)view.findViewById(R.id.list);
        setList();

        return view;
    }

    private void setList(){
        final LinkedHashMap<String, String> list = new LinkedHashMap<>();
        try {
            String services = mObjectData.getString("services");
            JSONArray array = new JSONArray(services);
            for (int i=0; i<array.length(); i++){
                JSONObject data = array.getJSONObject(i);
                String name = data.getString("name");
                String info = data.getString("info");

                list.put(name, info);
            }

        } catch (JSONException e){
            //e.printStackTrace();
        };

        Collection<String> titles = list.keySet();

        String[] rows = new String[titles.size()];
        rows = titles.toArray(rows);

        final int cell_layout = R.layout.servicing_list_item;

        mAdapter = new ArrayAdapter<String>(getActivity(), cell_layout, R.id.name, rows ){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the data item for this position
                String str_name = getItem(position);
                String str_info = list.get(str_name);

                // Check if an existing view is being reused, otherwise inflate the view
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(cell_layout, parent, false);
                }
                // Lookup view for data population
                TextView name = (TextView) convertView.findViewById(R.id.name);
                TextView info = (TextView) convertView.findViewById(R.id.info);
                name.setText(str_name);
                info.setText(str_info);


                // Return the completed view to render on screen
                return convertView;
            }
        };

        mList.setAdapter(mAdapter);

    }



    @Override
    public void onStart(){
        super.onStart();

    }


}
