package com.extravision.tracking.Fragments;

import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.extravision.tracking.MainActivity;
import com.extravision.tracking.Managers.API;
import com.extravision.tracking.R;
import com.extravision.tracking.Views.ObjectListHeaderView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by marktreble on 04/01/2016.
 */
public class ServicingListFragment extends Fragment
        implements API.APICallbackInterface {

    private static final String TAG = "ObjectListFragment";

    private static final String CELL_TYPE_HEADER = "Header";
    private static final String CELL_TYPE_OBJECT = "Object";

    private ListView mList;
    private JSONObject mRawData;
    private ArrayList<JSONObject> mObjectList;
    private ArrayAdapter<JSONObject> mAdapter;
    private ArrayList<String> mGroupsList = new ArrayList<>();
    private ArrayList<Boolean> mGroupsStatus = new ArrayList<>();
    private ArrayList<Integer> mGroupsCount = new ArrayList<>();

    private boolean mCheckAll = false;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "ONCREATE");

        if (savedInstanceState == null) {
            mObjectList = new ArrayList<>();
        } else {
            mCheckAll = savedInstanceState.getBoolean("checkall");

            // Restore the objects arrays

            /*mObjectList = new ArrayList<>();

            Object o;
            int counter = 0;
            do {
                o = null;
                if (savedInstanceState.containsKey("ol"+counter)) {
                    o = savedInstanceState.getString("ol" + counter++);
                    if (o != null){
                        try {
                            JSONObject obj = new JSONObject((String) o);
                            mObjectList.add(obj);
                        } catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                }
            } while (o != null);*/

            String rawData = savedInstanceState.getString("rawData");
            if (rawData != null) {
                try {
                    mRawData = new JSONObject(rawData);
                    setData(mRawData);
                    mAdapter.notifyDataSetChanged();
                } catch (JSONException e) {};
            }
        }

    }

    public void resume(){
        Log.i(TAG, "RESUME");
        try {
            JSONObject data = new JSONObject(mRawData.toString());
            setData(data);
            mAdapter.notifyDataSetChanged();
        } catch (JSONException e){};
    }

    public void onSaveInstanceState(Bundle outState){
        outState.putBoolean("checkall", mCheckAll);
        outState.putString("rawData", mRawData.toString());
        /*
        for (int i = 0; i < mObjectList.size(); i++) {
            outState.putString("ol" + i, mObjectList.get(i).toString());
        }*/

        super.onSaveInstanceState(outState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_container, null);

        TextView title = (TextView)view.findViewById(R.id.title);
        title.setVisibility(View.GONE);

        mList = (ListView)view.findViewById(R.id.list);
        setList();

        return view;
    }

    private void setList(){

        final Drawable contract = ContextCompat.getDrawable(getContext(), R.mipmap.contract_icon);
        final Drawable expand = ContextCompat.getDrawable(getContext(), R.mipmap.expand_icon);

        final int cell_layout = R.layout.servicing_list_item_full;


        mAdapter = new ArrayAdapter<JSONObject>(getActivity(), cell_layout, mObjectList ){
            public int getCount(){
                int total = super.getCount();
                for (int i=0; i<mGroupsStatus.size(); i++){
                    if (!mGroupsStatus.get(i)){
                        // Hidden, so remove the number of items in this group
                        total-= mGroupsCount.get(i);
                    }
                }
                return total;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                // Get the data item for this position
                int altered_position = position;
                int next_position = 0;
                for (int i=0; i<mGroupsStatus.size(); i++){
                    int offset = mGroupsCount.get(i);
                    next_position+=offset+1;
                    if (next_position>position+offset) break;
                    if (!mGroupsStatus.get(i)) {
                        // Hidden, so remove the number of items in this group
                        altered_position += offset;
                        next_position-= offset;
                    }

                }

                JSONObject o = getItem(altered_position);

                if (o.has("group_name") || o.length() == 0){
                    // Group Header Cell

                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.object_list_group_header, parent, false);
                    convertView.setTag(CELL_TYPE_HEADER);

                    TextView name = (TextView) convertView.findViewById(R.id.name);

                    String g_name = "Ungrouped";
                    try {
                        g_name = o.getString("group_name");
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Log.i("OBJECT", o.toString());
                    }

                    name.setText(g_name);

                    ImageView button_sort = (ImageView) convertView.findViewById(R.id.button_sort);
                    if (position==0){
                        button_sort.setVisibility(View.VISIBLE);
                        button_sort.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                showReorder();
                            }
                        });
                    }

                    ImageView button_hideshow = (ImageView) convertView.findViewById(R.id.button_hideshow);
                    final int group_index = mGroupsList.indexOf(g_name);
                    Log.i("PPP", "NAME = "+g_name);
                    if (group_index>=0) {
                        if (mGroupsStatus.get(group_index)) {
                            // Group is Showing (icon should be -)
                            button_hideshow.setImageDrawable(contract);
                        } else {
                            // Group is Hidden (icon should be +)
                            button_hideshow.setImageDrawable(expand);
                        }
                    }
                    button_hideshow.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            hideshowGroup((ImageView)v, group_index);
                        }
                    });
                } else {
                    // Tracker Cell

                    if (convertView == null || convertView.getTag() == CELL_TYPE_HEADER) {
                        convertView = LayoutInflater.from(getContext()).inflate(cell_layout, parent, false);
                    }
                    convertView.setTag(CELL_TYPE_OBJECT);

                    String g_name = "";
                    try {
                        g_name = o.getString("group");
                    } catch (JSONException e){}

                    int group_index = mGroupsList.indexOf(g_name);
                    if (group_index>=0 && group_index<mGroupsStatus.size()) {
                        if (mGroupsStatus.get(group_index)) {
                            convertView.setVisibility(View.VISIBLE);
                        } else {
                            convertView.setVisibility(View.GONE);
                            return convertView;
                        }
                    }

                    // Lookup view for data population
                    TextView name = (TextView) convertView.findViewById(R.id.name);
                    ImageView icon = (ImageView) convertView.findViewById(R.id.icon);
                    TextView keys = (TextView) convertView.findViewById(R.id.keys);
                    TextView values = (TextView) convertView.findViewById(R.id.values);

                    // Populate the data into the template view using the data object
                    String o_name = "";
                    String o_icon = "";
                    String o_keys ="";
                    String o_values = "";
                    SpannableStringBuilder spannable_values = new SpannableStringBuilder("");
                    // Branch between original and new version with status colours
                    boolean hasStatusKey = false;

                    try {
                        o_name = o.getString("name");
                        o_icon = o.getString("icon");
                        String services = o.getString("services");
                        JSONArray array = new JSONArray(services);

                        for (int i=0; i<array.length(); i++){
                            JSONObject data = array.getJSONObject(i);
                            o_keys+=String.format("%s:\n", data.getString("name"));
                            o_values+=String.format("%s\n", data.getString("info"));

                            if (data.has("raw") && data.has("status")){
                                hasStatusKey = true;
                                JSONArray raw = data.getJSONArray("raw");
                                JSONArray status = data.getJSONArray("status");

                                spannable_values.append("Left (");
                                for (int j=0; j<raw.length(); j++){
                                    int start_length = spannable_values.length();
                                    spannable_values.append(raw.getString(j));

                                    // Make bold
                                    spannable_values.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), start_length, spannable_values.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

                                    // Add icon
                                    String colour = status.getString(j);
                                    if (colour.equals("green")
                                            || colour.equals("amber")
                                            || colour.equals("red")) {
                                        spannable_values.append("  ");
                                        Drawable bd = ContextCompat.getDrawable(getActivity(), getResources().getIdentifier(colour, "drawable", getActivity().getPackageName()));
                                        bd.setBounds(0, 0, bd.getIntrinsicWidth(), bd.getIntrinsicHeight());
                                        spannable_values.setSpan(new ImageSpan(bd, ImageSpan.ALIGN_BASELINE), spannable_values.length() -1, spannable_values.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                                    }
                                    spannable_values.append(", ");

                                }
                                spannable_values.delete(spannable_values.length()-2, spannable_values.length());
                                spannable_values.append(")\n");

                            }

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    keys.setText(o_keys);
                    if (!hasStatusKey) {
                        values.setText(o_values);
                    } else {
                        values.setText(spannable_values);
                    }

                    name.setText(o_name);

                    if (!o_icon.equals("")) {
                        String base = getString(R.string.image_base);
                        Picasso.with(getActivity()).load(base + o_icon).into(icon);
                    } else {
                        icon.setImageDrawable(null);
                    }
                }
                // Return the completed view to render on screen
                return convertView;
            }
        };

        mList.setAdapter(mAdapter);

    }

    private void setData(JSONObject data){

        JSONArray objects = null;
        JSONArray groups = null;
        ArrayList<String> arr_groups = new ArrayList<>();
        mGroupsList = new ArrayList<>();
        while (mObjectList.size()>0) mObjectList.remove(0);
        mGroupsCount = new ArrayList<>();

        if (data != null) {
            try {
                objects = data.getJSONArray("data");
                groups = data.getJSONArray("groups");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (objects != null) {
            Log.i("PPP", "OBJECTS");
            String previous_group = "";
            String name = "";
            Integer counter = 0;
            boolean skip = true;
            for (int i = 0; i < objects.length(); i++) {
                JSONObject object = null;
                try {
                    object = objects.getJSONObject(i);
                    if (object != null) {
                        String group = object.getString("group_id");
                        if (!group.equals(previous_group)) {
                            previous_group = group;
                            if (group.equals("0")) {
                                name = "Ungrouped";
                                JSONObject ungrouped = new JSONObject();
                                ungrouped.put("group_name", name);
                                mObjectList.add(ungrouped);
                            } else {
                                for (int j = 0; j < groups.length(); j++) {
                                    JSONObject gname = groups.getJSONObject(j);
                                    if (gname.getString("group_id").equals(previous_group)) {
                                        mObjectList.add(gname);
                                        name = gname.getString("group_name");
                                    }
                                }
                            }
                            arr_groups.add(name);
                            mGroupsList.add(name); // Set Groups list as a default if no order hasbeen set yet
                            if (!skip)
                                mGroupsCount.add(counter);
                            skip = false;
                            counter = 0;
                        }
                        object.put("group", name);
                        mObjectList.add(object);
                        counter++;

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
            mGroupsCount.add(counter);
/*
            for (int i = 0; i < mObjectList.size(); i++) {
                try {
                    Log.i("PPP", "ARR(PRE):" + mObjectList.get(i).getString("name"));
                } catch (JSONException e){
                    Log.i("PPP", "ARR(PRE):***");
                };
            }
            Log.i("PPP", "ARR(PRE)---");

            Log.i("PPP", "mGroupsList (Natural): "+mGroupsList.toString());
*/

            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
            String user_id = sharedPreferences.getString("user_id", "");
            String str_groups_list =  sharedPreferences.getString("servicing_group_names_order_"+user_id, null);
            if (str_groups_list != null) {
                //Log.i("PPP", "strGroupsList: "+str_groups_list);
                mGroupsList = new ArrayList<>(Arrays.asList(str_groups_list.split("\\|\\|\\|")));
                //Log.i("PPP", "mGroupsList: "+mGroupsList.toString());
                for (int i=0; i<mGroupsList.size(); i++){
                    int sourceIndex = arr_groups.indexOf(mGroupsList.get(i));
                    if (sourceIndex>=0){
                        groups = this.reorderArray(groups, sourceIndex,i);
                        mObjectList = this.reorderObjects(mObjectList, sourceIndex, i);
                        arr_groups = this.reorderString(arr_groups, sourceIndex, i);
                        mGroupsCount = this.reorderInteger(mGroupsCount, sourceIndex, i);
                    }
                }

            }

            // Initialise the status (hidden/shown) array
            mGroupsStatus = new ArrayList<>();
            mGroupsStatus.add(true);
            String str_group_status =  sharedPreferences.getString("servicing_group_status_"+user_id, null);
            if (str_group_status != null) {
                mGroupsStatus = new ArrayList<>();
                for (int i=0; i<str_group_status.length(); i++){
                    mGroupsStatus.add((str_group_status.charAt(i) == 49)); // Ascii 49 = (String) "1" = (Boolean) true
                }
            }

            // Add new items to the end if required
            if (mGroupsStatus.size() < mGroupsList.size()){
                for (int i=mGroupsStatus.size(); i<mGroupsList.size(); i++){
                    mGroupsStatus.add(true);
                }
            }
/*
            Log.i("PPP", "NAMES:"+mGroupsList.toString());
            Log.i("PPP", "COUNTS:"+mGroupsCount.toString());
            Log.i("PPP", "STATUS:"+mGroupsStatus.toString());

            for (int i = 0; i < mObjectList.size(); i++) {
                try {
                    Log.i("PPP", "ARR(FINAL):" + mObjectList.get(i).getString("name"));
                } catch (JSONException e){
                    Log.i("PPP", "ARR(FINAL):***");
                };
            }
            Log.i("PPP", "ARR(FINAL)---");
*/
        }
    }

    private ArrayList<String> reorderString(ArrayList<String> arr, int src, int dst) {
        if (src == dst) return arr;

        String tmp = arr.get(dst);
        arr.set(dst, arr.get(src));
        arr.set(src, tmp);

        return arr;
    }

    private ArrayList<Integer> reorderInteger(ArrayList<Integer> arr, int src, int dst) {
        if (src == dst) return arr;

        Integer tmp = arr.get(dst);
        arr.set(dst, arr.get(src));
        arr.set(src, tmp);

        return arr;
    }

    private ArrayList<JSONObject> reorderObjects(ArrayList<JSONObject> arr, int src, int dst){
        if (src == dst) return arr;
        if (dst>src){
            // Swap to normalise order (dst, src)
            int tmp = dst;
            dst = src;
            src = tmp;
        }

        ArrayList<JSONObject> tmp = new ArrayList<>();
        int src_count = mGroupsCount.get(src);
        int src_offset = 0;

        for (int i=0; i<src; i++){
            src_offset+= mGroupsCount.get(i)+1;
        }

        int dst_count = mGroupsCount.get(dst);
        int dst_offset = 0;

        for (int i=0; i<dst; i++){
            dst_offset+= mGroupsCount.get(i)+1;
        }


        // Save dst...src to tmp
        for (int i=dst_offset; i<=src_offset+src_count; i++){
            tmp.add(arr.get(i));
        }

        // Start replacing from src (end)
        int cursor = src_offset - dst_offset;
        for (int i=dst_offset; i<=src_offset+src_count; i++) {
            arr.set(i, tmp.get(cursor++));
            if (cursor == tmp.size()) cursor = dst_count + 1; // When end is reached copy the middle
            if (cursor == src_offset - dst_offset) cursor = 0; // Finally copy the start
        }

        return arr;
    }

    private JSONArray reorderArray(JSONArray arr, int src, int dst){
        if (src == dst) return arr;

        try {
            Object tmp = arr.get(dst);
            arr.put(dst, arr.get(src));
        } catch (JSONException e){
            e.printStackTrace();
        }

        return arr;
    }

    @Override
    public void onStart(){
        super.onStart();

    }

    public void onAPISuccess(String request, JSONObject data){
        if (request.equals(API.API_GET_OBJECTS)) {
            try {
                mRawData = new JSONObject(data.toString());
                setData(data);
                mAdapter.notifyDataSetChanged();
            } catch (JSONException e){};
        }
    }

    public void onAPIError(String request, JSONObject data){
        Log.d(TAG, "Error: " + request);

    }

    public void onCheckAll(boolean checked) {
        mCheckAll = checked;

        for (int i=0; i<mObjectList.size(); i++){
            JSONObject object = mObjectList.get(i);
            try {
                object.put("selected", checked);
            } catch (JSONException e){
                e.printStackTrace();
            }
        }
        mAdapter.notifyDataSetChanged();
    }

    private void showReorder(){
        ((MainActivity)getActivity()).showReorderGroups(mGroupsList, mGroupsStatus, "servicing_");
    }

    private void hideshowGroup(ImageView button, int index){
        Drawable contract = ContextCompat.getDrawable(getContext(), R.mipmap.contract_icon);
        Drawable expand = ContextCompat.getDrawable(getContext(), R.mipmap.expand_icon);

        if (mGroupsStatus.get(index)){
            mGroupsStatus.set(index, false);
            // Group is Showing (icon should be -)
            button.setImageDrawable(expand);
        } else {
            mGroupsStatus.set(index, true);
            // Group is Hidden (icon should be +)
            button.setImageDrawable(contract);
        }

        mAdapter.notifyDataSetChanged();

        // Save to Prefs as string of zeros (false) and ones (true)
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String user_id = sharedPreferences.getString("user_id", "");
        SharedPreferences.Editor e = sharedPreferences.edit();
        String str_status = "";
        for (int i=0; i<mGroupsStatus.size(); i++){
            str_status+= (mGroupsStatus.get(i))?"1":"0";
        }
        e.putString("servicing_group_status_"+user_id, str_status);
        //e.remove("group_names_order_"+user_id);
        e.apply();
    }
}
