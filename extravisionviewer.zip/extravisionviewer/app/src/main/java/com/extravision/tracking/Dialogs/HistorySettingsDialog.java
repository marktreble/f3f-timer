package com.extravision.tracking.Dialogs;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.extravision.tracking.R;

/**
 * Created by marktreble on 06/01/2016.
 */
public class HistorySettingsDialog extends DialogFragment {

    private ViewGroup mView;
    private boolean mPinValid;

    public String mOldest_date;

    private DialogFragment mFragment;

    public static HistorySettingsDialog newInstance() {

        HistorySettingsDialog settingsDialog = new HistorySettingsDialog();
        return settingsDialog;
    }

    public interface HistorySettingsDialogListener {

        void onHistorySettingsChanged();
    }

    public HistorySettingsDialogListener mListener;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(STYLE_NO_TITLE);
        mView = (ViewGroup)inflater.inflate(R.layout.history_settings_dialog, null);

        if (savedInstanceState != null){
            mOldest_date = savedInstanceState.getString("oldestDate");
        }

        mFragment = this;

        Button ok = (Button)mView.findViewById(R.id.btn_ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.onCancel(getDialog());
            }
        });

        ImageView close = (ImageView)mView.findViewById(R.id.close_btn);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.onCancel(getDialog());
            }
        });

        Spinner sp_date = (Spinner)mView.findViewById(R.id.show_date);
        CheckBox cb_route = (CheckBox)mView.findViewById(R.id.show_route);
        CheckBox cb_stops = (CheckBox)mView.findViewById(R.id.show_stops);
        CheckBox cb_events = (CheckBox)mView.findViewById(R.id.show_events);
        CheckBox cb_journey_updates = (CheckBox)mView.findViewById(R.id.show_journey_updates);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String show_date = sharedPreferences.getString("show_date", "today");

        int selected = 0;
        if (show_date.equals("yesterday")) selected = 1;

        List<String> options = new ArrayList<>();
        options.add("Today");
        options.add("Yesterday");
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, -2);
        Date next = calendar.getTime();
        int safety = 200;
        try {
            Date last = fmt.parse(mOldest_date);
            while (next.compareTo(last)>=0 && safety-->0) {
                String date = fmt.format(next);
                options.add(date);
                if (show_date.equals(date)) selected = options.size()-1;

                calendar.add(Calendar.DAY_OF_YEAR, -1);
                next = calendar.getTime();
            }
        } catch (ParseException e){
            e.printStackTrace();
        }

        String[] date_options = options.toArray(new String[options.size()]);
        ArrayAdapter<String> sadapter = new ArrayAdapter<>(getActivity(), R.layout.custom_spinner_item, date_options);
        sp_date.setAdapter(sadapter);
        sp_date.setSelection(selected);

        boolean show_route = sharedPreferences.getBoolean("show_route", true);
        cb_route.setChecked(show_route);
        boolean show_stops = sharedPreferences.getBoolean("show_stops", true);
        cb_stops.setChecked(show_stops);
        boolean show_events = sharedPreferences.getBoolean("show_events", true);
        cb_events.setChecked(show_events);
        boolean show_journey_updates = sharedPreferences.getBoolean("show_journey_updates", true);
        cb_journey_updates.setChecked(show_journey_updates);

        return mView;
    }

    @Override
    public void onSaveInstanceState(Bundle outState){

        outState.putString("oldestDate", mOldest_date);

        super.onSaveInstanceState(outState);
    }

    @Override
    public void onStart() {
        super.onStart();

        if (getDialog() == null)
            return;

        getDialog().getWindow().setWindowAnimations(R.style.slide);

        getDialog().getWindow().setGravity(Gravity.CENTER);

        int screenWidth = (int) getResources().getDisplayMetrics().widthPixels;
        getDialog().getWindow().setLayout(screenWidth,
                RelativeLayout.LayoutParams.WRAP_CONTENT);

        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        Spinner sp_date = (Spinner)mView.findViewById(R.id.show_date);
        CheckBox cb_route = (CheckBox)mView.findViewById(R.id.show_route);
        CheckBox cb_stops = (CheckBox)mView.findViewById(R.id.show_stops);
        CheckBox cb_events = (CheckBox)mView.findViewById(R.id.show_events);
        CheckBox cb_journey_updates = (CheckBox)mView.findViewById(R.id.show_journey_updates);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());

        sharedPreferences.edit()
                .putString("show_date", sp_date.getSelectedItem().toString().toLowerCase())
                .putBoolean("show_route", cb_route.isChecked())
                .putBoolean("show_stops", cb_stops.isChecked())
                .putBoolean("show_events", cb_events.isChecked())
                .putBoolean("show_journey_updates", cb_journey_updates.isChecked())
                .apply();

        if (mListener != null)
            mListener.onHistorySettingsChanged();

        super.onCancel(dialog);
        mFragment.dismissAllowingStateLoss();

    }

    @Override
    public void onDismiss(DialogInterface dialog){


        super.onDismiss(dialog);
    }
}
