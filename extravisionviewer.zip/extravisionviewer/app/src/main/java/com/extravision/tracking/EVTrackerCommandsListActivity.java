package com.extravision.tracking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.extravision.tracking.Dialogs.SettingsDialog;
import com.extravision.tracking.Dialogs.TrackerSettingsDialog;
import com.extravision.tracking.Fragments.NotificationsListFragment;
import com.extravision.tracking.Fragments.TrackerCommandsListFragment;
import com.extravision.tracking.Managers.API;

import org.json.JSONObject;

/**
 * Created by marktreble on 17/03/2016.
 */
public class EVTrackerCommandsListActivity extends FragmentActivity
        implements View.OnClickListener, API.APICallbackInterface {

    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */

    private Context mContext;

    public static final Handler mHandler = new Handler();

    public static final String LIST_FRAGMENT = "List Fragment";

    private static final String SETTINGS_DIALOG = "Settings Dialog";
    private static final String TRACKER_SETTINGS_DIALOG = "Tracker Settings Dialog";

    // These booleans record that the user has requested a navigation item in the app
    // rather than pressing home to put app into the background
    // Setting this cancels the app kill timeout in onPause
    public boolean mBackPressed;
    public boolean mPermissionRequested;

    private Button mBtnBack;
    private Button mBtnLogout;
    private ImageButton mBtn_tracker_settings;
    private ImageButton mBtn_settings;

    private TextView mTitle;

    private Fragment mFragment;

    public String mIds;

    public ProgressDialog pDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;

        mBtnBack = (Button)findViewById(R.id.btn_back);
        mBtnBack.setVisibility(View.VISIBLE);
        mBtnBack.setOnClickListener(this);

        mBtnLogout = (Button)findViewById(R.id.btn_logout);
        mBtnLogout.setVisibility(View.GONE);

        mBtn_tracker_settings = (ImageButton)findViewById(R.id.btn_tracker_settings);
        mBtn_tracker_settings.setVisibility(View.VISIBLE);
        mBtn_tracker_settings.setOnClickListener(this);

        mBtn_settings = (ImageButton)findViewById(R.id.btn_settings);
        mBtn_settings.setVisibility(View.GONE);
        mBtn_settings.setOnClickListener(this);

        mTitle = (TextView)findViewById(R.id.title);

        Bundle extras = getIntent().getExtras();
        String title = extras.getString("title");
        mTitle.setText(title);

        mIds = extras.getString("ids");


        // Set the scene
        FragmentManager fm = this.getSupportFragmentManager();
        if (savedInstanceState == null) {
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);

            // Add Notifications List Fragment

            FragmentTransaction trans = fm.beginTransaction();
            TrackerCommandsListFragment frag = new TrackerCommandsListFragment();
            frag.setRetainInstance(true);
            //frag.delegate = this;
            trans.replace(R.id.main_content, frag, LIST_FRAGMENT);
            trans.commit();
            mFragment = frag;

        } else {
            mFragment = fm.findFragmentByTag(LIST_FRAGMENT);
        }

    }

    @Override
    public void onBackPressed(){
        mBackPressed = true;
        super.onBackPressed();

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        // Must call super or the map will not be restored
        super.onSaveInstanceState(outState);
    }

    // Runnable to shutdown application after 2 seconds of background
    // This forces the app to restart and require the PIN number
    Runnable shutdown = new Runnable() {
        @Override
        public void run() {
            ActivityCompat.finishAffinity((EVTrackerCommandsListActivity) mContext);
            System.exit(0);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();

        mPermissionRequested = false;

        // Cancel Shutdown timeout
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }

        /*
        registerReceiver(smsSentReceiver, new IntentFilter("SMS_SENT"));
        registerReceiver(smsReceivedReceiver, new IntentFilter("SMS_RECEIVED"));
        */
    }

    @Override
    protected void onPause() {
        super.onPause();

        /*
        unregisterReceiver(smsSentReceiver);
        unregisterReceiver(smsReceivedReceiver);
*/

        if (mBackPressed) return;
        if (mPermissionRequested) return;

        // Shutdown after SHUTDOWN_TIMOUT seconds
        mHandler.postDelayed(shutdown, MainActivity.SHUTDOWN_TIMOUT);

    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn_back:
                onBackPressed();
                break;
            case R.id.btn_settings:
                showSettings();
                break;
            case R.id.btn_tracker_settings:
                showTrackerSettings();
                break;
        }
    }

    public void showSettings(){
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(SETTINGS_DIALOG) == null) {
            final SettingsDialog lDialog = SettingsDialog.newInstance();
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, SETTINGS_DIALOG).commitAllowingStateLoss();
        }
    }

    public void showTrackerSettings(){
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(TRACKER_SETTINGS_DIALOG) == null) {
            final TrackerSettingsDialog lDialog = TrackerSettingsDialog.newInstance();
            lDialog.mObject_id = mIds;
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, TRACKER_SETTINGS_DIALOG).commitAllowingStateLoss();
        }
    }


    public void showSMSSending(){
        pDialog = new ProgressDialog(this);
        pDialog.setTitle("Sending Command");
        pDialog.show();
    }

    public void hideSMSSending(){
        if (pDialog != null)
            pDialog.hide();

        pDialog = null;
    }

    /*
    BroadcastReceiver smsSentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            pDialog.hide();
            String result = "";
            switch(getResultCode()) {
                case Activity.RESULT_OK:
                    result = "Command Sent";
                    break;
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    result = "Command failed (reason unknown)";
                    break;
                case SmsManager.RESULT_ERROR_RADIO_OFF:
                    result = "Command failed (Radio Off) - Is your device in Aeroplane mode?";
                    break;
                case SmsManager.RESULT_ERROR_NULL_PDU:
                    result = "No PDU defined";
                    break;
                case SmsManager.RESULT_ERROR_NO_SERVICE:
                    result = "Command failed. SMS service unavailable";
                    break;
            }
            Toast.makeText(getApplicationContext(), result,
                    Toast.LENGTH_SHORT).show();
        }
    };

    BroadcastReceiver smsReceivedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            pDialog.hide();
            String result = "";
            switch(getResultCode()) {
                case Activity.RESULT_OK:
                    break;
                case Activity.RESULT_CANCELED:
                    Toast.makeText(getApplicationContext(), "Command was not delivered. Perhaps the device is off the network at the moment.",
                            Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };
    */

    public void AerisAPIResponse(String response){
        hideSMSSending();

        String result = response;
        if (response.substring(0,10).equals("{\"address\"")) result = "Command Sent";

        Toast.makeText(getApplicationContext(), result,
                Toast.LENGTH_SHORT).show();
    }

    /* Response from GPRS API Proxy */
    public void onAPISuccess(String request, JSONObject data){
        if (request.equals(API.API_SEND_GPRS_COMMAND)) {
            hideSMSSending();
            Log.i("GPRS", request);
            Log.i("GPRS", "SUCCESS"+data.toString());
        }
    }

    public void onAPIError(String request, JSONObject data){
        if (request.equals(API.API_SEND_GPRS_COMMAND)) {
            hideSMSSending();
            Log.i("GPRS", request);
            Toast.makeText(getApplicationContext(), "Command was not delivered. Bad response from server.",
                    Toast.LENGTH_SHORT).show();


        }

    }
}
