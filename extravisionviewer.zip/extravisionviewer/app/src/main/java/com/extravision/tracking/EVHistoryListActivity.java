package com.extravision.tracking;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.extravision.tracking.Dialogs.HistorySettingsDialog;
import com.extravision.tracking.Dialogs.SettingsDialog;
import com.extravision.tracking.Fragments.HistoryListFragment;
import com.extravision.tracking.Managers.API;

/**
 * Created by marktreble on 05/01/2016.
 */
public class EVHistoryListActivity extends FragmentActivity
    implements View.OnClickListener {

    private static final int FRAG_HISTORY_LIST = 1;

    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */
    private API mAPITask = null;

    // UI references.
    int mCurrentFrag;

    private Context mContext;
    private String mToken;
    private String mIds;
    private String mOldest_date;
    public JSONObject mData;

    public static final Handler mHandler = new Handler();

    public static final String LIST_FRAGMENT = "List Fragment";

    public static final String INFO_DIALOG = "Info Dialog";
    private static final String SETTINGS_DIALOG = "Settings Dialog";
    private static final String HISTORY_SETTINGS_DIALOG = "History Settings Dialog";


    // These booleans record that the user has requested a navigation item in the app
    // rather than pressing home to put app into the background
    // Setting this cancels the app kill timeout in onPause
    public boolean mBackPressed;

    private Button mBtnLogout;
    private Button mBtnBack;

    private Fragment mFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;

        // Find retained views and add listeners
        mBtnLogout = (Button)findViewById(R.id.btn_logout);
        mBtnLogout.setOnClickListener(this);

        mBtnBack = (Button)findViewById(R.id.btn_back);
        mBtnBack.setOnClickListener(this);

        ImageButton btn_settings = (ImageButton)findViewById(R.id.btn_settings);
        //btn_settings.setOnClickListener(this);
        btn_settings.setVisibility(View.GONE);

        ImageButton btn_history_settings = (ImageButton)findViewById(R.id.btn_history_settings);
        btn_history_settings.setVisibility(View.VISIBLE);
        btn_history_settings.setOnClickListener(this);

        Bundle extras = getIntent().getExtras();
        String title = extras.getString("title");

        TextView lbl_title = (TextView)findViewById(R.id.title);
        lbl_title.setText(title);

        mToken = extras.getString("token");
        mIds = extras.getString("ids");
        mOldest_date = extras.getString("oldest_date");

        // Set the scene
        FragmentManager fm = this.getSupportFragmentManager();
        if (savedInstanceState == null) {
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            String token = preferences.getString("token", null);
            if (token == null) finish();
            mToken = token;

            mCurrentFrag = FRAG_HISTORY_LIST;

            // Add Objects List Fragment

            FragmentTransaction trans = fm.beginTransaction();
            HistoryListFragment frag = new HistoryListFragment();
            frag.setRetainInstance(true);
            //frag.delegate = this;
            trans.replace(R.id.main_content, frag, LIST_FRAGMENT);
            trans.commit();
            mFragment = frag;

            // Call api to download data
            getHistory(frag);

        } else {
            mToken = savedInstanceState.getString("token");
            mCurrentFrag = savedInstanceState.getInt("currentFrag");
            mFragment = fm.findFragmentByTag(LIST_FRAGMENT);
            HistorySettingsDialog settings = (HistorySettingsDialog)fm.findFragmentByTag(HISTORY_SETTINGS_DIALOG);
            if (settings != null) {
                settings.mListener = (HistorySettingsDialog.HistorySettingsDialogListener)mFragment;
            }
            String data;
            data = savedInstanceState.getString("data");
            try {
                mData = new JSONObject(data);
            } catch (JSONException e){
                e.printStackTrace();
            }
        }

        showBackButton();
    }

    @Override
    public void onBackPressed(){
        mBackPressed = true;
        super.onBackPressed();

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        // Save the data
        outState.putSerializable("data", mData.toString());

        // Must call super or the map will not be restored
        super.onSaveInstanceState(outState);
    }

    // Runnable to shutdown application after 2 seconds of background
    // This forces the app to restart and require the PIN number
    Runnable shutdown = new Runnable() {
        @Override
        public void run() {
            ActivityCompat.finishAffinity((EVHistoryListActivity)mContext);
            System.exit(0);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();

        // Cancel Shutdown timeout
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mBackPressed) return;
        // Shutdown after SHUTDOWN_TIMOUT seconds
        mHandler.postDelayed(shutdown, MainActivity.SHUTDOWN_TIMOUT);
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn_back:
                onBackPressed();
                break;
            case R.id.btn_settings:
                showSettings();
                break;
            case R.id.btn_history_settings:
                showHistorySettings();
                break;
        }
    }

    private void showBackButton(){
        mBtnLogout.setVisibility(View.GONE);
        mBtnBack.setVisibility(View.VISIBLE);
    }

    private void showLogoutButton(){
        mBtnLogout.setVisibility(View.VISIBLE);
        mBtnBack.setVisibility(View.GONE);
    }

    private void showSettings(){
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(SETTINGS_DIALOG) == null) {
            final SettingsDialog lDialog = SettingsDialog.newInstance();
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, SETTINGS_DIALOG).commitAllowingStateLoss();
        }
    }

    private void showHistorySettings(){
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(HISTORY_SETTINGS_DIALOG) == null) {
            final HistorySettingsDialog lDialog = HistorySettingsDialog.newInstance();
            lDialog.mListener = (HistorySettingsDialog.HistorySettingsDialogListener)mFragment;
            lDialog.mOldest_date = mOldest_date;

            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, HISTORY_SETTINGS_DIALOG).commitAllowingStateLoss();
        }
    }

    public void getHistory(API.APICallbackInterface callback){
        // Call the api on behalf of the fragment
        // Data will be returned to fragment's APIResponse callback methods
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String today = simpleDateFormat.format(cal.getTime());
        cal.add(Calendar.DATE, -1);
        String yesterday = simpleDateFormat.format(cal.getTime());

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        String date = preferences.getString("show_date", "today");
        ((HistoryListFragment)mFragment).mDate = date;

        if (date.equals("today")) date = today;
        if (date.equals("yesterday")) date = yesterday;


        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_GET_HISTORY);
        params.put("t", mToken);
        params.put("i", mIds);
        params.put("d", date);
        params.put("msd", "1");
        params.put("w", "light");

        mAPITask = new API();
        mAPITask.mCallback = callback;
        mAPITask.request = API.API_GET_HISTORY;
        mAPITask.makeAPICall(mContext, API.httpmethod.GET, params);

    }

}
