package com.extravision.tracking;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.extravision.tracking.Dialogs.NotificationSettingsDialog;
import com.extravision.tracking.Dialogs.SettingsDialog;
import com.extravision.tracking.Fragments.NotificationsListFragment;
import com.extravision.tracking.Managers.API;

import java.util.HashMap;
import java.util.Map;


/**
 * Created by marktreble on 17/03/2016.
 */
public class EVNotificationsActivity extends FragmentActivity
    implements View.OnClickListener, NotificationSettingsDialog.NotificationSettingsDialogListener {

    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */

    private Context mContext;

    public static final Handler mHandler = new Handler();

    public static final String LIST_FRAGMENT = "List Fragment";
    private static final String SETTINGS_DIALOG = "Settings Dialog";

    // These booleans record that the user has requested a navigation item in the app
    // rather than pressing home to put app into the background
    // Setting this cancels the app kill timeout in onPause
    public boolean mBackPressed;

    private Button mBtnBack;
    private Button mBtnLogout;
    private ImageButton mBtn_notifications;
    private ImageButton mBtn_settings;
    private ImageButton mBtn_delete;

    private TextView mTitle;

    private Fragment mFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;

        mBtnBack = (Button)findViewById(R.id.btn_back);
        mBtnBack.setVisibility(View.VISIBLE);
        mBtnBack.setOnClickListener(this);
        mBtnBack.setText("Cancel");

        mBtnLogout = (Button)findViewById(R.id.btn_logout);
        mBtnLogout.setVisibility(View.GONE);

        mBtn_settings = (ImageButton)findViewById(R.id.btn_settings);
        mBtn_settings.setVisibility(View.VISIBLE);
        mBtn_settings.setOnClickListener(this);

        mBtn_delete = (ImageButton)findViewById(R.id.btn_delete);
        mBtn_delete.setVisibility(View.VISIBLE);
        mBtn_delete.setOnClickListener(this);

        mTitle = (TextView)findViewById(R.id.title);
        mTitle.setText("");


        // Set the scene
        FragmentManager fm = this.getSupportFragmentManager();
        if (savedInstanceState == null) {
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);

            // Add Notifications List Fragment

            FragmentTransaction trans = fm.beginTransaction();
            NotificationsListFragment frag = new NotificationsListFragment();
            frag.setRetainInstance(true);
            frag.delegate = this;
            trans.replace(R.id.main_content, frag, LIST_FRAGMENT);
            trans.commit();
            mFragment = frag;

        } else {
            mFragment = fm.findFragmentByTag(LIST_FRAGMENT);
        }

    }

    @Override
    public void onBackPressed(){
        mBackPressed = true;
        super.onBackPressed();

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        // Must call super or the map will not be restored
        super.onSaveInstanceState(outState);
    }

    // Runnable to shutdown application after 2 seconds of background
    // This forces the app to restart and require the PIN number
    Runnable shutdown = new Runnable() {
        @Override
        public void run() {
            ActivityCompat.finishAffinity((EVNotificationsActivity) mContext);
            System.exit(0);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();

        // Cancel Shutdown timeout
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mBackPressed) return;
        // Shutdown after SHUTDOWN_TIMOUT seconds
        mHandler.postDelayed(shutdown, MainActivity.SHUTDOWN_TIMOUT);
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn_back:
                onBackPressed();
                break;
            case R.id.btn_settings:
                showNotificationSettings();
                break;
            case R.id.btn_delete:
                deleteNotifications();
                break;
        }
    }

    public void showNotificationSettings(){
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(SETTINGS_DIALOG) == null) {
            final NotificationSettingsDialog lDialog = NotificationSettingsDialog.newInstance();
            lDialog.mListener = this;
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, SETTINGS_DIALOG).commitAllowingStateLoss();
        }
    }

    public void onNotificationSettingsChanged() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        // update api
        String token = sharedPreferences.getString("token", null);
        String notifications = sharedPreferences.getString("notifications", null);
        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_SAVE_NOTIFICATION_SETTINGS);
        params.put("t", token);
        params.put("n", notifications);

        API apitask = new API();
        apitask.request = API.API_SAVE_NOTIFICATION_SETTINGS;
        apitask.makeAPICall(this, API.httpmethod.POST, params);


    }

    public void deleteNotifications(){
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.app_name))
                .setMessage("This will clear all your notifications. Are you sure you want to do this?")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        clearNotifications();
                    }
                })
                .create().show();
    }

    public void clearNotifications(){
        Log.i("OK", "CLEAR");
    }
}
