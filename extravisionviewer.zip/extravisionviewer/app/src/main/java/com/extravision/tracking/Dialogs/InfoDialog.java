package com.extravision.tracking.Dialogs;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import com.extravision.tracking.Managers.RGeocode;
import com.extravision.tracking.Managers.ReverseGeocoder;
import com.extravision.tracking.R;

/**
 * Created by marktreble on 06/01/2016.
 */
public class InfoDialog extends DialogFragment {

    private static final String TAG = "InfoDialog";

    private String mInfo;
    public boolean mFetchAddress;
    private String mPosition;
    private String mName;
    private TextView mAddress;

    public static InfoDialog newInstance(String info) {

        InfoDialog infoDialog = new InfoDialog();
        infoDialog.mInfo = info;
        return infoDialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            mInfo = savedInstanceState.getString("info");
        }

    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(STYLE_NO_TITLE);
        ViewGroup view = (ViewGroup)inflater.inflate(R.layout.info_dialog, null);

        ImageView close = (ImageView)view.findViewById(R.id.close_btn);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });

        try {
            ViewGroup content = (ViewGroup)view.findViewById(R.id.content);
            JSONObject data = new JSONObject(mInfo);
            Iterator<?> keys = data.keys();

            while (keys.hasNext()) {
                String key = (String) keys.next();
                if (data.get(key) instanceof String) {
                    // Ignore lat & lng values
                    if (key.equals("lat") ||key.equals("lng")) continue;
                    View row = inflater.inflate(R.layout.info_dialog_row, null);
                    row.setTag(key);
                    ((TextView)row.findViewById(R.id.key)).setText(key + ":");
                    ((TextView)row.findViewById(R.id.value)).setText(data.getString(key));
                    content.addView(row);
                }
            }

            View row =inflater.inflate(R.layout.info_dialog_button, null);
            content.addView(row);

            Button button = (Button)row.findViewById(R.id.btn_directions);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Uri gmmIntentUri = Uri.parse("google.navigation:q="+mPosition);
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
            });

            View row2 =inflater.inflate(R.layout.info_dialog_button2, null);
            content.addView(row2);

            Button button2 = (Button)row2.findViewById(R.id.btn_share);
            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String message = String.format("%s\n%s\n%s\nhttp://maps.google.com/?q=%s", mName, mAddress.getText().toString(), mPosition, mPosition.replace(" ", ""));
                    Intent sendIntent = new Intent(Intent.ACTION_VIEW);
                    sendIntent.setData(Uri.parse("sms:"));
                    sendIntent.putExtra("sms_body", message);
                    startActivity(sendIntent);

                }
            });


            // Requires fields Position (lat, lng), and Address (blank)
            if (mFetchAddress){
                // Fetch the address from the reverse geocoder in the background
                if (data.has("Position")) {
                    String[] latlng = data.getString("Position").split(",");
                    double lat = Double.parseDouble(latlng[0]);
                    double lng = Double.parseDouble(latlng[1]);
                    TextView address = null;
                    for (int i = 0; i < content.getChildCount(); i++) {
                        View v = content.getChildAt(i);
                        String tag = (String)v.getTag();
                        if (tag != null) {
                            Log.d("TAG", tag);
                            if (tag.equals("Address")) {
                                address = (TextView) v.findViewById(R.id.value);
                            }

                        }
                    }
                    if (address != null) {

                        RGeocode r = new RGeocode(getActivity(), lat, lng, (TextView) address.findViewById(R.id.value), null);
                        r.mDelimiter = "\n";
                        new Thread(r).start();
                        mAddress = address;
                    }
                    mPosition = data.getString("Position");
                    mName = data.getString("Object");
                }
            }
        } catch (JSONException e){
            e.printStackTrace();
        }

        return view;
    }

    @Override
    public void onSaveInstanceState(Bundle outState){
        outState.putString("info", mInfo);
        super.onSaveInstanceState(outState);
    }



    @Override
    public void onStart() {
        super.onStart();

        if (getDialog() == null)
            return;

        getDialog().getWindow().setWindowAnimations(R.style.slide);

        getDialog().getWindow().setGravity(Gravity.CENTER);

        int screenWidth = (int) getResources().getDisplayMetrics().widthPixels;
        getDialog().getWindow().setLayout(screenWidth,
                RelativeLayout.LayoutParams.WRAP_CONTENT);

        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }
}
