package com.extravision.tracking;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.SharedPreferencesCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.extravision.tracking.Dialogs.PinDialog;
import com.extravision.tracking.Managers.API;
import com.google.android.gms.common.api.GoogleApiClient;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity
        implements API.APICallbackInterface, PinDialog.PinDialogListener {

    private static final String PIN_DIALOG = "PIN Dialog";

    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */
    private API mAuthTask = null;

    // UI references.
    private AutoCompleteTextView mUsernameView;
    private EditText mPasswordView;
    private View mProgressView;
    private View mLoginFormView;
    private CheckBox mRemembermeView;

    private Context mContext;


    private String mUsername;
    private String mPassword;

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getWindow().getDecorView().setBackgroundColor(Color.WHITE);

        mContext = this;

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        String user_id = preferences.getString("user_id", "");
        String prefID = preferences.getString("prefID", user_id);
        String token = preferences.getString("token", null);
        String pin = preferences.getString("pin_number_" + prefID, null);
        boolean rememberme = preferences.getBoolean("rememberme", false);
        String username = preferences.getString("username", "");
        String password = preferences.getString("password", "");
        String ptoken = preferences.getString("ptoken", "");
        Log.d("PUSH TOKEN", ptoken);


        boolean pin_enabled = preferences.getBoolean("pin_enabled_" + prefID, false);
        if (token != null) {
            if (pin_enabled && pin != null && pin.length() == 4)
                loginSuccess(true, pin);
        }

        // Set up the login form.
        mUsernameView = (AutoCompleteTextView) findViewById(R.id.username);
        mPasswordView = (EditText) findViewById(R.id.password);
        mRemembermeView = (CheckBox) findViewById(R.id.remember_me);
        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
        if (rememberme) populateAutoComplete(username, password);

        // Add Listeners
        mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.login || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });

        Button mEmailSignInButton = (Button) findViewById(R.id.sign_in_button);
        mEmailSignInButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptLogin();
            }
        });

        String device = getDeviceId();

        TextView version = (TextView) findViewById(R.id.version);
        String str_version = String.format("Version %s%s (Install No. %s)", BuildConfig.VERSION_NAME, (BuildConfig.DEBUG)?" (DEBUG)":"", device);
        version.setText(str_version);
        version.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder adb = new AlertDialog.Builder(mContext);
                CharSequence items[] = new CharSequence[] {"SMS", "Email"};
                adb.setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
                        String device = sharedPreferences.getString("device_id", "");
                        switch (which){
                            case 0:
                                Intent sendIntent = new Intent(Intent.ACTION_VIEW);
                                sendIntent.setData(Uri.parse("sms:"));
                                sendIntent.putExtra("sms_body", device);
                                startActivity(sendIntent);
                                break;
                            case 1:

                                final Intent emailIntent = new Intent( android.content.Intent.ACTION_SEND);
                                emailIntent.setType("plain/text");
                                emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Extravision Tracking Install Number");
                                emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, device);
                                startActivity(Intent.createChooser(
                                        emailIntent, "Send mail..."));
                                break;
                        }
                    }
                });

                adb.setNegativeButton("Cancel", null);
                adb.setTitle("Send Install No. via");
                adb.show();
            }
        });
    }

    public void onPause() {
        super.onPause();

        if (mAuthTask != null) {
            mAuthTask.cancel();
        }
    }

    private void populateAutoComplete(String username, String password) {
        mRemembermeView.setChecked(true);
        mUsernameView.setText(username);
        mPasswordView.setText(password);
    }


    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private void attemptLogin() {
        if (mAuthTask != null) {
            return;
        }

        // Reset errors.
        mUsernameView.setError(null);
        mPasswordView.setError(null);

        // Store values at the time of the login attempt.
        String username = mUsernameView.getText().toString();
        String password = mPasswordView.getText().toString();
        boolean rememberme = mRemembermeView.isChecked();

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        SharedPreferences.Editor e = sharedPreferences.edit();
        e.putBoolean("rememberme", rememberme);
        if (rememberme) {
            e.putString("username", username);
            e.putString("password", password);
        } else {
            e.putString("username", "");
            e.putString("password", "");
        }
        e.apply();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password, if the user entered one.
        if (TextUtils.isEmpty(password)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid email address.
        if (TextUtils.isEmpty(username)) {
            mUsernameView.setError(getString(R.string.error_invalid_username));
            focusView = mUsernameView;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            showProgress(true);

            String device = getDeviceId();

            Map<String, String> params = new HashMap<>();
            params.put(API.ENDPOINT_KEY, API.API_LOGIN);
            params.put("u", username);
            params.put("d", device);
            params.put("p", password);

            mUsername = username;
            mPassword = password;

            mAuthTask = new API();
            mAuthTask.mCallback = this;
            mAuthTask.request = API.API_LOGIN;
            mAuthTask.makeAPICall(mContext, API.httpmethod.GET, params);

        }
    }

    public void onAPISuccess(String request, JSONObject data) {
        mAuthTask = null;
        showProgress(false);

        String type = "";
        String token = "";
        String user_id = "";
        String zones = "";
        String notifications ="";
        JSONArray users;
        try {
            type = data.getString("type");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (type.equals("user")) {
            try {
                token = data.getString("token");
                user_id = data.getString("user_id");
                zones = data.getString("zones");
                notifications = data.getString("notifications");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("token", token);
            editor.putString("user_id", user_id);
            editor.putString("prefID", user_id);
            editor.putString("zones", zones);
            editor.putString("notifications", notifications);
            SharedPreferencesCompat.EditorCompat.getInstance().apply(editor);

            loginSuccess(false, null); // Don't need to ask for pin
            finish();
        } else if (type.equals("super_admin")){
            try {
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("prefID", mUsername);
                SharedPreferencesCompat.EditorCompat.getInstance().apply(editor);
                users = data.getJSONArray("users");
                showSuperAdminLogin(users);

            } catch (JSONException e){
                e.printStackTrace();

            }
        }
    }

    public void onAPIError(String request, JSONObject data) {
        mAuthTask = null;
        showProgress(false);
        mPasswordView.setError(getString(R.string.error_incorrect_credentials));
        mPasswordView.requestFocus();
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    private void showSuperAdminLogin(JSONArray users){
        Intent i = new Intent(mContext, SuperAdminActivity.class);
        i.putExtra("users", users.toString());
        i.putExtra("username", mUsername.toString());
        i.putExtra("password", mPassword.toString());
        i.putExtra("deviceId", getDeviceId());
        startActivity(i);
        overridePendingTransition(R.anim.slide_in_right,
                R.anim.zoom_fade_exit);
    }

    private void loginSuccess(boolean pin_enabled, String pin) {
        if (pin_enabled) {
            FragmentManager fm = this.getSupportFragmentManager();
            if (fm.findFragmentByTag(PIN_DIALOG) == null) {
                final PinDialog pinDialog = PinDialog.newInstance();
                pinDialog.mListener = this;
                FragmentTransaction trans = fm.beginTransaction();

                trans.add(pinDialog, PIN_DIALOG).commitAllowingStateLoss();
            }
        } else {
            Intent i = new Intent(mContext, MainActivity.class);
            startActivity(i);
            overridePendingTransition(R.anim.slide_in_right,
                    R.anim.zoom_fade_exit);
            finish();
        }
    }

    public void onPINAccepted() {

        Intent i = new Intent(mContext, MainActivity.class);
        startActivity(i);
        overridePendingTransition(R.anim.slide_in_right,
                R.anim.zoom_fade_exit);
        finish();
    }

    private String getDeviceId(){
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);

        String device = sharedPreferences.getString("device_id", "");
        if (device.equals("")) {
            device = UUID.randomUUID().toString();
            sharedPreferences.edit().putString("device_id", device).apply();
        }
        return device;
    }


}

