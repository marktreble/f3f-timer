package com.extravision.tracking.Util;

import android.util.Log;

import java.nio.charset.Charset;

/**
 * Created by marktreble on 05/09/2016.
 */
public class Codec12 {
    private static final char[] HEX_CHARS = "0123456789ABCDEF".toCharArray();

    public String encode(String cmd){
        cmd+= "\r\n";

        String preamble = String.format("%08X", 0);
        String packet_len = String.format("%08X", 8 + cmd.length());
        String codec = String.format("%02X", 0x0C);
        String qty = String.format("%02X", 0x01);
        String type = String.format("%02X", 0x05);
        String size = String.format("%08X", cmd.length());
        String command = strhex(cmd);

        String crcrange = codec + qty + type + size + command + qty;

        String crc = CRC(hexstr(crcrange).getBytes(Charset.forName("US-ASCII")));

        String coded = (preamble + packet_len + crcrange + crc).toUpperCase();
        return coded;
    }

    public String decode(String response){
        String preamble = response.substring(0, 8);
        String packet_len =response.substring(8, 16);
        String codec = response.substring(16, 18);
        String qty = response.substring(18, 20);
        String type = response.substring(20, 22);
        String size = response.substring(22, 30);
        String command = response.substring(30, 30 + (Integer.parseInt(size, 16)*2));
        String crc = response.substring(30 + (Integer.parseInt(size, 16)*2) + 2);

        String crcrange = codec + qty + type + size + command + qty;

        String crc_check = CRC(hexstr(crcrange).getBytes(Charset.forName("US-ASCII")));

        if (!crc_check.equals(crc)) return "INVALID";

        String r = hexstr(command);

        // Remove the \r\n
        return r.substring(0, r.length()-2);
    }

    private String strhex(String string){
        byte[] buf = string.getBytes(Charset.forName("US-ASCII"));
        char[] chars = new char[2 * buf.length];
        for (int i = 0; i < buf.length; ++i) {
            chars[2 * i] = HEX_CHARS[(buf[i] & 0xF0) >>> 4];
            chars[2 * i + 1] = HEX_CHARS[buf[i] & 0x0F];
        }
        return new String(chars);
    }

    private String hexstr(String hex){
        byte [] txtInByte = new byte [hex.length() / 2];
        int j = 0;
        for (int i = 0; i < hex.length(); i += 2) {
            txtInByte[j++] = Byte.parseByte(hex.substring(i, i + 2), 16);
        }
        return new String(txtInByte);
    }

    private String CRC(byte[] bytes){
        int crc = 0;
        for (int byt=0; byt<bytes.length; byt++){
            crc = crc ^ bytes[byt];
            for (int bit=0; bit<8; bit++){
                int carry = crc & 1;
                crc = crc>>1;
                if (carry == 1) crc=crc ^ 0xA001;
            }

        }
        return String.format("%08X", crc);
    }
}
