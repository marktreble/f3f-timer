package com.extravision.tracking.Fragments;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.extravision.tracking.R;
import com.extravision.tracking.Adapters.DragnDropArrayAdapter;
import com.extravision.tracking.Views.DragnDropListView;

import java.util.ArrayList;

/**
 * Created by marktreble on 04/01/2016.
 */
public class ReorderGroupsFragment extends Fragment {

    private static final String TAG = "ReorderGroupsFrag";

    private DragnDropListView mList;
    private DragnDropArrayAdapter mAdapter;

    private ArrayList<String> mGroups;
    private ArrayList<Boolean> mGroupsStatus;
    private String mPrefix = "";

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Log.d(TAG, "ONCREATE");

    }

    public void setParams(ArrayList<String> groups, ArrayList<Boolean> status, String prefix){
        // Passthrough variables
        mGroups = groups;
        mGroupsStatus = status;
        mPrefix = prefix;
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dd_list_container, null);

        mList = (DragnDropListView)view.findViewById(R.id.list);
        setList();

        return view;
    }

    private void setList(){


        mAdapter = new DragnDropArrayAdapter(getActivity(), R.layout.dd_list_item, R.id.name, mGroups, R.id.handler ){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the data item for this position
                String option = getItem(position);
                // Check if an existing view is being reused, otherwise inflate the view
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.dd_list_item, parent, false);
                }
                convertView.setVisibility(View.VISIBLE);
                // Lookup view for data population
                TextView name = (TextView) convertView.findViewById(R.id.name);
                name.setText(option);

                // Return the completed view to render on screen
                return convertView;
            }
        };

        mList.setDragnDropAdapter(mAdapter);
        mList.setOnItemDragnDropListener(new DragnDropListView.OnItemDragnDropListener() {
            @Override
            public void onItemDrag(DragnDropListView parent, View view, int position, long id) {

            }

            @Override
            public void onItemDrop(DragnDropListView parent, View view, int startPosition, int endPosition, long id) {

                int positions[] = mAdapter.getPositions();

                ArrayList<String> tmpGroups = new ArrayList<>();
                ArrayList<Boolean> tmpStatus = new ArrayList<>();
                for (int i=0; i<mGroups.size(); i++){
                    tmpGroups.add(mGroups.get(positions[i]));
                    tmpStatus.add(mGroupsStatus.get(positions[i]));
                }
                // Save to Prefs as string of zeros (false) and ones (true)
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
                String user_id = sharedPreferences.getString("user_id", "");
                SharedPreferences.Editor e = sharedPreferences.edit();

                // Save Group order
                String str_groups = TextUtils.join("|||", tmpGroups);
                e.putString(mPrefix+"group_names_order_"+user_id, str_groups);
                Log.i("PPP","NAMES ORDER: "+str_groups);

                // Save Status Order
                String str_status = "";
                for (int i=0; i<tmpStatus.size(); i++){
                    str_status+= (tmpStatus.get(i))?"1":"0";
                }
                e.putString(mPrefix+"group_status_"+user_id, str_status);

                e.apply();

            }
        });
    }



    @Override
    public void onStart(){
        super.onStart();

    }

}
