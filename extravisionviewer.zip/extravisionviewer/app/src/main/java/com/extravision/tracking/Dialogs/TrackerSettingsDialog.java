package com.extravision.tracking.Dialogs;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.AppCompatSpinner;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;

import com.extravision.tracking.Managers.API;
import com.extravision.tracking.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by marktreble on 06/01/2016.
 */
public class TrackerSettingsDialog extends DialogFragment {

    private ViewGroup mView;

    private String user_id;
    public String mObject_id;

    private DialogFragment mFragment;

    public static TrackerSettingsDialog newInstance() {

        TrackerSettingsDialog settingsDialog = new TrackerSettingsDialog();
        return settingsDialog;
    }

    public interface SettingsDialogListener {

        void onSettingsChanged();
    }

    public SettingsDialogListener mListener;


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(STYLE_NO_TITLE);
        mView = (ViewGroup)inflater.inflate(R.layout.tracker_settings_dialog, null);

        mFragment = this;
        setCancelable(false);

        Button ok = (Button)mView.findViewById(R.id.btn_ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.onCancel(getDialog());
            }
        });

        ImageView close = (ImageView)mView.findViewById(R.id.close_btn);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFragment.onCancel(getDialog());
            }
        });



        AppCompatSpinner operator = (AppCompatSpinner)mView.findViewById(R.id.operator);
        EditText username = (EditText)mView.findViewById(R.id.username);
        EditText password = (EditText)mView.findViewById(R.id.password);
        EditText number = (EditText)mView.findViewById(R.id.number);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        user_id = sharedPreferences.getString("user_id", "");
        String val_operator = sharedPreferences.getString("operator_"+user_id+"_"+mObject_id, "");
        String val_username = sharedPreferences.getString("username_"+user_id+"_"+mObject_id, "");
        String val_password = sharedPreferences.getString("password_"+user_id+"_"+mObject_id, "");
        String val_number = sharedPreferences.getString("number_"+user_id+"_"+mObject_id, "");

        List<String> options = new ArrayList<>();
        options.add("Select...");   // Default (None chosen yet)
        options.add("Op1");         // GeoSIM
        options.add("Op2");         // Aeris
        options.add("Op3");         // GPRS

        int selected = 0;
        for (int i=0; i<options.size(); i++) {
            if (val_operator.equals(options.get(i))){
                selected = i;
            }
        }

        String[] operator_options = options.toArray(new String[options.size()]);
        ArrayAdapter<String> sadapter = new ArrayAdapter<>(getActivity(), R.layout.custom_spinner_item, operator_options);
        operator.setAdapter(sadapter);
        operator.setSelection(selected);

        username.setText(val_username);
        password.setText(val_password);
        number.setText(val_number);



        return mView;
    }

    @Override
    public void onStart() {
        super.onStart();

        if (getDialog() == null)
            return;

        getDialog().getWindow().setWindowAnimations(R.style.slide);

        getDialog().getWindow().setGravity(Gravity.CENTER);

        int screenWidth = (int) getResources().getDisplayMetrics().widthPixels;
        getDialog().getWindow().setLayout(screenWidth,
                RelativeLayout.LayoutParams.WRAP_CONTENT);

        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        AppCompatSpinner operator = (AppCompatSpinner)mView.findViewById(R.id.operator);
        EditText username = (EditText)mView.findViewById(R.id.username);
        EditText password = (EditText)mView.findViewById(R.id.password);
        EditText number = (EditText)mView.findViewById(R.id.number);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        sharedPreferences.edit()
                .putString("operator_" + user_id + "_" + mObject_id, operator.getSelectedItem().toString())
                .putString("username_" + user_id + "_" + mObject_id, username.getText().toString())
                .putString("password_"+user_id+"_"+mObject_id, password.getText().toString())
                .putString("number_"+user_id+"_"+mObject_id, number.getText().toString())
                .apply();

        Log.d("TRACKERSETTINGS", "username_" + user_id + "_" + mObject_id);
        Log.d("TRACKERSETTINGS", operator.getSelectedItem().toString());
        Log.d("TRACKERSETTINGS", username.getText().toString());
        Log.d("TRACKERSETTINGS", password.getText().toString());
        Log.d("TRACKERSETTINGS", number.getText().toString());

        // update api
        /*??
        String token = sharedPreferences.getString("token", null);
        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_SAVE_OBJECT_CONTROL_DETAILS);
        params.put("t", token);
        params.put("o", mObject_id);
        params.put("u", username.getText().toString());
        params.put("p", username.getText().toString());
        params.put("n", username.getText().toString());

        API apitask = new API();
        apitask.request = API.API_SAVE_OBJECT_CONTROL_DETAILS;
        apitask.makeAPICall(getActivity(), API.httpmethod.GET, params);
        */

        if (mListener != null)
            mListener.onSettingsChanged();

        super.onCancel(dialog);
        mFragment.dismissAllowingStateLoss();

    }

    @Override
    public void onDismiss(DialogInterface dialog){


        super.onDismiss(dialog);
    }
}
