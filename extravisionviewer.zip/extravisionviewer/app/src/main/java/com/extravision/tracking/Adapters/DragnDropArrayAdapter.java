package com.extravision.tracking.Adapters;

/**
 * Created by marktreble on 05/01/2017.
 */

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.extravision.tracking.Views.DragnDropListView;

import java.util.List;

public class DragnDropArrayAdapter extends ArrayAdapter implements DragnDropAdapter {
    private int mPosition[];
    private int mHandler;
    private List<String> dataList;

    public DragnDropArrayAdapter(Context context, int resource, int textViewResourceId, List<String> objects, int handler) {
        super(context, resource, textViewResourceId, objects);

        Log.i("DD", "HANDLER = "+handler);
        mHandler = handler;
        dataList = objects;
        setup(objects.size());
    }

    private void setup(int size) {
        mPosition = new int[size];

        for (int i = 0; i < size; ++i)
            mPosition[i] = i;
    }

    public int[] getPositions(){
        return mPosition;
    }

    @Override
    public View getDropDownView(int position, View view, ViewGroup group) {
        return super.getDropDownView(mPosition[position], view, group);
    }

    @Override
    public String getItem(int position) {
        return (String)super.getItem(mPosition[position]);
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(mPosition[position]);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(mPosition[position]);
    }

    @Override
    public View getView(int position, View view, ViewGroup group) {
        return super.getView(mPosition[position], view, group);
    }

    @Override
    public boolean isEnabled(int position) {
        return super.isEnabled(mPosition[position]);
    }

    @Override
    public void onItemDrag(DragnDropListView parent, View view, int position, long id) {

    }

    @Override
    public void onItemDrop(DragnDropListView parent, View view, int startPosition, int endPosition, long id) {
        int position = mPosition[startPosition];

        if (startPosition < endPosition)
            for (int i = startPosition; i < endPosition; ++i)
                mPosition[i] = mPosition[i + 1];
        else if (endPosition < startPosition)
            for (int i = startPosition; i > endPosition; --i)
                mPosition[i] = mPosition[i - 1];

        mPosition[endPosition] = position;
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public void notifyDataSetChanged() {
        setup(dataList.size());
        super.notifyDataSetChanged();
    }

    @Override
    public int getDragHandler() {
        return mHandler;
    }
}