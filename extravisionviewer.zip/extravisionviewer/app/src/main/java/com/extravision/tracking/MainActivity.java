package com.extravision.tracking;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.content.SharedPreferencesCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import com.extravision.tracking.Dialogs.HistorySettingsDialog;
import com.extravision.tracking.Dialogs.LogoutDialog;
import com.extravision.tracking.Dialogs.NotificationSettingsDialog;
import com.extravision.tracking.Dialogs.SettingsDialog;
import com.extravision.tracking.Fragments.HistoryListFragment;
import com.extravision.tracking.Fragments.HistoryMapFragment;
import com.extravision.tracking.Fragments.LiveTrackingFragment;
import com.extravision.tracking.Fragments.NotificationsListFragment;
import com.extravision.tracking.Fragments.ObjectContextMenuFragment;
import com.extravision.tracking.Fragments.ObjectListFragment;
import com.extravision.tracking.Fragments.ObjectListLayoutFullFragment;
import com.extravision.tracking.Fragments.ReorderGroupsFragment;
import com.extravision.tracking.Fragments.ServicingListFragment;
import com.extravision.tracking.Fragments.TrackerCommandsListFragment;
import com.extravision.tracking.Fragments.TrackerServicingFragment;
import com.extravision.tracking.Managers.API;
import com.extravision.tracking.Managers.RGeocode;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

/**
 * Created by marktreble on 04/01/2016.
 */
public class MainActivity extends FragmentActivity
        implements View.OnClickListener, LogoutDialog.LogoutDialogListener,
        API.APICallbackInterface, SettingsDialog.SettingsDialogListener,
        NotificationSettingsDialog.NotificationSettingsDialogListener {

    // For GCM
    public static final String EXTRA_MESSAGE = "message";
    public static final String PROPERTY_REG_ID = "registration_id";
    private static final String PROPERTY_APP_VERSION = "appVersion";
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private final static int OBJECT_SEARCH = 9001;
    public final static String REGISTRATION_COMPLETE = "registration_complete";

    public final static int VIEW_TYPE_MAP = 1;
    public final static int VIEW_TYPE_O_CONTEXT_MENU = 2;

    private static final String TAG = "MainActivity";

    private static final String LOGOUT_DIALOG = "Logout Dialog";
    private static final String SETTINGS_DIALOG = "Settings Dialog";
    private static final String HISTORY_SETTINGS_DIALOG = "History Settings Dialog";

    private static final int FRAG_OBJECTS = 1;
    private static final int FRAG_O_CONTEXT_MENU = 2;
    private static final int FRAG_REORDER_GROUPS = 3;
    public static final int FRAG_LIVE_TRACKING = 4;
    public static final int FRAG_HISTORY_MAP = 5;
    public static final int FRAG_HISTORY_LIST = 6;
    public static final int FRAG_SERVICING = 7;
    public static final int FRAG_TRACKER_COMMANDS = 8;
    private static final int FRAG_NOTIFICATIONS = 9;
    private static final int FRAG_SERVICING_LIST = 10;
    public static final int FRAG_SHARE_LOC = 11;

    public static final int SHUTDOWN_TIMOUT = 1000;


    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */
    private API mAPITask = null;

    // UI references.
    int mCurrentFrag;

    private String user_id;

    //private WeakReference mContext;
    private String mToken;

    private BroadcastReceiver mRegistrationBroadcastReceiver;

    public static final Handler mHandler = new Handler();

    // These booleans record that the user has requested a navigation item in the app
    // rather than pressing home to put app into the background
    // Setting these cancels the app kill timeout in onPause
    private boolean mLoggedOut;
    private boolean mIsSearching;

    private Button mBtnLogout;
    private Button mBtnBack;
    private ImageButton mBtn_swap;
    private ImageButton mBtn_search;
    private ImageButton mBtn_settings;
    private ImageButton mBtn_delete;
    private ImageButton mBtn_history_settings;
    private ImageButton mBtn_history_list;
    private JSONObject mZoom;

    private Button mTab_tracking;
    private Button mTab_notifications;
    private Button mTab_servicing;

    private TextView mTitle;

    private boolean layout_full_enabled;
    private boolean left_handed_enabled;
    private boolean immobiliser_shortcut_enabled;

    public ProgressDialog pDialog = null;

    // SMS Permission
    public boolean mPermissionRequested;

    private Fragment mFragment;
    public String mOldest_date;
    private String mIds;
    public JSONObject mData;
    private String mCurrentTitle;
    private boolean mMultiTrackerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //mContext = new WeakReference<>(this);

        mRegistrationBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                SharedPreferences sharedPreferences =
                        PreferenceManager.getDefaultSharedPreferences(context);
                boolean sentToken = sharedPreferences.getBoolean("gcm_token_sent", false);
                String ptoken = sharedPreferences.getString("ptoken", null);
                String token = sharedPreferences.getString("token", null);

                if (token != null && !sentToken) {
                    sendTokenToServer(ptoken, token);
                }
            }
        };

        // Check device for Play Services APK. If check succeeds, proceed with
        //  GCM registration.
        if (checkPlayServices()) {
            // Start IntentService to register this application with GCM.
            Intent intent = new Intent(this, RegistrationListenerService.class);
            startService(intent);
        }

        // Find retained views and add listeners
        mBtnLogout = (Button)findViewById(R.id.btn_logout);
        mBtnLogout.setOnClickListener(this);

        mBtnBack = (Button)findViewById(R.id.btn_back);
        mBtnBack.setOnClickListener(this);

        mTitle = (TextView)findViewById(R.id.title);
        mTitle.setText("Objects");

        mBtn_search = (ImageButton)findViewById(R.id.btn_search);
        mBtn_search.setOnClickListener(this);

        mBtn_settings = (ImageButton)findViewById(R.id.btn_settings);
        mBtn_settings.setOnClickListener(this);

        mBtn_delete = (ImageButton)findViewById(R.id.btn_delete);
        mBtn_delete.setOnClickListener(this);

        mBtn_history_settings = (ImageButton)findViewById(R.id.btn_history_settings);
        mBtn_history_settings.setOnClickListener(this);

        mBtn_history_list = (ImageButton)findViewById(R.id.btn_history_list);
        mBtn_history_list.setOnClickListener(this);

        mBtn_swap = (ImageButton)findViewById(R.id.btn_swap);
        mBtn_swap.setOnClickListener(this);


        mTab_tracking = (Button)findViewById(R.id.tab_tracking);
        mTab_notifications = (Button)findViewById(R.id.tab_notifications);
        mTab_servicing = (Button)findViewById(R.id.tab_servicing);

        mTab_tracking.setOnClickListener(this);
        mTab_notifications.setOnClickListener(this);
        mTab_servicing.setOnClickListener(this);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        user_id = preferences.getString("user_id", "");
        String prefID = preferences.getString("prefID", user_id);
        layout_full_enabled = preferences.getBoolean("layout_full_enabled_" + prefID, false);
        left_handed_enabled = preferences.getBoolean("left_handed_enabled_" + prefID, false);
        immobiliser_shortcut_enabled = preferences.getBoolean("immobiliser_shortcut_enabled_" + prefID, false);

        // Set the scene
        if (savedInstanceState == null) {

            showTabTracking();

        } else {
            mToken = savedInstanceState.getString("token");
            mCurrentFrag = savedInstanceState.getInt("currentFrag");
            String title = savedInstanceState.getString("title");
            mIds = savedInstanceState.getString("mIds");
            mOldest_date = savedInstanceState.getString("mOldest_date");

            FragmentManager fm = this.getSupportFragmentManager();
            mFragment = fm.findFragmentById(R.id.main_content);

            Log.d(TAG, "FRAG = "+mCurrentFrag);
            switch (mCurrentFrag){
                case FRAG_O_CONTEXT_MENU:
                    showButtonsForContextMenu();
                    showBackButton(title);
                    break;

                case FRAG_OBJECTS:
                    showButtonsForTab(R.id.tab_tracking);
                    showLogoutButton();
                    break;

                case FRAG_NOTIFICATIONS:
                    showButtonsForTab(R.id.tab_notifications);
                    showLogoutButton();
                    break;

                case FRAG_SERVICING_LIST:
                    showButtonsForTab(R.id.tab_servicing);
                    showLogoutButton();
                    break;

                case FRAG_HISTORY_MAP:
                    showButtonsForTab(R.id.tab_tracking);
                    showBackButton(title);
                    showButtonsForHistoryMap();
                    break;

                case FRAG_LIVE_TRACKING:
                    showButtonsForTab(R.id.tab_tracking);
                    showBackButton(title);
                    showButtonsForLiveTracking();
                    break;

                case FRAG_HISTORY_LIST:
                    showButtonsForTab(R.id.tab_tracking);
                    showBackButton(title);
                    showButtonsForHistoryList();
                    break;
                case FRAG_SERVICING:
                case FRAG_TRACKER_COMMANDS:
                    showButtonsForTab(R.id.tab_tracking);
                    showBackButton(title);
                    showButtonsForContextMenu();
                    break;
            }
        }


    }

    // Runnable to shutdown application after 2 seconds of background
    // This forces the app to restart and require the PIN number
    Runnable shutdown = new Runnable() {
        @Override
        public void run() {
            finish();
            System.exit(0);
        }
    };


    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(REGISTRATION_COMPLETE));

        // Cancel Shutdown timeout
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        mPermissionRequested = false;

        /* DEP
        registerReceiver(smsSentReceiver, new IntentFilter("SMS_SENT"));
        registerReceiver(smsReceivedReceiver, new IntentFilter("SMS_RECEIVED"));
        */
    }

    @Override
    protected void onPause() {
        /* DEP
        unregisterReceiver(smsReceivedReceiver);
        unregisterReceiver(smsSentReceiver);
        */

        try {
            FragmentManager fm = this.getSupportFragmentManager();
            Fragment o = fm.findFragmentById(R.id.main_content);
            if (o.getClass() == LiveTrackingFragment.class) {
                ((LiveTrackingFragment) o).destroy();
            }
            if (o.getClass() == ObjectListLayoutFullFragment.class) {
                ((ObjectListLayoutFullFragment) o).destroy();
            }
        } catch (Exception e) {
            // Ignore
        }

        LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
        super.onPause();
        if (mLoggedOut) return;
        if (mIsSearching) return;
        if (mPermissionRequested) return;
        // Shutdown after SHUTDOWN_TIMOUT seconds
        mHandler.postDelayed(shutdown, MainActivity.SHUTDOWN_TIMOUT);

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("token", mToken);
        outState.putInt("currentFrag", mCurrentFrag);
        outState.putString("title", mTitle.getText().toString());
        outState.putString("mIds", mIds);
        outState.putString("mOldest_date", mOldest_date);

        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed(){
        // Call methods on exiting class
        try {
            FragmentManager fm = this.getSupportFragmentManager();
            Fragment o = fm.findFragmentById(R.id.main_content);
            if (o.getClass() == LiveTrackingFragment.class) {
                ((LiveTrackingFragment) o).destroy();
            }
            if (o.getClass() == ObjectListLayoutFullFragment.class) {
                ((ObjectListLayoutFullFragment) o).destroy();
            }

        } catch (Exception e) {
            // Ignore
        }

        super.onBackPressed();

        if (mCurrentFrag == FRAG_OBJECTS
                || mCurrentFrag == FRAG_NOTIFICATIONS
                || mCurrentFrag == FRAG_SERVICING_LIST){
            mLoggedOut = true;
        }

        if (mCurrentFrag == FRAG_O_CONTEXT_MENU
                || mCurrentFrag == FRAG_REORDER_GROUPS) {
            mCurrentFrag = FRAG_OBJECTS;
            showLogoutButton();
        }

        if (mCurrentFrag == FRAG_TRACKER_COMMANDS
            || mCurrentFrag == FRAG_HISTORY_LIST
                || mCurrentFrag == FRAG_HISTORY_MAP
                || mCurrentFrag == FRAG_SERVICING
            || mCurrentFrag == FRAG_LIVE_TRACKING){
            mCurrentFrag = FRAG_O_CONTEXT_MENU;
            showButtonsForContextMenu();
        }

        // Call methods on resuming class
        try {
            FragmentManager fm = this.getSupportFragmentManager();
            Fragment o = fm.findFragmentById(R.id.main_content);
            if (o.getClass() == ObjectListFragment.class) {
                ((ObjectListFragment) o).resume();
            }
            if (o.getClass() == ObjectListLayoutFullFragment.class) {
                ((ObjectListLayoutFullFragment) o).resume();
            }
            if (o.getClass() == ServicingListFragment.class) {
                ((ServicingListFragment) o).resume();
            }
        } catch (Exception e) {
            // Ignore
        }

    }

    public void onClick(View v){
        mZoom = null;

        FragmentManager fm = this.getSupportFragmentManager();
        Fragment o = fm.findFragmentById(R.id.main_content);
        try {
            if (o.getClass() == LiveTrackingFragment.class) {
                ((LiveTrackingFragment) o).destroy();
            }
        } catch (Exception e){
            e.printStackTrace();

        }
        try {
            if (o.getClass() == ObjectListLayoutFullFragment.class) {
                ((ObjectListLayoutFullFragment) o).destroy();
            }
        } catch (Exception e){
            e.printStackTrace();

        }
        String[] ids;

        switch (v.getId()){
            case R.id.btn_logout:
                showLogOutDialog();
                break;
            case R.id.btn_back:
                onBackPressed();
                break;
            case R.id.btn_settings:
                if (mCurrentFrag == FRAG_OBJECTS) showSettings();
                if (mCurrentFrag == FRAG_NOTIFICATIONS) showNotificationSettings();
                break;
            case R.id.btn_delete:
                if (mCurrentFrag == FRAG_NOTIFICATIONS) deleteNotifications();
                break;
            case R.id.btn_search:
                showObjectSearch();
                break;
            case R.id.btn_history_settings:
                showHistorySettings();
                break;
            case R.id.tab_tracking:
                showTabTracking();
                break;
            case R.id.tab_notifications:
                showTabNotifications();
                break;
            case R.id.tab_servicing:
                showTabServicing();
                break;
            case R.id.btn_swap:
                ids = new String[1];
                ids[0] = mIds;

                fm.popBackStack (mFragment.getClass().getName(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
                switch (mCurrentFrag){

                    case FRAG_LIVE_TRACKING:
                        ((LiveTrackingFragment)mFragment).destroy();
                        showHistoryMap(ids, mCurrentTitle, mOldest_date);
                    break;

                    case FRAG_HISTORY_MAP:
                        showRealtimeMap(ids, mCurrentTitle, mOldest_date);
                        break;
                }
                break;

            case R.id.btn_history_list:
                ids = new String[1];
                ids[0] = mIds;

                fm.popBackStack (mFragment.getClass().getName(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
                switch (mCurrentFrag){

                    case FRAG_HISTORY_MAP:
                        showHistoryList(ids, mCurrentTitle, mOldest_date);
                        break;
                }
                break;

        }
    }

    public void showTabTracking(){

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String token = preferences.getString("token", null);
        if (token == null) logout();
        mToken = token;

        mCurrentFrag = FRAG_OBJECTS;

        // Add Objects List Fragment
        FragmentManager fm = this.getSupportFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();
        Fragment frag;
        if (!layout_full_enabled) {
            frag = new ObjectListLayoutFullFragment();
        } else {
            frag = new ObjectListFragment();
        }
        frag.setRetainInstance(true);
        trans.replace(R.id.main_content, frag);
        trans.commit();

        getObjects((API.APICallbackInterface) frag);

        showButtonsForTab(R.id.tab_tracking);
    }

    public void showTabNotifications(){

        pausePolling();

        mCurrentFrag = FRAG_NOTIFICATIONS;

        // Add Notifications List Fragment
        FragmentManager fm = this.getSupportFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();
        NotificationsListFragment frag = new NotificationsListFragment();
        frag.setRetainInstance(true);
        trans.replace(R.id.main_content, frag);
        trans.commit();

        showButtonsForTab(R.id.tab_notifications);
    }

    public void showTabServicing(){

        pausePolling();

        mCurrentFrag = FRAG_SERVICING_LIST;

        // Add Servicing List Fragment
        FragmentManager fm = this.getSupportFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();
        ServicingListFragment frag = new ServicingListFragment();
        frag.setRetainInstance(true);
        trans.replace(R.id.main_content, frag);
        trans.commit();

        getObjects(frag);

        showButtonsForTab(R.id.tab_servicing);
    }

    public void showSettings(){
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(SETTINGS_DIALOG) == null) {
            final SettingsDialog lDialog = SettingsDialog.newInstance();
            lDialog.mListener = this;
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, SETTINGS_DIALOG).commitAllowingStateLoss();
        }
    }

    public void onSettingsChanged(){
        Log.i(TAG, "OnSettingsChanged");
        if (mCurrentFrag == FRAG_OBJECTS){
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
            String prefID = preferences.getString("prefID", user_id);
            boolean changed_layout_full_enabled = preferences.getBoolean("layout_full_enabled_" + prefID, false);
            boolean changed_left_handed = preferences.getBoolean("left_handed_enabled_" + prefID, false);
            boolean changed_immobiliser_shortcut = preferences.getBoolean("immobiliser_shortcut_enabled_" + prefID, false);


            if (changed_layout_full_enabled != layout_full_enabled
                    || changed_left_handed != left_handed_enabled
                    || changed_immobiliser_shortcut != immobiliser_shortcut_enabled) {

                layout_full_enabled = changed_layout_full_enabled;
                left_handed_enabled = changed_left_handed;
                immobiliser_shortcut_enabled = changed_immobiliser_shortcut;

                FragmentManager fm = this.getSupportFragmentManager();
                FragmentTransaction trans = fm.beginTransaction();
                Fragment frag;
                if (!layout_full_enabled) {
                    Log.i(TAG, "RESUME POLLING");
                    frag = new ObjectListLayoutFullFragment();
                    ((ObjectListLayoutFullFragment)frag).resumePolling();
                } else {
                    frag = new ObjectListFragment();

                    pausePolling();

                }
                frag.setRetainInstance(true);
                trans.replace(R.id.main_content, frag);
                trans.commit();

                getObjects((API.APICallbackInterface) frag);
            } else {
                if (!layout_full_enabled) {
                    Log.i(TAG, "RESUME POLLING W/O CHANGE");
                    FragmentManager fm = this.getSupportFragmentManager();

                    ObjectListLayoutFullFragment o = (ObjectListLayoutFullFragment)fm.findFragmentById(R.id.main_content);
                    o.resumePolling();
                    o.onSettingsChanged(this);
                }
            }

        }
    }

    public void showNotificationSettings(){
     FragmentManager fm = this.getSupportFragmentManager();
     if (fm.findFragmentByTag(SETTINGS_DIALOG) == null) {
         final NotificationSettingsDialog lDialog = NotificationSettingsDialog.newInstance();
         lDialog.mListener = this;
         FragmentTransaction trans = fm.beginTransaction();

         trans.add(lDialog, SETTINGS_DIALOG).commitAllowingStateLoss();
     }
    }

    public void onNotificationSettingsChanged() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        // update api
        String token = sharedPreferences.getString("token", null);
        String notifications = sharedPreferences.getString("notifications", null);
        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_SAVE_NOTIFICATION_SETTINGS);
        params.put("t", token);
        params.put("n", notifications);

        API apitask = new API();
        apitask.request = API.API_SAVE_NOTIFICATION_SETTINGS;
        apitask.makeAPICall(this, API.httpmethod.POST, params);


    }

    public void deleteNotifications(){
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.app_name))
                .setMessage("This will clear all your notifications. Are you sure you want to do this?")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        clearNotifications();
                    }
                })
                .create().show();
    }

    public void clearNotifications(){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String user_id = preferences.getString("user_id", "");
        preferences.edit()
                .putString("notifications_" + user_id, "[]")
                .apply();

        showTabNotifications();
    }

    public void getObjects(API.APICallbackInterface callback){
        // Call the api on behalf of the fragment
        // Data will be returned to fragment's APIResponse callback methods
        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_GET_OBJECTS);
        params.put("t", mToken);

        mAPITask = new API();
        mAPITask.mCallback = callback;
        mAPITask.request = API.API_GET_OBJECTS;
        mAPITask.makeAPICall(this, API.httpmethod.GET, params);

    }

    private void showObjectSearch(){
        mIsSearching = true;
        Intent i = new Intent(this, EVSearchObjectActivity.class);
        i.putExtra("token", mToken);
        startActivityForResult(i, OBJECT_SEARCH);
    }

    private void showLogOutDialog(){
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(LOGOUT_DIALOG) == null) {
            final LogoutDialog lDialog = LogoutDialog.newInstance();
            lDialog.mListener = this;
            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, LOGOUT_DIALOG).commitAllowingStateLoss();
        }
    }

    public void onDialogChooseLogout(){
        logout();
    }

    public void onDialogChooseCancel(){
        // Nowt to do...
    }

    private void pausePolling(){
        if (mCurrentFrag != FRAG_OBJECTS) return;

        // Cancel the polling if needed
        FragmentManager fm = this.getSupportFragmentManager();

        try {
            ObjectListLayoutFullFragment o = (ObjectListLayoutFullFragment)fm.findFragmentById(R.id.main_content);
            o.pausePolling();
        } catch (Exception e){
            // Ignore
        }
    }
    private void showBackButton(String title){
        mBtnLogout.setVisibility(View.GONE);
        mBtnBack.setVisibility(View.VISIBLE);
        mTitle.setText(title);

    }

    private void showLogoutButton(){
        mBtnLogout.setVisibility(View.VISIBLE);
        mBtnBack.setVisibility(View.GONE);
        mBtn_search.setVisibility(View.VISIBLE);
        mBtn_settings.setVisibility(View.VISIBLE);
        mBtn_history_settings.setVisibility(View.GONE);
        mBtn_history_list.setVisibility(View.GONE);
        mBtn_swap.setVisibility(View.GONE);

        mTitle.setText(getString(R.string.tab_tracking));

    }

    private void showButtonsForContextMenu(){
        FragmentManager fm = this.getSupportFragmentManager();
        Fragment o = fm.findFragmentById(R.id.main_content);
        try {
            if (o.getClass() == ObjectListLayoutFullFragment.class) {
                ((ObjectListLayoutFullFragment) o).destroy();
            }
        } catch (Exception e){
            e.printStackTrace();

        }
        mBtn_history_settings.setVisibility(View.GONE);
        mBtn_history_list.setVisibility(View.GONE);
        mBtn_search.setVisibility(View.GONE);
        mBtn_settings.setVisibility(View.GONE);
        mBtn_swap.setVisibility(View.GONE);
    }

    private void showButtonsForHistoryList(){
        mBtn_history_settings.setVisibility(View.VISIBLE);
        mBtn_history_list.setVisibility(View.GONE);
        mBtn_search.setVisibility(View.GONE);
        mBtn_settings.setVisibility(View.GONE);
        mBtn_swap.setVisibility(View.GONE);

    }

    private void showButtonsForHistoryMap(){
        mBtn_swap.setVisibility(View.VISIBLE);
        mBtn_history_settings.setVisibility(View.VISIBLE);
        mBtn_history_list.setVisibility(View.VISIBLE);
        mBtn_search.setVisibility(View.GONE);
        mBtn_settings.setVisibility(View.GONE);

        mBtn_swap.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.live_tracking));
    }

    private void showButtonsForLiveTracking(){

        if (mCurrentFrag == FRAG_LIVE_TRACKING && mMultiTrackerView){
            mBtn_swap.setVisibility(View.GONE);
        } else {
            mBtn_swap.setVisibility(View.VISIBLE);
        }
        mBtn_history_settings.setVisibility(View.GONE);
        mBtn_history_list.setVisibility(View.GONE);
        mBtn_search.setVisibility(View.GONE);
        mBtn_settings.setVisibility(View.GONE);

        mBtn_swap.setImageDrawable(ContextCompat.getDrawable(this, R.mipmap.history_icon));
    }

    private void showButtonsForTab(int tabid){

        switch (tabid){
            case R.id.tab_tracking:
                mTab_tracking.setEnabled(false);
                mTab_notifications.setEnabled(true);
                mTab_servicing.setEnabled(true);

                mBtnLogout.setVisibility(View.VISIBLE);
                mBtnBack.setVisibility(View.GONE);
                mBtn_search.setVisibility(View.VISIBLE);
                mBtn_settings.setVisibility(View.VISIBLE);
                mBtn_delete.setVisibility(View.GONE);
                mBtn_history_settings.setVisibility(View.GONE);
                mBtn_history_list.setVisibility(View.GONE);
                mBtn_swap.setVisibility(View.GONE);
                mTitle.setText(getString(R.string.tab_tracking));
                break;
            case R.id.tab_notifications:
                mTab_tracking.setEnabled(true);
                mTab_notifications.setEnabled(false);
                mTab_servicing.setEnabled(true);

                mBtnLogout.setVisibility(View.VISIBLE);
                mBtnBack.setVisibility(View.GONE);
                mBtn_search.setVisibility(View.GONE);
                mBtn_settings.setVisibility(View.VISIBLE);
                mBtn_delete.setVisibility(View.VISIBLE);
                mBtn_history_settings.setVisibility(View.GONE);
                mBtn_history_list.setVisibility(View.GONE);
                mBtn_swap.setVisibility(View.GONE);
                mTitle.setText(getString(R.string.tab_notifications));
                break;
            case R.id.tab_servicing:
                mTab_tracking.setEnabled(true);
                mTab_notifications.setEnabled(true);
                mTab_servicing.setEnabled(false);

                mBtnLogout.setVisibility(View.VISIBLE);
                mBtnBack.setVisibility(View.GONE);
                mBtn_search.setVisibility(View.GONE);
                mBtn_settings.setVisibility(View.GONE);
                mBtn_delete.setVisibility(View.GONE);
                mBtn_history_settings.setVisibility(View.GONE);
                mBtn_history_list.setVisibility(View.GONE);
                mBtn_swap.setVisibility(View.GONE);
                mTitle.setText(getString(R.string.tab_servicing));
                break;
            default:
                mTab_tracking.setEnabled(false);
                mTab_notifications.setEnabled(true);
                mTab_servicing.setEnabled(true);

                mBtnLogout.setVisibility(View.GONE);
                mBtnBack.setVisibility(View.VISIBLE);
                mBtn_search.setVisibility(View.GONE);
                mBtn_settings.setVisibility(View.GONE);
                mBtn_delete.setVisibility(View.GONE);
                mBtn_history_settings.setVisibility(View.GONE);
                mBtn_history_list.setVisibility(View.GONE);
                mBtn_swap.setVisibility(View.GONE);
                break;

        }
    }
    private void logout(){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("token", null);
        editor.putString("user_id", "");
        SharedPreferencesCompat.EditorCompat.getInstance().apply(editor);

        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_LOGOUT);
        params.put("t", mToken);

        mAPITask = new API();
        mAPITask.mCallback = this;
        mAPITask.request = API.API_LOGOUT;
        mAPITask.makeAPICall(this, API.httpmethod.GET, params);
    }

    public void showContextMenu(String[] ids, String title, String oldest_date, JSONObject o){
        pausePolling();

        mCurrentFrag = FRAG_O_CONTEXT_MENU;

        FragmentManager fm = this.getSupportFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();

        ObjectContextMenuFragment frag = new ObjectContextMenuFragment();
        frag.mObjectData = o;
        frag.setParams(ids, title, oldest_date);
        frag.setRetainInstance(true);
        trans.add(R.id.main_content, frag);
        String backStateName = frag.getClass().getName();
        trans.addToBackStack(backStateName);
        trans.commitAllowingStateLoss();
        mMultiTrackerView = false;
        showBackButton("");
        showButtonsForContextMenu();

    }

    public void showRealtimeMap(String[] ids, String title, String oldest_date) {
        //Intent i = new Intent(this, EVRealtimeTrackingActivity.class);
        //showActivityFromContextMenu(i, ids, title, oldest_date);

        if (ids.length == 0){
            // Show Alert
            new AlertDialog.Builder(this)
                    .setTitle("No Objects Chosen")
                    .setMessage("Please tick the boxes on the left to select which object to view, or select a single object using the arrows on the right.")
                    .create().show();
            return;
        }

        // Convert ids array into String
        StringBuilder idBuilder = new StringBuilder();

        for (String id : ids) {
            idBuilder.append(id).append(",");
        }

        idBuilder.deleteCharAt(idBuilder.length() - 1);
        String str_ids = idBuilder.toString();

        mCurrentFrag = FRAG_LIVE_TRACKING;

        FragmentManager fm = this.getSupportFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();

        LiveTrackingFragment frag = new LiveTrackingFragment();
        frag.setParams(mToken, str_ids, title, oldest_date);
        frag.setRetainInstance(true);
        trans.add(R.id.main_content, frag);
        String backStateName = frag.getClass().getName();
        trans.addToBackStack(backStateName);
        trans.commitAllowingStateLoss();
        mFragment = frag;
        mCurrentTitle = title;
        mIds = ids[0];
        mOldest_date = oldest_date;
        mMultiTrackerView = (ids.length>1);
        showBackButton("");
        showButtonsForLiveTracking();
    }

    public void showHistoryMap(String[] ids, String title, String oldest_date) {
        //Intent i = new Intent(this, EVHistoryMapActivity.class);
        //showActivityFromContextMenu(i, ids, title, oldest_date);

        if (ids.length == 0){
            // Show Alert
            new AlertDialog.Builder(this)
                    .setTitle("No Objects Chosen")
                    .setMessage("Please tick the boxes on the left to select which object to view, or select a single object using the arrows on the right.")
                    .create().show();
            return;
        }

        // Convert ids array into String
        StringBuilder idBuilder = new StringBuilder();

        for (String id : ids) {
            idBuilder.append(id).append(",");
        }

        idBuilder.deleteCharAt(idBuilder.length() - 1);
        String str_ids = idBuilder.toString();

        mCurrentFrag = FRAG_HISTORY_MAP;

        FragmentManager fm = this.getSupportFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();

        HistoryMapFragment frag = new HistoryMapFragment();
        frag.setParams(mToken, str_ids, title, oldest_date);
        frag._startPosition = mZoom;
        frag.setRetainInstance(true);
        trans.add(R.id.main_content, frag);
        String backStateName = frag.getClass().getName();
        trans.addToBackStack(backStateName);
        trans.commitAllowingStateLoss();
        mFragment = frag;
        mCurrentTitle = title;
        mOldest_date = oldest_date;
        mIds = ids[0];
        mMultiTrackerView = false;
        showBackButton("");
        showButtonsForHistoryMap();
    }

    public void showHistoryMapAtLocation(JSONObject zoom, String[] ids, String title, String oldest_date){
        FragmentManager fm = this.getSupportFragmentManager();
        fm.popBackStack (mFragment.getClass().getName(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
        mZoom = zoom;

        showHistoryMap(ids, mCurrentTitle, mOldest_date);
    }

    public void showHistoryList(String[] ids, String title, String oldest_date) {
        //Intent i = new Intent(this, EVHistoryListActivity.class);
        //showActivityFromContextMenu(i, ids, title, oldest_date);

        mBtn_settings.setVisibility(View.GONE);
        mBtn_history_settings.setVisibility(View.VISIBLE);

        // Convert ids array into String
        StringBuilder idBuilder = new StringBuilder();

        for (String id : ids) {
            idBuilder.append(id).append(",");
        }

        idBuilder.deleteCharAt(idBuilder.length() - 1);
        String str_ids = idBuilder.toString();

        mCurrentFrag = FRAG_HISTORY_LIST;

        // Add Objects List Fragment
        FragmentManager fm = this.getSupportFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();
        HistoryListFragment frag = new HistoryListFragment();
        frag.setParams(mToken, str_ids, title, oldest_date);
        frag.setRetainInstance(true);
        frag.delegate = this;
        trans.add(R.id.main_content, frag);
        String backStateName = frag.getClass().getName();
        trans.addToBackStack(backStateName);
        trans.commitAllowingStateLoss();
        mFragment = frag;
        mCurrentTitle = title;
        mIds = ids[0];
        mOldest_date = oldest_date;

        // Call api to download data
        getHistory(frag);

        showButtonsForHistoryList();
    }

    public void getHistory(API.APICallbackInterface callback){
        // Call the api on behalf of the fragment
        // Data will be returned to fragment's APIResponse callback methods
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        String today = simpleDateFormat.format(cal.getTime());
        cal.add(Calendar.DATE, -1);
        String yesterday = simpleDateFormat.format(cal.getTime());

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String date = preferences.getString("show_date", "today");
        ((HistoryListFragment)mFragment).mDate = date;

        if (date.equals("today")) date = today;
        if (date.equals("yesterday")) date = yesterday;


        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_GET_HISTORY);
        params.put("t", mToken);
        params.put("i", mIds);
        params.put("d", date);
        params.put("msd", "1");
        params.put("w", "lightplus");

        mAPITask = new API();
        mAPITask.mCallback = callback;
        mAPITask.request = API.API_GET_HISTORY;
        mAPITask.makeAPICall(this, API.httpmethod.GET, params);

    }

    private void showHistorySettings(){
        FragmentManager fm = this.getSupportFragmentManager();
        if (fm.findFragmentByTag(HISTORY_SETTINGS_DIALOG) == null) {
            final HistorySettingsDialog lDialog = HistorySettingsDialog.newInstance();
            lDialog.mListener = (HistorySettingsDialog.HistorySettingsDialogListener)mFragment;
            lDialog.mOldest_date = mOldest_date;

            FragmentTransaction trans = fm.beginTransaction();

            trans.add(lDialog, HISTORY_SETTINGS_DIALOG).commitAllowingStateLoss();
        }
    }

    public void showServicing(String[] ids, String title, JSONObject o) {

        mCurrentFrag = FRAG_SERVICING;

        FragmentManager fm = this.getSupportFragmentManager();

        FragmentTransaction trans = fm.beginTransaction();
        TrackerServicingFragment frag = new TrackerServicingFragment();
        frag.setParams(title);
        frag.setRetainInstance(true);
        frag.mIds = ids;
        frag.mObjectData = o;
        trans.add(R.id.main_content, frag);
        String backStateName = frag.getClass().getName();
        trans.addToBackStack(backStateName);
        trans.commitAllowingStateLoss();
        showBackButton("");

    }

    public void showTrackerCommandsList(String[] ids, String title, JSONObject o) {

        mCurrentFrag = FRAG_TRACKER_COMMANDS;

        FragmentManager fm = this.getSupportFragmentManager();

        FragmentTransaction trans = fm.beginTransaction();
        TrackerCommandsListFragment frag = new TrackerCommandsListFragment();
        frag.setParams(title);
        frag.setRetainInstance(true);
        frag.delegate = this;
        frag.mObjectData = o;
        trans.add(R.id.main_content, frag);
        String backStateName = frag.getClass().getName();
        trans.addToBackStack(backStateName);
        trans.commitAllowingStateLoss();

        showBackButton("");
    }

    public void shareLocation(String[] ids, String title, JSONObject o) {

        double lat = 0, lng = 0;
        try {
            final String mName = o.getString("name");
            final String mPosition = o.getString("Position");

            String[] latlng = mPosition.split(",");
            lat = Double.parseDouble(latlng[0]);
            lng = Double.parseDouble(latlng[1]);

            RGeocode.LocationReceiver location_received = new RGeocode().new LocationReceiver() {

                @Override
                public void run() {
                    String message = String.format("%s\n%s\n%s\nhttp://maps.google.com/?q=%s", mName, mAddress, mPosition, mPosition.replace(" ", ""));
                    Intent sendIntent = new Intent(Intent.ACTION_VIEW);
                    sendIntent.setData(Uri.parse("sms:"));
                    sendIntent.putExtra("sms_body", message);
                    startActivity(sendIntent);
                }
            };

            RGeocode r = new RGeocode(this, lat, lng, null, location_received);
            r.mDelimiter = "\n";
            new Thread(r).start();

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void showSMSSending(){
        if (pDialog == null) {
            pDialog = new ProgressDialog(this);
            pDialog.setTitle("Sending Command");
            pDialog.show();
        }
    }

    public void hideSMSSending(){
        if (pDialog != null)
            pDialog.hide();

        pDialog = null;
    }

    /* DEP

    BroadcastReceiver smsSentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG, "smsSentReceiver");
            ((MainActivity)context).hideSMSSending();

            String result = "";
            switch(getResultCode()) {
                case Activity.RESULT_OK:
                    result = "Command Sent";
                    break;
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    result = "Command failed (reason unknown)";
                    break;
                case SmsManager.RESULT_ERROR_RADIO_OFF:
                    result = "Command failed (Radio Off) - Is your device in Aeroplane mode?";
                    break;
                case SmsManager.RESULT_ERROR_NULL_PDU:
                    result = "No PDU defined";
                    break;
                case SmsManager.RESULT_ERROR_NO_SERVICE:
                    result = "Command failed. SMS service unavailable";
                    break;
            }
            Toast.makeText(getApplicationContext(), result,
                    Toast.LENGTH_SHORT).show();
        }
    };

    BroadcastReceiver smsReceivedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            hideSMSSending();
            String result = "";
            switch(getResultCode()) {
                case Activity.RESULT_OK:
                    break;
                case Activity.RESULT_CANCELED:
                    Toast.makeText(getApplicationContext(), "Command was not delivered. Perhaps the device is off the network at the moment.",
                            Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };
    */

    /*
    public void AerisAPIResponse(String response){
        hideSMSSending();

        String result = response;
        if (response.substring(0,10).equals("{\"address\"")) result = "Command Sent";

        Toast.makeText(getApplicationContext(), result,
                Toast.LENGTH_SHORT).show();
    }*/

    public void showReorderGroups(ArrayList<String> groups, ArrayList<Boolean> status, String prefix){
        pausePolling();

        mCurrentFrag = FRAG_REORDER_GROUPS;

        FragmentManager fm = this.getSupportFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();

        ReorderGroupsFragment frag  = new ReorderGroupsFragment();
        frag.setParams(groups, status, prefix);
        frag.setRetainInstance(true);
        trans.add(R.id.main_content, frag);
        String backStateName = frag.getClass().getName();
        trans.addToBackStack(backStateName);
        trans.commit();
        showBackButton("Reorder Groups");
    }

    public void onAPISuccess(String request, JSONObject data){
        if (request.equals(API.API_LOGOUT)) {
            pausePolling();
            mLoggedOut = true;
            Intent i = new Intent(this, LoginActivity.class);
            startActivity(i);
            finish();
        }

        if (request.equals(API.API_SAVE_PUSH_TOKEN)) {
            String status = "";
            try {
                status = data.getString("status");
            } catch (JSONException e){
                e.printStackTrace();
            }
            if (status.equals("ok")) {
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
                sharedPreferences.edit().putBoolean("gcm_token_sent", true).apply();
            }
        }

        if (request.equals(API.API_SEND_GPRS_COMMAND)) {
            hideSMSSending();

            String result = "Command sent.";

            Toast.makeText(getApplicationContext(), result,
                    Toast.LENGTH_SHORT).show();
        }

        if (request.equals(API.API_SEND_DATASIM_COMMAND)) {
            hideSMSSending();

            String result = "Command was not delivered. Bad response from server.";
            try {
                result = data.getString("data");
            } catch (JSONException e){
                e.printStackTrace();
            }

            Toast.makeText(getApplicationContext(), result,
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void onAPIError(String request, JSONObject data){
        if (request.equals(API.API_LOGOUT)) {
            Intent i = new Intent(this, LoginActivity.class);
            startActivity(i);
            finish();
        }

        if (request.equals(API.API_SAVE_PUSH_TOKEN)) {
            // Ignore it - try again another time

        }

        if (request.equals(API.API_SEND_GPRS_COMMAND)) {
            hideSMSSending();
            Log.i("GPRS", request);
            Toast.makeText(getApplicationContext(), "Command was not delivered. Bad response from server.",
                    Toast.LENGTH_SHORT).show();


        }

        if (request.equals(API.API_SEND_AERIS_COMMAND)) {
            hideSMSSending();
            Log.i("GPRS", request);
            Toast.makeText(getApplicationContext(), "Command was not delivered. Bad response from server.",
                    Toast.LENGTH_SHORT).show();


        }

        if (request.equals(API.API_SEND_DATASIM_COMMAND)) {
            hideSMSSending();
            Log.i("GPRS", request);
            Toast.makeText(getApplicationContext(), "Command was not delivered. Bad response from server.",
                    Toast.LENGTH_SHORT).show();


        }

    }

    /**
     * Check the device to make sure it has the Google Play Services APK. If
     * it doesn't, display a dialog that allows users to download the APK from
     * the Google Play Store or enable it in the device's system settings.
     */
    private boolean checkPlayServices() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (apiAvailability.isUserResolvableError(resultCode)) {
                apiAvailability.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST)
                        .show();
            } else {
                Log.i(TAG, "This device is not supported.");
                finish();
            }
            return false;
        }
        return true;
    }

    private void sendTokenToServer(String ptoken, String token) {
        Log.d("SENDING TOKEN", ptoken+"\n::"+token);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String device = sharedPreferences.getString("device_id", "");

        Map<String, String> params = new HashMap<>();
        params.put(API.ENDPOINT_KEY, API.API_SAVE_PUSH_TOKEN);
        params.put("t", token);
        params.put("d", device);
        params.put("tp", "And");
        params.put("p", ptoken);

        mAPITask = new API();
        mAPITask.mCallback = (API.APICallbackInterface)this;
        mAPITask.request = API.API_SAVE_PUSH_TOKEN;
        mAPITask.makeAPICall(this, API.httpmethod.GET, params);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == OBJECT_SEARCH) {
            mIsSearching = false;
            // Make sure the request was successful
            if (resultCode == RESULT_OK) {
                String search_result = data.getStringExtra("search_result");
                JSONObject o = null;
                try {
                    o = new JSONObject(search_result);

                    if (o != null){
                        String[] ids = new String[1];
                        ids[0] = o.getString("object_id");
                        String title = o.getString("name");
                        String oldest_date = o.getString("oldest_data");

                        showContextMenu(ids, title, oldest_date, o);
                    }


                } catch (JSONException e){
                    e.printStackTrace();
                }


            }
        }

    }
}