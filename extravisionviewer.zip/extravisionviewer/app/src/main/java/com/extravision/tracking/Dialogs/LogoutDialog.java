package com.extravision.tracking.Dialogs;

import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.DialogFragment;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.extravision.tracking.R;

/**
 * Created by marktreble on 04/01/2016.
 */
public class LogoutDialog extends DialogFragment implements View.OnClickListener {

    private boolean isGallery;

    public static LogoutDialog newInstance() {

        LogoutDialog areyousureDialog = new LogoutDialog();
        return areyousureDialog;
    }

    public interface LogoutDialogListener {

        void onDialogChooseLogout();
        void onDialogChooseCancel();
    }

    public LogoutDialogListener mListener;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(STYLE_NO_TITLE);
        View view = inflater.inflate(R.layout.logout_dialog, null);

        ImageView close = (ImageView)view.findViewById(R.id.close_btn);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });

        Button btn_logout = (Button) view.findViewById(R.id.btn_logout);
        btn_logout.setOnClickListener(this);

        Button btn_cancel = (Button) view.findViewById(R.id.btn_cancel);
        btn_cancel.setOnClickListener(this);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        if (getDialog() == null)
            return;

        getDialog().getWindow().setWindowAnimations(R.style.slide);

        getDialog().getWindow().setGravity(Gravity.CENTER);

        int screenWidth = (int) getResources().getDisplayMetrics().widthPixels;
        getDialog().getWindow().setLayout(screenWidth,
                RelativeLayout.LayoutParams.WRAP_CONTENT);

        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.btn_logout:
                dismiss();
                if (mListener != null)
                    mListener.onDialogChooseLogout();
                break;

            case R.id.btn_cancel:
                dismiss();
                if (mListener != null)
                    mListener.onDialogChooseCancel();
                break;

        }
    }


}
