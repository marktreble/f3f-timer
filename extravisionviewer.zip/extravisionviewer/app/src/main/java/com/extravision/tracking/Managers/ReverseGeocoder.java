package com.extravision.tracking.Managers;

import android.content.Context;
import android.location.Location;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.extravision.tracking.R;

/**
 * Created by marktreble on 26/01/15.
 */
public class ReverseGeocoder {
    public static String getFromLocation(Location loc, Context context){
        
        String url = String.format("https://maps.googleapis.com/maps/api/geocode/json?location_type=APPROXIMATE&latlng=%f,%f&key=%s",loc.getLatitude(), loc.getLongitude(), context.getResources().getString(R.string.google_api_key));

        Log.d("Geocoder", url);
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        String str_response = null;

        try {
            Response r = client.newCall(request).execute();
            if (r.isSuccessful()) {
                str_response = r.body().string();
            } else {
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }
        String str_address = "";
        try {
            JSONObject results = new JSONObject(str_response);
            JSONArray arr = results.getJSONArray("results");
            
            if (arr.length()>0) {

                JSONObject address = arr.getJSONObject(0);
                str_address = address.getString("formatted_address");

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return str_address;
        
    }
}
