package com.extravision.tracking.Adapters;

import android.widget.ListAdapter;

import com.extravision.tracking.Views.DragnDropListView;

/**
 * Created by marktreble on 05/01/2017.
 */

public interface DragnDropAdapter extends ListAdapter, DragnDropListView.OnItemDragnDropListener {
    public int getDragHandler();
}